import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.ProgressBar;
public class SWTGrid {

	private Shell sShell = null;  //  @jve:decl-index=0:visual-constraint="26,17"
	private Label label = null;
	private Text text = null;
	private Button button = null;
	private List list = null;
	private Button button1 = null;
	private Button button2 = null;
	private Button button3 = null;
	private Button button4 = null;
	private Button button5 = null;
	private ProgressBar progressBar = null;
	/**
	 * This method initializes sShell	
	 *
	 */    
	private void createSShell() {
		sShell = new Shell();		   
		GridLayout gridLayout2 = new GridLayout();
		org.eclipse.swt.layout.GridData gridData3 = new org.eclipse.swt.layout.GridData();
		org.eclipse.swt.layout.GridData gridData4 = new org.eclipse.swt.layout.GridData();
		org.eclipse.swt.layout.GridData gridData5 = new org.eclipse.swt.layout.GridData();
		org.eclipse.swt.layout.GridData gridData6 = new org.eclipse.swt.layout.GridData();
		label = new Label(sShell, SWT.NONE);
		text = new Text(sShell, SWT.BORDER);
		button = new Button(sShell, SWT.NONE);
		list = new List(sShell, SWT.BORDER);
		button1 = new Button(sShell, SWT.NONE);
		button2 = new Button(sShell, SWT.NONE);
		button3 = new Button(sShell, SWT.NONE);
		button4 = new Button(sShell, SWT.NONE);
		button5 = new Button(sShell, SWT.NONE);
		progressBar = new ProgressBar(sShell, SWT.NONE);
		sShell.setSize(new org.eclipse.swt.graphics.Point(426,247));
		sShell.setText("Grid Test");
		sShell.setLayout(gridLayout2);
		gridLayout2.numColumns = 3;
		label.setText("Foo:");
		gridData3.horizontalSpan = 2;
		gridData3.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData3.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData3.grabExcessHorizontalSpace = true;
		gridData3.verticalSpan = 1;
		text.setLayoutData(gridData3);
		text.setText("text");
		button.setText("One");
		gridData4.horizontalSpan = 2;
		gridData4.verticalSpan = 2;
		gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		list.setLayoutData(gridData4);
		button1.setText("Two");
		button2.setText("Three");
		button3.setText("Four");
		button4.setText("Five");
		button4.setLayoutData(gridData5);
		gridData5.horizontalSpan = 2;
		button5.setText("Six");
		gridData6.horizontalSpan = 3;
		progressBar.setLayoutData(gridData6);
		progressBar.setSelection(75);
	}
  }
