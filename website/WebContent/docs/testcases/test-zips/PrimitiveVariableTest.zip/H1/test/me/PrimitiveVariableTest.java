/*
 * Created on Nov 19, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package test.me;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
/**
 * @author sgunturi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PrimitiveVariableTest {
	String text1 = "One", text2="Two";
	final static int prog1=10; // tests FieldDeclaration
	Integer prog2=new Integer(40); // tests FieldDeclaration
	String texttext = "Text field text";
	
	int pi=100;
	float pf=100;
	short ps=100;
	long pl=100;
	double pd=100;
	boolean pb=true;
	char pc='1';
	String pstr="One hundered";
	
	Integer i = new Integer(100);
	Float f = new Float(100);
	Short s = new Short((short)100);
	Long l = new Long(100);
	Double d = new Double(100);
	Boolean b = new Boolean(true);
	Character c = new Character('1');
	String str = new String("One hundered");
	
	private JProgressBar jProgressBar = null;  //  @jve:decl-index=0:visual-constraint="69,90"
	private JProgressBar jProgressBar1 = null;  //  @jve:decl-index=0:visual-constraint="68,127"
	private JTextField jTextField = null;  //  @jve:decl-index=0:visual-constraint="70,187"
	private JLabel jLabel = null;  //  @jve:decl-index=0:visual-constraint="70,221"
	private JLabel jLabel1 = null;  //  @jve:decl-index=0:visual-constraint="70,252"
	private BasicTypes basicTypes = null;  //  @jve:decl-index=0:visual-constraint="143,31"
	/**
	 * This method initializes jProgressBar	
	 * 	
	 * @return javax.swing.JProgressBar	
	 */    
	private JProgressBar getJProgressBar() {
		if (jProgressBar == null) {
			Boolean stringPainted = new Boolean(true); // tests VariableDeclarationStatement
			jProgressBar = new JProgressBar();
			jProgressBar.setSize(216, 28);
			jProgressBar.setString(text1+text2);
			jProgressBar.setStringPainted(stringPainted.booleanValue());
			jProgressBar.setValue(prog1+prog2.intValue());
		}
		return jProgressBar;
	}
	/**
	 * This method initializes jProgressBar1	
	 * 	
	 * @return javax.swing.JProgressBar	
	 */    
	private JProgressBar getJProgressBar1(int value) { // tests SingleVariableDeclaration
		if (jProgressBar1 == null) {
			value=20;
			jProgressBar1 = new JProgressBar();
			jProgressBar1.setSize(219, 32);
			jProgressBar1.setValue(value);
		}
		return jProgressBar1;
	}
	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setSize(220, 30);
			jTextField.setText(texttext);
		}
		return jTextField;
	}
	/**
	 * This method initializes jLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */    
	private JLabel getJLabel() {
		String labelText = "Wrong text ! ERROR";
		if (jLabel == null) {
			labelText = ">>"+jTextField.getText()+":"+BorderLayout.NORTH+":"+text1.toLowerCase()+":"+prog2.intValue();
			jLabel = new JLabel();
			jLabel.setSize(221, 29);
			jLabel.setText(labelText+"<<");
		}
		return jLabel;
	}
	/**
	 * This method initializes jLabel1	
	 * 	
	 * @return javax.swing.JLabel	
	 */    
	private JLabel getJLabel1() {
		if (jLabel1 == null) {
			String tex = jTextField.getText();
			tex = tex.toLowerCase(); // Tests infinite loop evaluation
			jLabel1 = new JLabel();
			jLabel1.setSize(222, 31);
			jLabel1.setText(tex);
		}
		return jLabel1;
	}
	/**
	 * This method initializes basicTypes	
	 * 	
	 * @return test.me.BasicTypes	
	 */    
	private BasicTypes getBasicTypes() {
		if (basicTypes == null) {
			basicTypes = new BasicTypes();
			basicTypes.setBoolean(b);
			basicTypes.setbooleanPrim(pb);
			basicTypes.setCharacter(c);
			basicTypes.setcharPrim(pc);
			basicTypes.setDouble(d);
			basicTypes.setdoublePrim(pd);
			basicTypes.setFloat(f);
			basicTypes.setfloatPrim(pf);
			basicTypes.setInteger(i);
			basicTypes.setintPrim(pi);
			basicTypes.setLong(l);
			basicTypes.setlongPrim(pl);
			basicTypes.setShort(s);
			basicTypes.setshortPrim(ps);
			basicTypes.setString(str);
		}
		return basicTypes;
	}
    }
