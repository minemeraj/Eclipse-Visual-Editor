package answer;
import javax.swing.JPanel;
import javax.swing.event.EventListenerList;

public class AnswerPanel extends JPanel {
	
	 private EventListenerList listenerList = new EventListenerList();
	 
     private javax.swing.JLabel jLabel = null;
     private javax.swing.JTextField jTextField = null;
     private javax.swing.JButton jButton = null;
     
     private String answer = "42";
     
	/**
	 * This method initializes 
	 * 
	 */
	public AnswerPanel() {
		super();
		initialize();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
        this.add(getJLabel(), null);
        this.add(getJTextField(), null);
        this.add(getJButton(), null);
			
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setText("Enter the answer:");
		}
		return jLabel;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField() {
		if(jTextField == null) {
			jTextField = new javax.swing.JTextField();
			jTextField.setColumns(5);
			jTextField.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					checkAnswer();
				}
			});
		}
		return jTextField;
	}
	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton() {
		if(jButton == null) {
			jButton = new javax.swing.JButton();
			jButton.setText("OK");
			jButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {
					checkAnswer();
				}
			});
		}
		return jButton;
	}
	
	private void checkAnswer() {
		String value = getJTextField().getText(); 
		if (value.equals(getAnswer())) {
			fireCorrectAnswer(value);
		} else {
			fireIncorrectAnswer(value);
		}
	}
	
	public void addAnswerListener(AnswerListener l) {
		listenerList.add(AnswerListener.class, l);
	}
	
	public void removeAnswerListener(AnswerListener l) {
		listenerList.remove(AnswerListener.class, l);
	}
	
	private void fireCorrectAnswer(String answer) {
		AnswerEvent e = new AnswerEvent(this, answer);
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==AnswerListener.class) {
			((AnswerListener)listeners[i+1]).answeredCorrectly(e);
			}
		}
	}
	
	private void fireIncorrectAnswer(String answer) {
		AnswerEvent e = new AnswerEvent(this, answer);
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==AnswerListener.class) {
			((AnswerListener)listeners[i+1]).answeredIncorrectly(e);
			}
		}
	}
	/**
	 * @return
	 */
	public String getAnswer() {
		return answer;
	}

	/**
	 * @param string
	 */
	public void setAnswer(String string) {
		String oldval = answer;
		answer = string;
		firePropertyChange("answer", oldval, answer);
		
	}

}  //  @jve:visual-info  decl-index=0 visual-constraint="92,109"
