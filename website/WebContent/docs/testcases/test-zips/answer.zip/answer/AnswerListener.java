package answer;
import java.util.EventListener;

public interface AnswerListener extends EventListener {
	public void answeredCorrectly(AnswerEvent e);
	public void answeredIncorrectly(AnswerEvent e);
}
