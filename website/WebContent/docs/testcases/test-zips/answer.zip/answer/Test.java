package answer;
import javax.swing.JFrame;

public class Test extends JFrame {

     private javax.swing.JPanel jContentPane = null;
     private AnswerPanel answerPanel = null;
     private javax.swing.JLabel jLabel = null;
	/**
	 * This method initializes 
	 * 
	 */
	public Test() {
		super();
		initialize();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
        this.setContentPane(getJContentPane());
        this.setSize(319, 186);
        this.setTitle("What is the answer?");
			
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJContentPane() {
		if(jContentPane == null) {
			jContentPane = new javax.swing.JPanel();
			jContentPane.setLayout(new java.awt.BorderLayout());
			jContentPane.add(getAnswerPanel(), java.awt.BorderLayout.SOUTH);
			jContentPane.add(getJLabel(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}
	/**
	 * This method initializes answerPanel
	 * 
	 * @return AnswerPanel
	 */
	private AnswerPanel getAnswerPanel() {
		if(answerPanel == null) {
			answerPanel = new AnswerPanel();
		}
		return answerPanel;
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			jLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 48));
		}
		return jLabel;
	}
}  //  @jve:visual-info  decl-index=0 visual-constraint="0,0"
