package answer;
public class AnswerAdapter implements AnswerListener {

	/* (non-Javadoc)
	 * @see AnswerListener#answeredCorrectly(AnswerEvent)
	 */
	public void answeredCorrectly(AnswerEvent e) {
	}

	/* (non-Javadoc)
	 * @see AnswerListener#answeredIncorrectly(AnswerEvent)
	 */
	public void answeredIncorrectly(AnswerEvent e) {

	}

}
