/**
 * @author jmyers
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class ConcreteChild extends inheritance.Parent {
     private javax.swing.JLabel jLabel = null;
     private javax.swing.JTree jTree = null;
	public ConcreteChild() {
		super();
		initialize();
	}

	/**
	 * @see Parent#doNothing()
	 */
	public void doNothing() {
	}
	
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
        this.setLeftComponent(getJLabel());
        this.setRightComponent(getJTree());
        this.setSize(340, 123);
        this.setResizeWeight(0.5D);
			
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setText("Left");
			jLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			jLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 24));
			jLabel.setBackground(new java.awt.Color(0,153,102));
			jLabel.setOpaque(true);
			jLabel.setForeground(new java.awt.Color(0,102,153));
		}
		return jLabel;
	}
	/**
	 * This method initializes jTree
	 * 
	 * @return javax.swing.JTree
	 */
	private javax.swing.JTree getJTree() {
		if(jTree == null) {
			jTree = new javax.swing.JTree();
		}
		return jTree;
	}
}  //  @jve:visual-info  decl-index=0 visual-constraint="0,0" 
