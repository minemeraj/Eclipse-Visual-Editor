package inheritance;
/**
 * @author jmyers
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public abstract class AbstractChild extends Parent {
	
	protected int protectedInt;
	private int privateInt;
	public int publicInt;

	/**
	 * Returns the privateInt.
	 * @return int
	 */
	private int getPrivateInt() {
		return privateInt;
	}

	/**
	 * Returns the protectedInt.
	 * @return int
	 */
	protected int getProtectedInt() {
		return protectedInt;
	}

	/**
	 * Returns the publicInt.
	 * @return int
	 */
	public int getPublicInt() {
		return publicInt;
	}

	/**
	 * Sets the privateInt.
	 * @param privateInt The privateInt to set
	 */
	private void setPrivateInt(int privateInt) {
		this.privateInt = privateInt;
	}

	/**
	 * Sets the protectedInt.
	 * @param protectedInt The protectedInt to set
	 */
	protected void setProtectedInt(int protectedInt) {
		this.protectedInt = protectedInt;
	}

	/**
	 * Sets the publicInt.
	 * @param publicInt The publicInt to set
	 */
	public void setPublicInt(int publicInt) {
		this.publicInt = publicInt;
	}

}
