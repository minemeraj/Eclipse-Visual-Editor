package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class NameWriter {

// Run main to write a serialized Name instance out to the file system.
// The Name.ser file winds up in project_resources/IBM Java Examples
	
/**
 * Starts the application.
 * @param args java.lang.String[] An array of command line arguments
 */
public static void main(java.lang.String[] args) {
	Name thisName = null;
	java.io.FileOutputStream thisFile = null;
	java.io.ObjectOutputStream thisObjStream = null;
	try {
		thisName = new Name();
		thisFile = new java.io.FileOutputStream("Name.ser");
		thisObjStream = new java.io.ObjectOutputStream(thisFile);
		thisName.setTitle("Mrs.");
		thisName.setFirst("Susan");
		thisName.setMiddle("Gail");
		thisName.setLast("Carpenter");
		thisObjStream.writeObject(thisName);
		thisObjStream.close();
	} catch (Throwable exception) {
		System.err.println("Exception..." + exception);
	}
}	
}
