package com.ibm.ivj.examples.vc.swing.directoryexplorer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import javax.swing.tree.*;
import java.io.*;
/**
 * This type was created in VisualAge.
 */
public class DirectoryTreeModel extends DefaultTreeModel {
/**
 * DirectoryTreeModel constructor comment.
 * @param root javax.swing.tree.TreeNode
 */
public DirectoryTreeModel() {
	super(new DefaultMutableTreeNode(new DirectoryData("c:\\")));
	loadChildren((DefaultMutableTreeNode) getRoot());	
}
/**
 * DirectoryTreeModel constructor comment.
 * @param root javax.swing.tree.TreeNode
 * @param asksAllowsChildren boolean
 */
public DirectoryTreeModel(java.lang.String directoryName) {
	super(new DefaultMutableTreeNode(new File(directoryName), true));
}
/**
 * This method was created in VisualAge.
 * @return int
 * @param parent java.lang.Object
 */
public int getChildCount(Object parent) {
	
	int childrenInTree = ((TreeNode)parent).getChildCount();

	// If there are no children already added for the parent,
	// then this is the first time that the children were
	// requested and we should add the childen in at this point.
	if (childrenInTree == 0)
		loadChildren((TreeNode)parent);

	return ((TreeNode)parent).getChildCount();
}
/**
 * This method was created in VisualAge.
 * @return boolean
 * @param node java.lang.Object
 */
public boolean isLeaf(Object node) {
	DefaultMutableTreeNode dNode = (DefaultMutableTreeNode) node;
	DirectoryData dirData = (DirectoryData) dNode.getUserObject();
	return (!dirData.getHasChildDirectories());
}
/**
 * This method was created in VisualAge.
 * @param node javax.swing.tree.TreeNode
 */
public void loadChildren(TreeNode node) {
	
	if (node != null) {
		System.out.println("Load children: " + node);
		// Re-read the directory structure from <node> down and
		// reconstruct the tree nodes for the directories.
		DefaultMutableTreeNode dNode = (DefaultMutableTreeNode) node;
		DirectoryData parentDirData = (DirectoryData) dNode.getUserObject();
		File parentFile = parentDirData.getFileObject();
		boolean isDirectory = false;

		if (dNode.equals((DefaultMutableTreeNode)getRoot())){
			isDirectory = true;
		}else{
			isDirectory = parentFile.isDirectory();
		}
		
		
		if (isDirectory) {
			String[] files = parentFile.list();
			int childIndex = 0;
			for (int i=0; i < files.length; i++) {
				File newFile = new File(parentFile.getPath() + File.separator + files[i]);

				// Only add directories to the tree
				if (newFile.isDirectory()) {
					DefaultMutableTreeNode newNode = 
						new DefaultMutableTreeNode(new DirectoryData(newFile));
					dNode.insert(newNode, childIndex++);
				}
			}
		}
	}			
}
}
