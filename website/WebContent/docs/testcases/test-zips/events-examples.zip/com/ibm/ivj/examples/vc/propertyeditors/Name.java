package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class Name implements java.io.Serializable {
	private String fieldTitle = "";
	protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
	private String fieldFirst = "";
	private String fieldMiddle = "";
	private String fieldLast = "";
/**
 * Name constructor comment.
 */
public Name() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param firstName java.lang.String
 * @param lastName java.lang.String
 */
public Name(String firstName, String lastName) {
	this();
	setFirst(firstName);
	setLast(lastName);
}
/**
 * This method was created in VisualAge.
 * @param title java.lang.String
 * @param firstName java.lang.String
 * @param middleName java.lang.String
 * @param lastName java.lang.String
 */
public Name(String title, String firstName, String middleName, String lastName) {
	this ();
	setTitle(title);
	setFirst(firstName);
	setMiddle(middleName);
	setLast(lastName);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	getPropertyChangeSupport().addPropertyChangeListener(arg1);
}
/**
 * Compares two objects for equality. Returns a boolean that indicates
 * whether this object is equivalent to the specified object. This method
 * is used when an object is stored in a hashtable.
 * @param obj the Object to compare with
 * @return true if these Objects are equal; false otherwise.
 * @see java.util.Hashtable
 */
public boolean equals(Object obj) {
	// insert code to compare the receiver and #obj here
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: #obj might be an instance of any class
	return (toString() == obj.toString());
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String arg1, Object arg2, Object arg3) {
	getPropertyChangeSupport().firePropertyChange(arg1, arg2, arg3);
}
/**
 * Gets the first property (java.lang.String) value.
 * @return The first property value.
 * @see #setFirst
 */
public String getFirst() {
	return fieldFirst;
}
/**
 * Gets the last property (java.lang.String) value.
 * @return The last property value.
 * @see #setLast
 */
public String getLast() {
	return fieldLast;
}
/**
 * Gets the middle property (java.lang.String) value.
 * @return The middle property value.
 * @see #setMiddle
 */
public String getMiddle() {
	return fieldMiddle;
}
/**
 * This method was created in VisualAge.
 * @return java.beans.PropertyChangeSupport
 */
public java.beans.PropertyChangeSupport getPropertyChangeSupport() {
	if (propertyChange == null)
		propertyChange = new java.beans.PropertyChangeSupport(this);
	return propertyChange;
}
/**
 * Gets the title property (java.lang.String) value.
 * @return The title property value.
 * @see #setTitle
 */
public String getTitle() {
	return fieldTitle;
}
/**
 * Gets the valueAsString property (java.lang.String) value.
 * @return The valueAsString property value.
 */
public String getValueAsString() {
	return toString();
}
/**
 * Generates a hash code for the receiver.
 * This method is supported primarily for
 * hash tables, such as those provided in java.util.
 * @return an integer hash code for the receiver
 * @see java.util.Hashtable
 */
public int hashCode() {
	// insert code to generate a hash code for the receiver here
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: if two objects are equal (equals(Object) returns true) they must have the same hash code
	return super.hashCode();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	getPropertyChangeSupport().removePropertyChangeListener(arg1);
}
/**
 * Sets the first property (java.lang.String) value.
 * @param first The new value for the property.
 * @see #getFirst
 */
public void setFirst(String first) {
	String oldValue = fieldFirst;
	fieldFirst = first;
	firePropertyChange("first", oldValue, first);
}
/**
 * Sets the last property (java.lang.String) value.
 * @param last The new value for the property.
 * @see #getLast
 */
public void setLast(String last) {
	String oldValue = fieldLast;
	fieldLast = last;
	firePropertyChange("last", oldValue, last);
}
/**
 * Sets the middle property (java.lang.String) value.
 * @param middle The new value for the property.
 * @see #getMiddle
 */
public void setMiddle(String middle) {
	String oldValue = fieldMiddle;
	fieldMiddle = middle;
	firePropertyChange("middle", oldValue, middle);
}
/**
 * Sets the title property (java.lang.String) value.
 * @param title The new value for the property.
 * @see #getTitle
 */
public void setTitle(String title) {
	String oldValue = fieldTitle;
	fieldTitle = title;
	firePropertyChange("title", oldValue, title);
}
/**
 * Returns a String that represents the value of this object.
 */
public String toString() {
	
	return (
	  ( getTitle() != null ? (getTitle() + " ") : "" ) + 
	  ( getFirst() != null ? (getFirst() + " ") : "" ) +
	  ( getMiddle() != null ? (getMiddle() + " ") : "" ) +
	  ( getLast() != null ? getLast() : "" )
	);  
}
}
