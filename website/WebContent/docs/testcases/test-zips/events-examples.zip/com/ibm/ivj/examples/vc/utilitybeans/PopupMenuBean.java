package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * PopupMenuBean
 *
 * This bean subclasses java.awt.PopupMenu to make visual composition of parts that need popup menus
 * easier.  It provides a show method that takes a java.awt.event.MouseEvent parameter that contains
 * information about which mouse button was used and which component requested the popup.  By using 
 * this method, you can simply connect the MouseReleased event of any Component directly to the PopupMenu.
 * The show method checks that the correct mouse button was used to trigger the popup and then adds the
 * popup to the component and calls the show(Component, x, y) method on the popup.
 * 
 * The component to which the popup was added is then accessible through a property called ownerComponent.
 * When one popup menu is used for multiple components, this property can be used as the target of the 
 * MenuItem(ActionPerformed) connection to mean whichever component the popup was displayed over.
 *
 * This class was created using the Visual Age for Java 
 * Integrated Development Environment using the following steps:
 * 
 *  1) From the WorkBench, create a new class called PopupMenuBean with a superclass of
 *			java.awt.PopupMenu
 *  2) Open the class and select the BeanInfo tab.
 *  3) Press the New Property Feature button on the toolbar and create
 * 		a new read/write, Bound property named ownerComponent, superclass java.awt.Component.
 *  		This property represents the component from which the popup menu was triggered.
 *  4) Press the New Method Feature button on the toolbar to create the new show method named show
 * 		that returns void with one parameter named mouseEvent, superclass java.awt.event.MouseEvent.
 *  5) Select the Methods tab, then select the show method and enter the body of the new function:
 *
 *				if (mouseEvent != null && mouseEvent.isPopupTrigger())
 *				{
 *					java.awt.Component popupOwner = mouseEvent.getComponent();
 *					if (popupOwner != null)
 *					{
 *						setOwnerComponent(popupOwner);
 *						popupOwner.add(this);
 *						show(popupOwner, mouseEvent.getX(), mouseEvent.getY());
 *					}
 *				}
 *
 *			Save the method. 
 * 
 */
public class PopupMenuBean extends java.awt.PopupMenu {
private java.awt.Component fieldOwnerComponent = null;
protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
/**
 * PopupMenuBean constructor comment.
 */
public PopupMenuBean() {
	super();
}
/**
 * PopupMenuBean constructor comment.
 * @param label java.lang.String
 */
public PopupMenuBean(java.lang.String label) {
	super(label);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	propertyChange.addPropertyChangeListener(arg1);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String arg1, Object arg2, Object arg3) {
	propertyChange.firePropertyChange(arg1, arg2, arg3);
}
/**
 * Gets the ownerComponentproperty (java.awt.Component) value.
 * @return The ownerComponent property value.
 * @see #setOwnerComponent
 */
public java.awt.Component getOwnerComponent() {
	/* Returns the ownerComponentproperty value. */
	return fieldOwnerComponent;
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	propertyChange.removePropertyChangeListener(arg1);
}
/**
 * Sets the ownerComponent property (java.awt.Component) value.
 * @param ownerComponent The new value for the property.
 * @see #getOwnerComponent
 */
public void setOwnerComponent(java.awt.Component ownerComponent) {
	/* Get the old property value for fire property change event. */
	java.awt.Component oldValue = fieldOwnerComponent;
	/* Set the ownerComponentproperty to the new value. */
	fieldOwnerComponent = ownerComponent;
	/* Fire (signal/notify) the ownerComponentproperty change event. */
	firePropertyChange("ownerComponent", oldValue, ownerComponent);
	return;
}
/**
 * Performs the show method.
 * @param e java.awt.event.MouseEvent
 */
public void show(java.awt.event.MouseEvent e) {
	/* Perform the show method. */
	if (e != null && e.isPopupTrigger())
	{
		java.awt.Component popupOwner = e.getComponent();
		if (popupOwner != null)
		{
			setOwnerComponent(popupOwner);
			popupOwner.add(this);
			show(popupOwner, e.getX(), e.getY());
		}
	}
}
}
