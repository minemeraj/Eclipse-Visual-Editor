package com.ibm.ivj.examples.vc.swing.directoryexplorer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import java.io.File;
import java.util.Vector;
/**
 * This type was created in VisualAge.
 */
public class FileTableModel extends javax.swing.table.AbstractTableModel {
	private java.io.File directory = null;
	private Vector files = new Vector(0);
	private String columnNames[] = {"Name", "Size", "Modified" };	
/**
 * FileTableModel constructor comment.
 */
public FileTableModel() {
	super();
}
/**
 * getColumnCount method comment.
 */
public int getColumnCount() {
	return columnNames.length;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param column int
 */
public java.lang.String getColumnName(int column) {
	return columnNames[column];
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public java.lang.String getDirectory() {
	return directory.getPath();
}
/**
 * getRowCount method comment.
 */
public int getRowCount() {
	return files.size();
}
/**
 * getValueAt method comment.
 */
public Object getValueAt(int row, int col) {
	File rowFile = (File) files.elementAt(row);
	String ret = "";
	switch (col) {
		case 0:
			// Column 0 is the filename
			ret = rowFile.getName();
			break;
		case 1:
			// Column 1 is the file size
			ret = String.valueOf(rowFile.length() / 1000) + "KB";
			break;
		case 2:
			// Column 2 is the modified date
			ret = (new java.sql.Date(rowFile.lastModified())).toString();
			break;
	}
	return ret;	
}
/**
 * This method was created in VisualAge.
 * @param dir java.lang.String
 */
public void setDirectory(java.lang.String dir) {
	directory = new File(dir);
	String[] filesAndDirs = directory.list();
	String fileDir = getDirectory() + File.separator;

	// Refresh the files list for the new directory.
	// Do not add directories to the list of files.
	files = new Vector();
	for (int i=0; i < filesAndDirs.length; i++) {
		File f = new File(fileDir + filesAndDirs[i]);
		if (f.isFile())
			files.addElement(f);
	}
	fireTableDataChanged();	
}
}
