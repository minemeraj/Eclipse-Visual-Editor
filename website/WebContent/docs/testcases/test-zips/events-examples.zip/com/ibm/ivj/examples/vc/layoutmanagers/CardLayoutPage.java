package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class CardLayoutPage extends java.awt.Panel {
	private java.awt.Label ivjLabel1 = null;
	private java.awt.TextArea ivjTextArea1 = null;
/**
 * Constructor
 */
public CardLayoutPage() {
	super();
	initialize();
}
/**
 * CardLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public CardLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("");
			ivjLabel1.setBackground(java.awt.Color.cyan);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the TextArea1 property value.
 * @return java.awt.TextArea
 */
private java.awt.TextArea getTextArea1() {
	if (ivjTextArea1 == null) {
		try {
			ivjTextArea1 = new java.awt.TextArea();
			ivjTextArea1.setName("TextArea1");
			ivjTextArea1.setText("This entire notebook is implemented using a CardLayout.\nAs you click on the tabs (which are labels in a GridLayout)\na different component of the CardLayout is shown.");
			ivjTextArea1.setBackground(java.awt.Color.white);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextArea1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("CardLayoutPage");
		setLayout(new java.awt.BorderLayout());
		setBackground(java.awt.Color.cyan);
		setSize(426, 240);
		add(getLabel1(), "North");
		add(getTextArea1(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.CardLayoutPage aCardLayoutPage;
		aCardLayoutPage = new com.ibm.ivj.examples.vc.layoutmanagers.CardLayoutPage();
		frame.add("Center", aCardLayoutPage);
		frame.setSize(aCardLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
