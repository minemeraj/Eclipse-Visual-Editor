package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class LayoutManagers extends java.applet.Applet implements java.awt.event.ActionListener, java.awt.event.MouseListener, java.beans.PropertyChangeListener {
	private BorderLayoutPage ivjBorderLayoutPage1 = null;
	private java.awt.Button ivjButton1 = null;
	private java.awt.Button ivjButton2 = null;
	private java.awt.Button ivjButton3 = null;
	private java.awt.Button ivjButton4 = null;
	private java.awt.CardLayout ivjCardLayout1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="481,461"
	private CardLayoutPage ivjCardLayoutPage1 = null;
	private FlowLayoutPage ivjFlowLayoutPage1 = null;
	private GridBagLayoutPage ivjGridBagLayoutPage1 = null;
	private GridLayoutPage ivjGridLayoutPage1 = null;
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.Label ivjLabel6 = null;
	private NullLayoutPage ivjNullLayoutPage1 = null;
	private java.awt.Panel ivjPanel1 = null;
	private java.awt.Panel ivjPanel2 = null;
	private java.awt.Panel ivjPanel3 = null;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private boolean ivjConnPtoP5Aligning = false;
	private boolean ivjConnPtoP6Aligning = false;
	private boolean ivjConnPtoP7Aligning = false;
/**
 * LayoutManagers constructor comment.
 */
public LayoutManagers() {
	super();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getButton1()) 
		connEtoM7(e);
	if (e.getSource() == getButton2()) 
		connEtoM8(e);
	if (e.getSource() == getButton3()) 
		connEtoM9(e);
	if (e.getSource() == getButton4()) 
		connEtoM10(e);
}
/**
 * connEtoM1:  (Label1.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM1(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getNullLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM10:  (Button4.action.actionPerformed(java.awt.event.ActionEvent) --> CardLayout1.last(Ljava.awt.Container;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM10(java.awt.event.ActionEvent arg1) {
	try {
		getCardLayout1().last(getPanel3());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (Label2.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM2(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getFlowLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (Label3.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM3(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getBorderLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (Label4.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM4(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getGridLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (Label5.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM5(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getGridBagLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (Label6.mouse.mouseClicked(java.awt.event.MouseEvent) --> CardLayout1.show(Ljava.awt.Container;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM6(java.awt.event.MouseEvent arg1) {
	try {
		getCardLayout1().show(getPanel3(), getCardLayoutPage1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> CardLayout1.first(Ljava.awt.Container;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM7(java.awt.event.ActionEvent arg1) {
	try {
		getCardLayout1().first(getPanel3());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (Button2.action.actionPerformed(java.awt.event.ActionEvent) --> CardLayout1.previous(Ljava.awt.Container;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM8(java.awt.event.ActionEvent arg1) {
	try {
		getCardLayout1().previous(getPanel3());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  (Button3.action.actionPerformed(java.awt.event.ActionEvent) --> CardLayout1.next(Ljava.awt.Container;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM9(java.awt.event.ActionEvent arg1) {
	try {
		getCardLayout1().next(getPanel3());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetSource:  (Panel3.layout <--> CardLayout1.this)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if ((getCardLayout1() != null)) {
			getPanel3().setLayout(getCardLayout1());
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (Panel3.layout <--> CardLayout1.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		setCardLayout1((java.awt.CardLayout)getPanel3().getLayout());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (NullLayoutPage1.background <--> Label1.background)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getNullLayoutPage1().setBackground(getLabel1().getBackground());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (NullLayoutPage1.background <--> Label1.background)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getLabel1().setBackground(getNullLayoutPage1().getBackground());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (FlowLayoutPage1.background <--> Label2.background)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getFlowLayoutPage1().setBackground(getLabel2().getBackground());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (FlowLayoutPage1.background <--> Label2.background)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getLabel2().setBackground(getFlowLayoutPage1().getBackground());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (BorderLayoutPage1.background <--> Label3.background)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getBorderLayoutPage1().setBackground(getLabel3().getBackground());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (BorderLayoutPage1.background <--> Label3.background)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getLabel3().setBackground(getBorderLayoutPage1().getBackground());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (GridLayoutPage1.background <--> Label4.background)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getGridLayoutPage1().setBackground(getLabel4().getBackground());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (GridLayoutPage1.background <--> Label4.background)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getLabel4().setBackground(getGridLayoutPage1().getBackground());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetSource:  (GridBagLayoutPage1.background <--> Label5.background)
 */
private void connPtoP6SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getGridBagLayoutPage1().setBackground(getLabel5().getBackground());
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetTarget:  (GridBagLayoutPage1.background <--> Label5.background)
 */
private void connPtoP6SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getLabel5().setBackground(getGridBagLayoutPage1().getBackground());
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP7SetSource:  (CardLayoutPage1.background <--> Label6.background)
 */
private void connPtoP7SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP7Aligning == false) {
			ivjConnPtoP7Aligning = true;
			getCardLayoutPage1().setBackground(getLabel6().getBackground());
			ivjConnPtoP7Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP7Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP7SetTarget:  (CardLayoutPage1.background <--> Label6.background)
 */
private void connPtoP7SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP7Aligning == false) {
			ivjConnPtoP7Aligning = true;
			getLabel6().setBackground(getCardLayoutPage1().getBackground());
			ivjConnPtoP7Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP7Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.layoutmanagers.LayoutManagers created using VisualAge for Java.";
}
/**
 * Return the BorderLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.BorderLayoutPage
 */
private BorderLayoutPage getBorderLayoutPage1() {
	if (ivjBorderLayoutPage1 == null) {
		try {
			ivjBorderLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.BorderLayoutPage();
			ivjBorderLayoutPage1.setName("BorderLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjBorderLayoutPage1;
}
/**
 * Return the Button1 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton1() {
	if (ivjButton1 == null) {
		try {
			ivjButton1 = new java.awt.Button();
			ivjButton1.setName("Button1");
			ivjButton1.setLabel("|<");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton1;
}
/**
 * Return the Button2 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton2() {
	if (ivjButton2 == null) {
		try {
			ivjButton2 = new java.awt.Button();
			ivjButton2.setName("Button2");
			ivjButton2.setLabel("<");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton2;
}
/**
 * Return the Button3 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton3() {
	if (ivjButton3 == null) {
		try {
			ivjButton3 = new java.awt.Button();
			ivjButton3.setName("Button3");
			ivjButton3.setLabel(">");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton3;
}
/**
 * Return the Button4 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton4() {
	if (ivjButton4 == null) {
		try {
			ivjButton4 = new java.awt.Button();
			ivjButton4.setName("Button4");
			ivjButton4.setLabel(">|");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton4;
}
/**
 * Return the CardLayout1 property value.
 * @return java.awt.CardLayout
 */
private java.awt.CardLayout getCardLayout1() {
	return ivjCardLayout1;
}
/**
 * Return the CardLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.CardLayoutPage
 */
private CardLayoutPage getCardLayoutPage1() {
	if (ivjCardLayoutPage1 == null) {
		try {
			ivjCardLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.CardLayoutPage();
			ivjCardLayoutPage1.setName("CardLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCardLayoutPage1;
}
/**
 * Return the FlowLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.FlowLayoutPage
 */
private FlowLayoutPage getFlowLayoutPage1() {
	if (ivjFlowLayoutPage1 == null) {
		try {
			ivjFlowLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.FlowLayoutPage();
			ivjFlowLayoutPage1.setName("FlowLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjFlowLayoutPage1;
}
/**
 * Return the GridBagLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.GridBagLayoutPage
 */
private GridBagLayoutPage getGridBagLayoutPage1() {
	if (ivjGridBagLayoutPage1 == null) {
		try {
			ivjGridBagLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.GridBagLayoutPage();
			ivjGridBagLayoutPage1.setName("GridBagLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGridBagLayoutPage1;
}
/**
 * Return the GridLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.GridLayoutPage
 */
private GridLayoutPage getGridLayoutPage1() {
	if (ivjGridLayoutPage1 == null) {
		try {
			ivjGridLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.GridLayoutPage();
			ivjGridLayoutPage1.setName("GridLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGridLayoutPage1;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("LayoutManagers");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("FlowLayout");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("BorderLayout");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("GridLayout");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setText("GridBagLayout");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setText("CardLayout");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel6;
}
/**
 * Return the NullLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.layoutmanagers.NullLayoutPage
 */
private NullLayoutPage getNullLayoutPage1() {
	if (ivjNullLayoutPage1 == null) {
		try {
			ivjNullLayoutPage1 = new com.ibm.ivj.examples.vc.layoutmanagers.NullLayoutPage();
			ivjNullLayoutPage1.setName("NullLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjNullLayoutPage1;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(new java.awt.GridLayout());
			ivjPanel1.add(getLabel1());
			getPanel1().add(getLabel2(), getLabel2().getName());
			getPanel1().add(getLabel3(), getLabel3().getName());
			getPanel1().add(getLabel4(), getLabel4().getName());
			getPanel1().add(getLabel5(), getLabel5().getName());
			getPanel1().add(getLabel6(), getLabel6().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the Panel2 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel2() {
	if (ivjPanel2 == null) {
		try {
			ivjPanel2 = new java.awt.Panel();
			ivjPanel2.setName("Panel2");
			ivjPanel2.setLayout(new java.awt.GridBagLayout());

			java.awt.GridBagConstraints constraintsButton1 = new java.awt.GridBagConstraints();
			constraintsButton1.gridx = 0; constraintsButton1.gridy = 0;
			constraintsButton1.anchor = java.awt.GridBagConstraints.EAST;
			constraintsButton1.weightx = 1.0;
			getPanel2().add(getButton1(), constraintsButton1);

			java.awt.GridBagConstraints constraintsButton2 = new java.awt.GridBagConstraints();
			constraintsButton2.gridx = 1; constraintsButton2.gridy = 0;
			getPanel2().add(getButton2(), constraintsButton2);

			java.awt.GridBagConstraints constraintsButton3 = new java.awt.GridBagConstraints();
			constraintsButton3.gridx = 2; constraintsButton3.gridy = 0;
			getPanel2().add(getButton3(), constraintsButton3);

			java.awt.GridBagConstraints constraintsButton4 = new java.awt.GridBagConstraints();
			constraintsButton4.gridx = 3; constraintsButton4.gridy = 0;
			getPanel2().add(getButton4(), constraintsButton4);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel2;
}
/**
 * Return the Panel3 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel3() {
	if (ivjPanel3 == null) {
		try {
			ivjPanel3 = new java.awt.Panel();
			ivjPanel3.setName("Panel3");
			ivjPanel3.setLayout(new java.awt.CardLayout());
			getPanel3().add(getNullLayoutPage1(), getNullLayoutPage1().getName());
			getPanel3().add(getFlowLayoutPage1(), getFlowLayoutPage1().getName());
			getPanel3().add(getBorderLayoutPage1(), getBorderLayoutPage1().getName());
			getPanel3().add(getGridLayoutPage1(), getGridLayoutPage1().getName());
			getPanel3().add(getGridBagLayoutPage1(), getGridBagLayoutPage1().getName());
			getPanel3().add(getCardLayoutPage1(), getCardLayoutPage1().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel3;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		super.init();
		setName("LayoutManagers");
		setLayout(new java.awt.BorderLayout());
		setSize(800, 400);
		add(getPanel1(), "North");
		add(getPanel2(), "South");
		add(getPanel3(), "Center");
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getNullLayoutPage1().addPropertyChangeListener(this);
	getLabel1().addPropertyChangeListener(this);
	getFlowLayoutPage1().addPropertyChangeListener(this);
	getLabel2().addPropertyChangeListener(this);
	getBorderLayoutPage1().addPropertyChangeListener(this);
	getLabel3().addPropertyChangeListener(this);
	getGridLayoutPage1().addPropertyChangeListener(this);
	getLabel4().addPropertyChangeListener(this);
	getGridBagLayoutPage1().addPropertyChangeListener(this);
	getLabel5().addPropertyChangeListener(this);
	getCardLayoutPage1().addPropertyChangeListener(this);
	getLabel6().addPropertyChangeListener(this);
	getLabel1().addMouseListener(this);
	getLabel2().addMouseListener(this);
	getLabel3().addMouseListener(this);
	getLabel4().addMouseListener(this);
	getLabel5().addMouseListener(this);
	getLabel6().addMouseListener(this);
	getButton1().addActionListener(this);
	getButton2().addActionListener(this);
	getButton3().addActionListener(this);
	getButton4().addActionListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP6SetTarget();
	connPtoP7SetTarget();
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.LayoutManagers aLayoutManagers;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.layoutmanagers.LayoutManagers");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aLayoutManagers = (com.ibm.ivj.examples.vc.layoutmanagers.LayoutManagers)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.layoutmanagers.LayoutManagers");
		frame.add("Center", aLayoutManagers);
		frame.setSize(aLayoutManagers.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
	if (e.getSource() == getLabel1()) 
		connEtoM1(e);
	if (e.getSource() == getLabel2()) 
		connEtoM2(e);
	if (e.getSource() == getLabel3()) 
		connEtoM3(e);
	if (e.getSource() == getLabel4()) 
		connEtoM4(e);
	if (e.getSource() == getLabel5()) 
		connEtoM5(e);
	if (e.getSource() == getLabel6()) 
		connEtoM6(e);
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getNullLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP2SetTarget();
	if (evt.getSource() == getLabel1() && (evt.getPropertyName().equals("background"))) 
		connPtoP2SetSource();
	if (evt.getSource() == getFlowLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP3SetTarget();
	if (evt.getSource() == getLabel2() && (evt.getPropertyName().equals("background"))) 
		connPtoP3SetSource();
	if (evt.getSource() == getBorderLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP4SetTarget();
	if (evt.getSource() == getLabel3() && (evt.getPropertyName().equals("background"))) 
		connPtoP4SetSource();
	if (evt.getSource() == getGridLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP5SetTarget();
	if (evt.getSource() == getLabel4() && (evt.getPropertyName().equals("background"))) 
		connPtoP5SetSource();
	if (evt.getSource() == getGridBagLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP6SetTarget();
	if (evt.getSource() == getLabel5() && (evt.getPropertyName().equals("background"))) 
		connPtoP6SetSource();
	if (evt.getSource() == getCardLayoutPage1() && (evt.getPropertyName().equals("background"))) 
		connPtoP7SetTarget();
	if (evt.getSource() == getLabel6() && (evt.getPropertyName().equals("background"))) 
		connPtoP7SetSource();
}
/**
 * Set the CardLayout1 to a new value.
 * @param newValue java.awt.CardLayout
 */
private void setCardLayout1(java.awt.CardLayout newValue) {
	if (ivjCardLayout1 != newValue) {
		try {
			ivjCardLayout1 = newValue;
			connPtoP1SetSource();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
