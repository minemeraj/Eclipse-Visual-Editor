package com.ibm.ivj.examples.vc.mortgageamortizer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class Amortization extends java.applet.Applet implements java.awt.event.ActionListener, java.awt.event.MouseListener, java.awt.event.TextListener, java.beans.PropertyChangeListener {
	private java.awt.Button ivjButton1 = null;
	private CompoundInterest ivjCompoundInterest1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="417,515"
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private boolean ivjConnPtoP5Aligning = false;
	private java.text.NumberFormat ivjCurrencyFormatter = null;  // @jve:visual-info  decl-index=0 visual-constraint="843,185"
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel10 = null;
	private java.awt.Label ivjLabel11 = null;
	private java.awt.Label ivjLabel12 = null;
	private java.awt.Label ivjLabel13 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.Label ivjLabel6 = null;
	private java.awt.Label ivjLabel7 = null;
	private java.awt.Label ivjLabel8 = null;
	private java.awt.Label ivjLabel9 = null;
	private java.awt.List ivjList1 = null;
	private java.awt.MenuItem ivjMenuItem1 = null;
	private java.awt.MenuItem ivjMenuItem2 = null;
	private java.awt.Panel ivjPanel1 = null;
	private java.text.NumberFormat ivjPercentFormatter = null;  // @jve:visual-info  decl-index=0 visual-constraint="738,93"
	private java.awt.PopupMenu ivjPopupMenu1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="754,398"
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
	private java.awt.TextField ivjTextField4 = null;
	private java.awt.TextField ivjTextField5 = null;
/**
 * AmortizationS1 constructor comment.
 */
public Amortization() {
	super();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getButton1()) 
		connEtoM2(e);
	if (e.getSource() == getButton1()) 
		connEtoM1(e);
	if (e.getSource() == getButton1()) 
		connEtoM3(e);
	if (e.getSource() == getButton1()) 
		connEtoM4(e);
	if (e.getSource() == getMenuItem1()) 
		connEtoM11(e);
	if (e.getSource() == getMenuItem2()) 
		connEtoM12(e);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public static String amortizationHeading() {
	/* Perform the amortizationHeading method. */
	final String[] heading = {"Principal", "Years", "Rate", "#/Yr", "X/Yr", "Payment", "EAR", "Total Int."};
	return formatRecord(heading);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param compoundInterest com.ibm.ivj.examples.vc.mortgageamortizer.CompoundInterest
 */
public String amortizationRecord(CompoundInterest compoundInterest) {

	String[] record = new String[8];
	java.text.NumberFormat integerFormatter = java.text.NumberFormat.getNumberInstance();
	integerFormatter.setMaximumFractionDigits(0);
	integerFormatter.setMinimumFractionDigits(0);
				
	record[0] = getCurrencyFormatter().format(compoundInterest.getPrincipalAmount());
	record[1] = integerFormatter.format(compoundInterest.getAmortizationPeriod());
	record[2] = getPercentFormatter().format(compoundInterest.getInterestRate());
	record[3] = integerFormatter.format(compoundInterest.getPaymentsPerYear());
	record[4] = integerFormatter.format(compoundInterest.getTimesPerYear());
	record[5] = getCurrencyFormatter().format(compoundInterest.getPaymentAmount());
	record[6] = getPercentFormatter().format(compoundInterest.getEffectiveAnnualRate());
	record[7] = getCurrencyFormatter().format(compoundInterest.getTotalInterestCost());
	return formatRecord(record);

}
/**
 * connEtoC1:  (List1.mouse.mouseReleased(java.awt.event.MouseEvent) --> AmortizationS1.genericPopupDisplay(Ljava.awt.event.MouseEvent;Ljava.awt.PopupMenu;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoC1(java.awt.event.MouseEvent arg1) {
	try {
		this.genericPopupDisplay(arg1, getPopupMenu1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> Label10.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		if ((getCurrencyFormatter() != null)) {
			getLabel10().setText(getCurrencyFormatter().format(getCompoundInterest1().getPaymentAmount()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM10:  (AmortizationS1.init() --> Label13.text)
 */
private void connEtoM10() {
	try {
		getLabel13().setText(com.ibm.ivj.examples.vc.mortgageamortizer.Amortization.amortizationHeading());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM11:  (MenuItem1.action.actionPerformed(java.awt.event.ActionEvent) --> List1.remove(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM11(java.awt.event.ActionEvent arg1) {
	try {
		getList1().remove(getList1().getSelectedIndex());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM12:  (MenuItem2.action.actionPerformed(java.awt.event.ActionEvent) --> List1.removeAll()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM12(java.awt.event.ActionEvent arg1) {
	try {
		getList1().removeAll();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM13:  ( (AmortizationS1,init() --> CurrencyFormatter,getCurrencyInstance()Ljava.text.NumberFormat;).normalResult --> CurrencyFormatter.this)
 * @param result java.text.NumberFormat
 */
private void connEtoM13(java.text.NumberFormat result) {
	try {
		setCurrencyFormatter(result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> Label11.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		if ((getPercentFormatter() != null)) {
			getLabel11().setText(getPercentFormatter().format(getCompoundInterest1().getEffectiveAnnualRate()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> Label12.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		if ((getCurrencyFormatter() != null)) {
			getLabel12().setText(getCurrencyFormatter().format(getCompoundInterest1().getTotalInterestCost()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> List1.add(Ljava.lang.String;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		getList1().add(this.amortizationRecord(getCompoundInterest1()));
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (AmortizationS1.init() --> PercentFormatter.getPercentInstance()Ljava.text.NumberFormat;)
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat connEtoM5() {
	java.text.NumberFormat connEtoM5Result = null;
	try {
		connEtoM5Result = java.text.NumberFormat.getPercentInstance();
		connEtoM7(connEtoM5Result);
		connEtoM8(connEtoM5Result);
		connEtoM9(connEtoM5Result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	return connEtoM5Result;
}
/**
 * connEtoM6:  (AmortizationS1.init() --> CurrencyFormatter.getCurrencyInstance()Ljava.text.NumberFormat;)
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat connEtoM6() {
	java.text.NumberFormat connEtoM6Result = null;
	try {
		connEtoM6Result = java.text.NumberFormat.getCurrencyInstance();
		connEtoM13(connEtoM6Result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	return connEtoM6Result;
}
/**
 * connEtoM7:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.this)
 * @param result java.text.NumberFormat
 */
private void connEtoM7(java.text.NumberFormat result) {
	try {
		setPercentFormatter(result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.setMinimumFractionDigits(I)V)
 * @param result java.text.NumberFormat
 */
private void connEtoM8(java.text.NumberFormat result) {
	try {
		getPercentFormatter().setMinimumFractionDigits(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.setMinimumFractionDigits(I)V)
 * @param result java.text.NumberFormat
 */
private void connEtoM9(java.text.NumberFormat result) {
	try {
		getPercentFormatter().setMinimumFractionDigits(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetSource:  (TextField1.text <--> CompoundInterest1.principalAmount)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			getTextField1().setText(String.valueOf(getCompoundInterest1().getPrincipalAmount()));
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (TextField1.text <--> CompoundInterest1.principalAmount)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			getCompoundInterest1().setPrincipalAmount(new Double(getTextField1().getText()).doubleValue());
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (TextField2.text <--> CompoundInterest1.amortizationPeriod)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getTextField2().setText(String.valueOf(getCompoundInterest1().getAmortizationPeriod()));
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (TextField2.text <--> CompoundInterest1.amortizationPeriod)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getCompoundInterest1().setAmortizationPeriod(new Double(getTextField2().getText()).doubleValue());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (TextField3.text <--> CompoundInterest1.interestRate)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getTextField3().setText(String.valueOf(getCompoundInterest1().getInterestRate()));
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (TextField3.text <--> CompoundInterest1.interestRate)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getCompoundInterest1().setInterestRate(new Double(getTextField3().getText()).doubleValue());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (TextField4.text <--> CompoundInterest1.paymentsPerYear)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getTextField4().setText(String.valueOf(getCompoundInterest1().getPaymentsPerYear()));
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (TextField4.text <--> CompoundInterest1.paymentsPerYear)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getCompoundInterest1().setPaymentsPerYear(new Double(getTextField4().getText()).doubleValue());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (TextField5.text <--> CompoundInterest1.timesPerYear)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getTextField5().setText(String.valueOf(getCompoundInterest1().getTimesPerYear()));
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (TextField5.text <--> CompoundInterest1.timesPerYear)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getCompoundInterest1().setTimesPerYear(new Double(getTextField5().getText()).doubleValue());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetTarget:  (List1.font <--> Label13.font)
 */
private void connPtoP6SetTarget() {
	/* Set the target from the source */
	try {
		getLabel13().setFont(getList1().getFont());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 * @param recordParms java.lang.String[]
 */
protected static String formatRecord(String[] recordParms) {
	String record = "";			
	String pad = "                         ";
	int columnWidth[] = {15, 7, 10, 6, 6, 13, 10, 17};
	for (int i=0;i<recordParms.length && i<columnWidth.length;i++)
	{
		int padLength = columnWidth[i] - recordParms[i].length();
		if (padLength > 0)
		  record += pad.substring(0,padLength);
		record += recordParms[i];
	}	
	return record;
}
/**
 * This method was created in VisualAge.
 * @param e java.awt.event.MouseEvent
 * @param p java.awt.PopupMenu
 */
protected void genericPopupDisplay(java.awt.event.MouseEvent e, java.awt.PopupMenu p) {
   if ((e.isPopupTrigger()))  {
	  e.getComponent().add(p);
	  p.show(e.getComponent(), e.getX(), e.getY());
   };
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.mortgageamortizer.AmortizationS1 created using VisualAge for Java.";
}
/**
 * Return the Button1 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton1() {
	if (ivjButton1 == null) {
		try {
			ivjButton1 = new java.awt.Button();
			ivjButton1.setName("Button1");
			ivjButton1.setLabel("Recalculate");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton1;
}
/**
 * Return the CompoundInterest1 property value.
 * @return com.ibm.ivj.examples.vc.mortgageamortizer.CompoundInterest
 */
private CompoundInterest getCompoundInterest1() {
	if (ivjCompoundInterest1 == null) {
		try {
			ivjCompoundInterest1 = new com.ibm.ivj.examples.vc.mortgageamortizer.CompoundInterest();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCompoundInterest1;
}
/**
 * Return the CurrencyFormatter property value.
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat getCurrencyFormatter() {
	return ivjCurrencyFormatter;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setAlignment(java.awt.Label.CENTER);
			ivjLabel1.setText("Loan AmortizationS1 Calculator");
			ivjLabel1.setBackground(java.awt.Color.green);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label10 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel10() {
	if (ivjLabel10 == null) {
		try {
			ivjLabel10 = new java.awt.Label();
			ivjLabel10.setName("Label10");
			ivjLabel10.setText("$*,***.**");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel10;
}
/**
 * Return the Label11 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel11() {
	if (ivjLabel11 == null) {
		try {
			ivjLabel11 = new java.awt.Label();
			ivjLabel11.setName("Label11");
			ivjLabel11.setText("**.**%");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel11;
}
/**
 * Return the Label12 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel12() {
	if (ivjLabel12 == null) {
		try {
			ivjLabel12 = new java.awt.Label();
			ivjLabel12.setName("Label12");
			ivjLabel12.setText("$*,***,***.**");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel12;
}
/**
 * Return the Label13 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel13() {
	if (ivjLabel13 == null) {
		try {
			ivjLabel13 = new java.awt.Label();
			ivjLabel13.setName("Label13");
			ivjLabel13.setText("AmortizationS1 Table Heading");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel13;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("Principal Amount");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("AmortizationS1 Period (Years)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("Annual Interest Rate");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setText("Payments Per Year (#/Yr)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setText("Compounded Times Per Year (X/Yr)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel6;
}
/**
 * Return the Label7 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel7() {
	if (ivjLabel7 == null) {
		try {
			ivjLabel7 = new java.awt.Label();
			ivjLabel7.setName("Label7");
			ivjLabel7.setText("Payment Amount");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel7;
}
/**
 * Return the Label8 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel8() {
	if (ivjLabel8 == null) {
		try {
			ivjLabel8 = new java.awt.Label();
			ivjLabel8.setName("Label8");
			ivjLabel8.setText("Effective Annual Interest Rate (EAR)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel8;
}
/**
 * Return the Label9 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel9() {
	if (ivjLabel9 == null) {
		try {
			ivjLabel9 = new java.awt.Label();
			ivjLabel9.setName("Label9");
			ivjLabel9.setText("Total Interest Cost");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel9;
}
/**
 * Return the List1 property value.
 * @return java.awt.List
 */
private java.awt.List getList1() {
	if (ivjList1 == null) {
		try {
			ivjList1 = new java.awt.List();
			ivjList1.setName("List1");
			ivjList1.setFont(new java.awt.Font("monospaced", 0, 12));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjList1;
}
/**
 * Return the MenuItem1 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem1() {
	if (ivjMenuItem1 == null) {
		try {
			ivjMenuItem1 = new java.awt.MenuItem();
			ivjMenuItem1.setLabel("Delete");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem1;
}
/**
 * Return the MenuItem2 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem2() {
	if (ivjMenuItem2 == null) {
		try {
			ivjMenuItem2 = new java.awt.MenuItem();
			ivjMenuItem2.setLabel("Delete All");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem2;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(new java.awt.GridBagLayout());

			java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
			constraintsLabel2.gridx = 0; constraintsLabel2.gridy = 0;
			constraintsLabel2.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel2(), constraintsLabel2);

			java.awt.GridBagConstraints constraintsLabel3 = new java.awt.GridBagConstraints();
			constraintsLabel3.gridx = 0; constraintsLabel3.gridy = 1;
			constraintsLabel3.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel3(), constraintsLabel3);

			java.awt.GridBagConstraints constraintsLabel4 = new java.awt.GridBagConstraints();
			constraintsLabel4.gridx = 0; constraintsLabel4.gridy = 2;
			constraintsLabel4.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel4(), constraintsLabel4);

			java.awt.GridBagConstraints constraintsLabel5 = new java.awt.GridBagConstraints();
			constraintsLabel5.gridx = 0; constraintsLabel5.gridy = 3;
			constraintsLabel5.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel5(), constraintsLabel5);

			java.awt.GridBagConstraints constraintsLabel6 = new java.awt.GridBagConstraints();
			constraintsLabel6.gridx = 0; constraintsLabel6.gridy = 4;
			constraintsLabel6.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel6(), constraintsLabel6);

			java.awt.GridBagConstraints constraintsTextField1 = new java.awt.GridBagConstraints();
			constraintsTextField1.gridx = 1; constraintsTextField1.gridy = 0;
			constraintsTextField1.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getTextField1(), constraintsTextField1);

			java.awt.GridBagConstraints constraintsTextField2 = new java.awt.GridBagConstraints();
			constraintsTextField2.gridx = 1; constraintsTextField2.gridy = 1;
			constraintsTextField2.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getTextField2(), constraintsTextField2);

			java.awt.GridBagConstraints constraintsTextField3 = new java.awt.GridBagConstraints();
			constraintsTextField3.gridx = 1; constraintsTextField3.gridy = 2;
			constraintsTextField3.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getTextField3(), constraintsTextField3);

			java.awt.GridBagConstraints constraintsTextField4 = new java.awt.GridBagConstraints();
			constraintsTextField4.gridx = 1; constraintsTextField4.gridy = 3;
			constraintsTextField4.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getTextField4(), constraintsTextField4);

			java.awt.GridBagConstraints constraintsTextField5 = new java.awt.GridBagConstraints();
			constraintsTextField5.gridx = 1; constraintsTextField5.gridy = 4;
			constraintsTextField5.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getTextField5(), constraintsTextField5);

			java.awt.GridBagConstraints constraintsLabel7 = new java.awt.GridBagConstraints();
			constraintsLabel7.gridx = 2; constraintsLabel7.gridy = 0;
			constraintsLabel7.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel7(), constraintsLabel7);

			java.awt.GridBagConstraints constraintsLabel8 = new java.awt.GridBagConstraints();
			constraintsLabel8.gridx = 2; constraintsLabel8.gridy = 1;
			constraintsLabel8.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel8(), constraintsLabel8);

			java.awt.GridBagConstraints constraintsLabel9 = new java.awt.GridBagConstraints();
			constraintsLabel9.gridx = 2; constraintsLabel9.gridy = 2;
			constraintsLabel9.anchor = java.awt.GridBagConstraints.EAST;
			getPanel1().add(getLabel9(), constraintsLabel9);

			java.awt.GridBagConstraints constraintsLabel10 = new java.awt.GridBagConstraints();
			constraintsLabel10.gridx = 3; constraintsLabel10.gridy = 0;
			constraintsLabel10.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getLabel10(), constraintsLabel10);

			java.awt.GridBagConstraints constraintsLabel11 = new java.awt.GridBagConstraints();
			constraintsLabel11.gridx = 3; constraintsLabel11.gridy = 1;
			constraintsLabel11.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getLabel11(), constraintsLabel11);

			java.awt.GridBagConstraints constraintsLabel12 = new java.awt.GridBagConstraints();
			constraintsLabel12.gridx = 3; constraintsLabel12.gridy = 2;
			constraintsLabel12.anchor = java.awt.GridBagConstraints.WEST;
			getPanel1().add(getLabel12(), constraintsLabel12);

			java.awt.GridBagConstraints constraintsButton1 = new java.awt.GridBagConstraints();
			constraintsButton1.gridx = 2; constraintsButton1.gridy = 4;
			getPanel1().add(getButton1(), constraintsButton1);

			java.awt.GridBagConstraints constraintsLabel13 = new java.awt.GridBagConstraints();
			constraintsLabel13.gridx = 0; constraintsLabel13.gridy = 5;
			constraintsLabel13.gridwidth = 4;
			constraintsLabel13.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel13.insets = new java.awt.Insets(10, 15, 0, 0);
			getPanel1().add(getLabel13(), constraintsLabel13);

			java.awt.GridBagConstraints constraintsList1 = new java.awt.GridBagConstraints();
			constraintsList1.gridx = 0; constraintsList1.gridy = 6;
			constraintsList1.gridwidth = 4;
			constraintsList1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsList1.weightx = 1.0;
			constraintsList1.weighty = 1.0;
			constraintsList1.insets = new java.awt.Insets(10, 15, 15, 15);
			getPanel1().add(getList1(), constraintsList1);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the PercentFormatter property value.
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat getPercentFormatter() {
	return ivjPercentFormatter;
}
/**
 * Return the PopupMenu1 property value.
 * @return java.awt.PopupMenu
 */
private java.awt.PopupMenu getPopupMenu1() {
	if (ivjPopupMenu1 == null) {
		try {
			ivjPopupMenu1 = new java.awt.PopupMenu();
			ivjPopupMenu1.add(getMenuItem1());
			ivjPopupMenu1.add(getMenuItem2());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPopupMenu1;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
			ivjTextField1.setText("100000");
			ivjTextField1.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setText("30");
			ivjTextField2.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setText("10.00");
			ivjTextField3.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Return the TextField4 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField4() {
	if (ivjTextField4 == null) {
		try {
			ivjTextField4 = new java.awt.TextField();
			ivjTextField4.setName("TextField4");
			ivjTextField4.setText("12");
			ivjTextField4.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField4;
}
/**
 * Return the TextField5 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField5() {
	if (ivjTextField5 == null) {
		try {
			ivjTextField5 = new java.awt.TextField();
			ivjTextField5.setName("TextField5");
			ivjTextField5.setText("12");
			ivjTextField5.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField5;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		super.init();
		setName("AmortizationS1");
		setLayout(new java.awt.BorderLayout());
		setBackground(java.awt.Color.lightGray);
		setSize(650, 400);
		add(getLabel1(), "North");
		add(getPanel1(), "South");
		initConnections();
		connEtoM5();
		connEtoM6();
		connEtoM10();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getTextField1().addTextListener(this);
	getCompoundInterest1().addPropertyChangeListener(this);
	getTextField2().addTextListener(this);
	getTextField3().addTextListener(this);
	getTextField4().addTextListener(this);
	getTextField5().addTextListener(this);
	getButton1().addActionListener(this);
	getList1().addMouseListener(this);
	getMenuItem1().addActionListener(this);
	getMenuItem2().addActionListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP6SetTarget();
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.mortgageamortizer.Amortization aAmortization;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.mortgageamortizer.AmortizationS1");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aAmortization = (com.ibm.ivj.examples.vc.mortgageamortizer.Amortization)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.mortgageamortizer.AmortizationS1");
		frame.add("Center", aAmortization);
		frame.setSize(aAmortization.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(java.awt.event.MouseEvent e) {
	if (e.getSource() == getList1()) 
		connEtoC1(e);
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("principalAmount"))) 
		connPtoP1SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("amortizationPeriod"))) 
		connPtoP2SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("interestRate"))) 
		connPtoP3SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("paymentsPerYear"))) 
		connPtoP4SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("timesPerYear"))) 
		connPtoP5SetSource();
}
/**
 * Set the CurrencyFormatter to a new value.
 * @param newValue java.text.NumberFormat
 */
private void setCurrencyFormatter(java.text.NumberFormat newValue) {
	if (ivjCurrencyFormatter != newValue) {
		try {
			ivjCurrencyFormatter = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the PercentFormatter to a new value.
 * @param newValue java.text.NumberFormat
 */
private void setPercentFormatter(java.text.NumberFormat newValue) {
	if (ivjPercentFormatter != newValue) {
		try {
			ivjPercentFormatter = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
public void textValueChanged(java.awt.event.TextEvent e) {
	if (e.getSource() == getTextField1()) 
		connPtoP1SetTarget();
	if (e.getSource() == getTextField2()) 
		connPtoP2SetTarget();
	if (e.getSource() == getTextField3()) 
		connPtoP3SetTarget();
	if (e.getSource() == getTextField4()) 
		connPtoP4SetTarget();
	if (e.getSource() == getTextField5()) 
		connPtoP5SetTarget();
}
}  // @jve:visual-info  decl-index=0 visual-constraint="38,51"
