package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * The bean information class for SwingTest.GroupBox.
 */
public class GroupBoxBeanInfo extends java.beans.SimpleBeanInfo {
/**
 * Gets the borderproperty descriptor.
 * @return java.beans.PropertyDescriptor
 */
public java.beans.PropertyDescriptor borderPropertyDescriptor() {
	java.beans.PropertyDescriptor aDescriptor = null;
	try {
		try {
			/* Using methods via getMethod is the faster way to create the border property descriptor. */
			java.lang.reflect.Method aGetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aGetMethodParameterTypes[] = {};
				aGetMethod = getBeanClass().getMethod("getBorder", aGetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aGetMethod = findMethod(getBeanClass(), "getBorder", 0);
			};
			java.lang.reflect.Method aSetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aSetMethodParameterTypes[] = {
					javax.swing.border.Border.class
				};
				aSetMethod = getBeanClass().getMethod("setBorder", aSetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aSetMethod = findMethod(getBeanClass(), "setBorder", 1);
			};
			aDescriptor = new java.beans.PropertyDescriptor("border"
			, aGetMethod, aSetMethod);
		} catch (Throwable exception) {
			/* Since we failed using methods, try creating a default property descriptor. */
			handleException(exception);
			aDescriptor = new java.beans.PropertyDescriptor("border"
			, getBeanClass());
		};
		/* aDescriptor.setBound(false); */
		/* aDescriptor.setConstrained(false); */
		/* aDescriptor.setDisplayName("border"); */
		/* aDescriptor.setShortDescription("border"); */
		/* aDescriptor.setExpert(false); */
		aDescriptor.setHidden(true);
	} catch (Throwable exception) {
		handleException(exception);
	};
	return aDescriptor;
}
/**
 * Extend the titleJustification property descriptor by calling setValue(key, object).
 * @return java.beans.PropertyDescriptor
 */
public void extendTitleJustificationPropertyDescriptor(java.beans.PropertyDescriptor aDescriptor) {
	try {
		aDescriptor.setValue("enumerationValues", new Object[] {
			"DEFAULT_JUSTIFICATION", new Integer(0), "javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION",
			"LEFT", new Integer(1), "javax.swing.border.TitledBorder.LEFT",
			"CENTER", new Integer(2), "javax.swing.border.TitledBorder.CENTER",
			"RIGHT", new Integer(3), "javax.swing.border.TitledBorder.RIGHT"});
	} catch (Throwable exception) {
		handleException(exception);
	};
	return;
}
/**
 * Extend the titlePosition property descriptor by calling setValue(key, object).
 */
public void extendTitlePositionPropertyDescriptor(java.beans.PropertyDescriptor aDescriptor) {
	try {
		aDescriptor.setValue("enumerationValues", new Object[] {
			"DEFAULT_POSITION", new Integer(0), "javax.swing.border.TitledBorder.DEFAULT_POSITION",
			"ABOVE_TOP", new Integer(1), "javax.swing.border.TitledBorder.ABOVE_TOP",
			"TOP", new Integer(2), "javax.swing.border.TitledBorder.TOP",
			"BELOW_TOP", new Integer(3), "javax.swing.border.TitledBorder.BELOW_TOP",
			"ABOVE_BOTTOM", new Integer(4), "javax.swing.border.TitledBorder.ABOVE_BOTTOM",
			"BOTTOM", new Integer(5), "javax.swing.border.TitledBorder.BOTTOM",
			"BELOW_BOTTOM", new Integer(6), "javax.swing.border.TitledBorder.BELOW_BOTTOM"
			});
	} catch (Throwable exception) {
		handleException(exception);
	};
	return;
}
/**
 * Find the method by comparing (name & parameter size) against the methods in the class.
 * @return java.lang.reflect.Method
 * @param aClass java.lang.Class
 * @param methodName java.lang.String
 * @param parameterCount int
 */
public static java.lang.reflect.Method findMethod(java.lang.Class aClass, java.lang.String methodName, int parameterCount) {
	try {
		/* Since this method attempts to find a method by getting all methods from the class,
	this method should only be called if getMethod cannot find the method. */
		java.lang.reflect.Method methods[] = aClass.getMethods();
		for (int index = 0; index < methods.length; index++){
			java.lang.reflect.Method method = methods[index];
			if ((method.getParameterTypes().length == parameterCount) && (method.getName().equals(methodName))) {
				return method;
			};
		};
	} catch (java.lang.Throwable exception) {
		return null;
	};
	return null;
}
/**
 * Returns the BeanInfo of the superclass of this bean to inherit its features.
 * @return java.beans.BeanInfo[]
 */
public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	java.lang.Class superClass;
	java.beans.BeanInfo superBeanInfo = null;

	try {
		superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	} catch (java.lang.Throwable exception) {
		return null;
	}

	try {
		superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	} catch (java.beans.IntrospectionException ie) {}

	if (superBeanInfo != null) {
		java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		ret[0] = superBeanInfo;
		return ret;
	}
	return null;
}
/**
 * Gets the bean class.
 * @return java.lang.Class
 */
public static java.lang.Class getBeanClass() {
	return com.ibm.ivj.examples.vc.utilitybeans.GroupBox.class;
}
/**
 * Gets the bean class name.
 * @return java.lang.String
 */
public static java.lang.String getBeanClassName() {
	return "com.ibm.ivj.examples.vc.utilitybeans.GroupBox";
}
public java.beans.BeanDescriptor getBeanDescriptor() {
	java.beans.BeanDescriptor aDescriptor = null;
	try {
		/* Create and return the GroupBoxBeanInfobean descriptor. */
		aDescriptor = new java.beans.BeanDescriptor(com.ibm.ivj.examples.vc.utilitybeans.GroupBox.class);
		/* aDescriptor.setExpert(false); */
		/* aDescriptor.setHidden(false); */
		/* aDescriptor.setValue("hidden-state", Boolean.FALSE); */
	} catch (Throwable exception) {
	};
	return aDescriptor;
}
/**
 * Return the event set descriptors for this bean.
 * @return java.beans.EventSetDescriptor[]
 */
public java.beans.EventSetDescriptor[] getEventSetDescriptors() {
	try {
		java.beans.EventSetDescriptor aDescriptorList[] = {
					};
		return aDescriptorList;
	} catch (Throwable exception) {
		handleException(exception);
	};
	return null;
}
/**
 * Return the method descriptors for this bean.
 * @return java.beans.MethodDescriptor[]
 */
public java.beans.MethodDescriptor[] getMethodDescriptors() {
	try {
		java.beans.MethodDescriptor aDescriptorList[] = {
					};
		return aDescriptorList;
	} catch (Throwable exception) {
		handleException(exception);
	};
	return null;
}
/**
 * Return the property descriptors for this bean.
 * @return java.beans.PropertyDescriptor[]
 */
public java.beans.PropertyDescriptor[] getPropertyDescriptors() {
	try {
		java.beans.PropertyDescriptor aDescriptorList[] = {
			borderPropertyDescriptor()
			,lineColorPropertyDescriptor()
			,lineWidthPropertyDescriptor()
			,titleJustificationPropertyDescriptor()
			,titlePositionPropertyDescriptor()
		};
		return aDescriptorList;
	} catch (Throwable exception) {
		handleException(exception);
	};
	return null;
}
/**
 * Called whenever the bean information class throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Gets the lineColorproperty descriptor.
 * @return java.beans.PropertyDescriptor
 */
public java.beans.PropertyDescriptor lineColorPropertyDescriptor() {
	java.beans.PropertyDescriptor aDescriptor = null;
	try {
		try {
			/* Using methods via getMethod is the faster way to create the lineColor property descriptor. */
			java.lang.reflect.Method aGetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aGetMethodParameterTypes[] = {};
				aGetMethod = getBeanClass().getMethod("getLineColor", aGetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aGetMethod = findMethod(getBeanClass(), "getLineColor", 0);
			};
			java.lang.reflect.Method aSetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aSetMethodParameterTypes[] = {
					java.awt.Color.class
				};
				aSetMethod = getBeanClass().getMethod("setLineColor", aSetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aSetMethod = findMethod(getBeanClass(), "setLineColor", 1);
			};
			aDescriptor = new java.beans.PropertyDescriptor("lineColor"
			, aGetMethod, aSetMethod);
		} catch (Throwable exception) {
			/* Since we failed using methods, try creating a default property descriptor. */
			handleException(exception);
			aDescriptor = new java.beans.PropertyDescriptor("lineColor"
			, getBeanClass());
		};
		aDescriptor.setBound(true);
		/* aDescriptor.setConstrained(false); */
		/* aDescriptor.setDisplayName("lineColor"); */
		/* aDescriptor.setShortDescription("lineColor"); */
		/* aDescriptor.setExpert(false); */
		/* aDescriptor.setHidden(false); */
	} catch (Throwable exception) {
		handleException(exception);
	};
	return aDescriptor;
}
/**
 * Gets the lineWidthproperty descriptor.
 * @return java.beans.PropertyDescriptor
 */
public java.beans.PropertyDescriptor lineWidthPropertyDescriptor() {
	java.beans.PropertyDescriptor aDescriptor = null;
	try {
		try {
			/* Using methods via getMethod is the faster way to create the lineWidth property descriptor. */
			java.lang.reflect.Method aGetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aGetMethodParameterTypes[] = {};
				aGetMethod = getBeanClass().getMethod("getLineWidth", aGetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aGetMethod = findMethod(getBeanClass(), "getLineWidth", 0);
			};
			java.lang.reflect.Method aSetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aSetMethodParameterTypes[] = {
					int.class
				};
				aSetMethod = getBeanClass().getMethod("setLineWidth", aSetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aSetMethod = findMethod(getBeanClass(), "setLineWidth", 1);
			};
			aDescriptor = new java.beans.PropertyDescriptor("lineWidth"
			, aGetMethod, aSetMethod);
		} catch (Throwable exception) {
			/* Since we failed using methods, try creating a default property descriptor. */
			handleException(exception);
			aDescriptor = new java.beans.PropertyDescriptor("lineWidth"
			, getBeanClass());
		};
		aDescriptor.setBound(true);
		/* aDescriptor.setConstrained(false); */
		/* aDescriptor.setDisplayName("lineWidth"); */
		/* aDescriptor.setShortDescription("lineWidth"); */
		/* aDescriptor.setExpert(false); */
		/* aDescriptor.setHidden(false); */
	} catch (Throwable exception) {
		handleException(exception);
	};
	return aDescriptor;
}
/**
 * Gets the titleJustificationproperty descriptor.
 * @return java.beans.PropertyDescriptor
 */
public java.beans.PropertyDescriptor titleJustificationPropertyDescriptor() {
	java.beans.PropertyDescriptor aDescriptor = null;
	try {
		try {
			/* Using methods via getMethod is the faster way to create the titleJustification property descriptor. */
			java.lang.reflect.Method aGetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aGetMethodParameterTypes[] = {};
				aGetMethod = getBeanClass().getMethod("getTitleJustification", aGetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aGetMethod = findMethod(getBeanClass(), "getTitleJustification", 0);
			};
			java.lang.reflect.Method aSetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aSetMethodParameterTypes[] = {
					int.class
				};
				aSetMethod = getBeanClass().getMethod("setTitleJustification", aSetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aSetMethod = findMethod(getBeanClass(), "setTitleJustification", 1);
			};
			aDescriptor = new java.beans.PropertyDescriptor("titleJustification"
			, aGetMethod, aSetMethod);
		} catch (Throwable exception) {
			/* Since we failed using methods, try creating a default property descriptor. */
			handleException(exception);
			aDescriptor = new java.beans.PropertyDescriptor("titleJustification"
			, getBeanClass());
		};
		extendTitleJustificationPropertyDescriptor(aDescriptor);
		aDescriptor.setBound(true);
		/* aDescriptor.setConstrained(false); */
		/* aDescriptor.setDisplayName("titleJustification"); */
		/* aDescriptor.setShortDescription("titleJustification"); */
		/* aDescriptor.setExpert(false); */
		/* aDescriptor.setHidden(false); */
	} catch (Throwable exception) {
		handleException(exception);
	};
	return aDescriptor;
}
/**
 * Gets the titlePositionproperty descriptor.
 * @return java.beans.PropertyDescriptor
 */
public java.beans.PropertyDescriptor titlePositionPropertyDescriptor() {
	java.beans.PropertyDescriptor aDescriptor = null;
	try {
		try {
			/* Using methods via getMethod is the faster way to create the titlePosition property descriptor. */
			java.lang.reflect.Method aGetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aGetMethodParameterTypes[] = {};
				aGetMethod = getBeanClass().getMethod("getTitlePosition", aGetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aGetMethod = findMethod(getBeanClass(), "getTitlePosition", 0);
			};
			java.lang.reflect.Method aSetMethod = null;
			try {
				/* Attempt to find the method using getMethod with parameter types. */
				java.lang.Class aSetMethodParameterTypes[] = {
					int.class
				};
				aSetMethod = getBeanClass().getMethod("setTitlePosition", aSetMethodParameterTypes);
			} catch (Throwable exception) {
				/* Since getMethod failed, call findMethod. */
				handleException(exception);
				aSetMethod = findMethod(getBeanClass(), "setTitlePosition", 1);
			};
			aDescriptor = new java.beans.PropertyDescriptor("titlePosition"
			, aGetMethod, aSetMethod);
		} catch (Throwable exception) {
			/* Since we failed using methods, try creating a default property descriptor. */
			handleException(exception);
			aDescriptor = new java.beans.PropertyDescriptor("titlePosition"
			, getBeanClass());
		};
		extendTitlePositionPropertyDescriptor(aDescriptor);
		aDescriptor.setBound(true);
		/* aDescriptor.setConstrained(false); */
		/* aDescriptor.setDisplayName("titlePosition"); */
		/* aDescriptor.setShortDescription("titlePosition"); */
		/* aDescriptor.setExpert(false); */
		/* aDescriptor.setHidden(false); */
	} catch (Throwable exception) {
		handleException(exception);
	};
	return aDescriptor;
}
}
