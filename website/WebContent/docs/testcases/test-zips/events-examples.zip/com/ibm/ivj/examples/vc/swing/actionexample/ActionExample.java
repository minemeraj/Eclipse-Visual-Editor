package com.ibm.ivj.examples.vc.swing.actionexample;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class ActionExample extends javax.swing.JFrame implements java.awt.event.ActionListener, java.awt.event.MouseListener {
	private javax.swing.JMenuBar ivjActionExampleJMenuBar = null;
	private ActionClass ivjCopyAction = null;  // @jve:visual-info  decl-index=0 visual-constraint="218,348"
	private ActionClass ivjCutAction = null;  // @jve:visual-info  decl-index=0 visual-constraint="135,348"
	private javax.swing.JPanel ivjJFrameContentPane = null;
	private javax.swing.JMenu ivjJMenu1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="522,20"
	private javax.swing.JPopupMenu ivjJPopupMenu1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="520,81"
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
	private javax.swing.JToolBar ivjJToolBar1 = null;
	private ActionClass ivjPasteAction = null;  // @jve:visual-info  decl-index=0 visual-constraint="298,348"
/**
 * Constructor
 */
public ActionExample() {
	super();
	initialize();
}
/**
 * ActionExample constructor comment.
 * @param title java.lang.String
 */
public ActionExample(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getCutAction()) 
		connEtoM1(e);
	if (e.getSource() == getCopyAction()) 
		connEtoM2(e);
	if (e.getSource() == getPasteAction()) 
		connEtoM3(e);
}
/**
 * connEtoC1:  (JTextArea1.mouse.mouseReleased(java.awt.event.MouseEvent) --> ActionExample.genericPopupDisplay(Ljava.awt.event.MouseEvent;Lcom.sun.java.swing.JPopupMenu;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoC1(java.awt.event.MouseEvent arg1) {
	try {
		this.genericPopupDisplay(arg1, getJPopupMenu1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (CutAction.action.actionPerformed(java.awt.event.ActionEvent) --> JTextArea1.cut()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		getJTextArea1().cut();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (CopyAction.action.actionPerformed(java.awt.event.ActionEvent) --> JTextArea1.copy()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		getJTextArea1().copy();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (PasteAction.action.actionPerformed(java.awt.event.ActionEvent) --> JTextArea1.paste()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		getJTextArea1().paste();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 * @param e java.awt.event.MouseEvent
 * @param p javax.swing.JPopupMenu
 */
protected final void genericPopupDisplay(java.awt.event.MouseEvent e, javax.swing.JPopupMenu p) {
	  if ((e.isPopupTrigger()))  {
	  p.show(e.getComponent(), e.getX(), e.getY());
  }	
}
/**
 * Return the ActionExampleJMenuBar property value.
 * @return javax.swing.JMenuBar
 */
private javax.swing.JMenuBar getActionExampleJMenuBar() {
	if (ivjActionExampleJMenuBar == null) {
		try {
			ivjActionExampleJMenuBar = new javax.swing.JMenuBar();
			ivjActionExampleJMenuBar.setName("ActionExampleJMenuBar");
			ivjActionExampleJMenuBar.add(getJMenu1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjActionExampleJMenuBar;
}
/**
 * Return the CopyAction property value.
 * @return com.ibm.ivj.examples.vc.swing.actionexample.ActionClass
 */
private ActionClass getCopyAction() {
	if (ivjCopyAction == null) {
		try {
			ivjCopyAction = new com.ibm.ivj.examples.vc.swing.actionexample.ActionClass();
			ivjCopyAction.setIcon(new javax.swing.ImageIcon("..\\Sun JFC SwingSet\\images\\copy.gif"));
			ivjCopyAction.setText("Copy");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCopyAction;
}
/**
 * Return the CutAction property value.
 * @return com.ibm.ivj.examples.vc.swing.actionexample.ActionClass
 */
private ActionClass getCutAction() {
	if (ivjCutAction == null) {
		try {
			ivjCutAction = new com.ibm.ivj.examples.vc.swing.actionexample.ActionClass();
			ivjCutAction.setIcon(new javax.swing.ImageIcon("..\\Sun JFC SwingSet\\images\\cut.gif"));
			ivjCutAction.setText("Cut");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCutAction;
}
/**
 * Return the JFrameContentPane property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new javax.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(new java.awt.BorderLayout());
			getJFrameContentPane().add(getJToolBar1(), "North");
			getJFrameContentPane().add(getJScrollPane1(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJFrameContentPane;
}
/**
 * Return the JMenu1 property value.
 * @return javax.swing.JMenu
 */
private javax.swing.JMenu getJMenu1() {
	if (ivjJMenu1 == null) {
		try {
			ivjJMenu1 = new javax.swing.JMenu();
			ivjJMenu1.setName("JMenu1");
			ivjJMenu1.setText("Edit");
			ivjJMenu1.add(getCutAction());
			ivjJMenu1.add(getCopyAction());
			ivjJMenu1.add(getPasteAction());	
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJMenu1;
}
/**
 * Return the JPopupMenu1 property value.
 * @return javax.swing.JPopupMenu
 */
private javax.swing.JPopupMenu getJPopupMenu1() {
	if (ivjJPopupMenu1 == null) {
		try {
			ivjJPopupMenu1 = new javax.swing.JPopupMenu();
			ivjJPopupMenu1.setName("JPopupMenu1");
			ivjJPopupMenu1.add(getCutAction());
			ivjJPopupMenu1.add(getCopyAction());
			ivjJPopupMenu1.add(getPasteAction());	
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPopupMenu1;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			getJScrollPane1().setViewportView(getJTextArea1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setText("The Cut, Copy and Paste actions are available from the Toolbar,\nthe Edit pulldown menu, and from the popup menu in this TextArea.\nTo use Cut and Copy with the popup menu, select the desired \ntext in this TextArea with Mouse Button 2.");
			ivjJTextArea1.setBounds(0, 0, 12, 17);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Return the JToolBar1 property value.
 * @return javax.swing.JToolBar
 */
private javax.swing.JToolBar getJToolBar1() {
	if (ivjJToolBar1 == null) {
		try {
			ivjJToolBar1 = new javax.swing.JToolBar();
			ivjJToolBar1.setName("JToolBar1");
			ivjJToolBar1.setPreferredSize(new java.awt.Dimension(60, 50));
			ivjJToolBar1.setMaximumSize(new java.awt.Dimension(60, 50));
			ivjJToolBar1.setMinimumSize(new java.awt.Dimension(60, 50));
			getJToolBar1().add(getCutAction());
			getJToolBar1().add(getCopyAction());
			getJToolBar1().add(getPasteAction());				
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJToolBar1;
}
/**
 * Return the PasteAction property value.
 * @return com.ibm.ivj.examples.vc.swing.actionexample.ActionClass
 */
private ActionClass getPasteAction() {
	if (ivjPasteAction == null) {
		try {
			ivjPasteAction = new com.ibm.ivj.examples.vc.swing.actionexample.ActionClass();
			ivjPasteAction.setIcon(new javax.swing.ImageIcon("..\\Sun JFC SwingSet\\images\\paste.gif"));
			ivjPasteAction.setText("Paste");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPasteAction;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getCutAction().addActionListener(this);
	getCopyAction().addActionListener(this);
	getPasteAction().addActionListener(this);
	getJTextArea1().addMouseListener(this);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("ActionExample");
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setSize(474, 269);
		setJMenuBar(getActionExampleJMenuBar());
		setContentPane(getJFrameContentPane());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.ibm.ivj.examples.vc.swing.actionexample.ActionExample aActionExample;
		aActionExample = new com.ibm.ivj.examples.vc.swing.actionexample.ActionExample();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aActionExample };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aActionExample.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(java.awt.event.MouseEvent e) {
	if (e.getSource() == getJTextArea1()) 
		connEtoC1(e);
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
