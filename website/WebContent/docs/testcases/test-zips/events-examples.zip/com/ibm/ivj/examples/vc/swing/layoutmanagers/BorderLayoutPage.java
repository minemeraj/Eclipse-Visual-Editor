package com.ibm.ivj.examples.vc.swing.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class BorderLayoutPage extends javax.swing.JPanel {
	private javax.swing.JButton ivjJButton1 = null;
	private javax.swing.JButton ivjJButton2 = null;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
	private javax.swing.JTextField ivjJTextField1 = null;
/**
 * Constructor
 */
public BorderLayoutPage() {
	super();
	initialize();
}
/**
 * BorderLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public BorderLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * BorderLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public BorderLayoutPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * BorderLayoutPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public BorderLayoutPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new javax.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setOpaque(false);
			ivjJButton1.setText("West");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton1;
}
/**
 * Return the JButton2 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton2() {
	if (ivjJButton2 == null) {
		try {
			ivjJButton2 = new javax.swing.JButton();
			ivjJButton2.setName("JButton2");
			ivjJButton2.setOpaque(false);
			ivjJButton2.setText("East");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton2;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("North");
			ivjJLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setText("This is a BorderLayout.\nIt can contain up to five components in five regions:\nNorth, South, East, West, and Center.\nThis panel contains:\nNorth: aLabel\nWest: aButton\nEast: aButton\nSouth: aTextField\nCenter: This TextArea");
			ivjJTextArea1.setBackground(new java.awt.Color(230,230,255));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setText("South");
			ivjJTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("BorderLayoutPage");
		setLayout(new java.awt.BorderLayout());
		setBackground(java.awt.Color.magenta);
		setSize(600, 300);
		add(getJLabel1(), "North");
		add(getJButton1(), "West");
		add(getJButton2(), "East");
		add(getJTextField1(), "South");
		add(getJTextArea1(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		com.ibm.ivj.examples.vc.swing.layoutmanagers.BorderLayoutPage aBorderLayoutPage;
		aBorderLayoutPage = new com.ibm.ivj.examples.vc.swing.layoutmanagers.BorderLayoutPage();
		frame.getContentPane().add("Center", aBorderLayoutPage);
		frame.setSize(aBorderLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
