package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class NameEditor extends java.beans.PropertyEditorSupport {
	java.beans.PropertyChangeSupport iPropertyChange = new java.beans.PropertyChangeSupport(this);
	NameCustomEditor iNameCustomEditor = null;
	Name iName = null;
/**
 * This method was created in VisualAge.
 */
public NameEditor() {
	super ();
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getAsText() {
	return ((Name) getValue()).toString();
}
/**
 * This method was created in VisualAge.
 * @return java.awt.Component
 */
public java.awt.Component getCustomEditor() {
	if (iNameCustomEditor == null) {
		iNameCustomEditor = new NameCustomEditor();
		iNameCustomEditor.setTheNameThis(getName());
	}
	return iNameCustomEditor;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getJavaInitializationString() {
	Name tName = ((Name) getValue());
	return "new com.ibm.ivj.examples.vc.propertyeditors.Name(\"" + 
		tName.getTitle() + "\", \"" + 
		tName.getFirst() + "\", \"" + 
		tName.getMiddle() + "\", \"" + 
		tName.getLast() + "\")";
}
/**
 * This method was created in VisualAge.
 * @return com.ibm.ivj.examples.vc.propertyeditors.Name
 */
public Name getName() {
	if (iName == null) iName = new Name();
	return iName;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 */
public Object getValue() {
	if (iNameCustomEditor == null) return getName();
	else return iNameCustomEditor.getTheNameThis();
}
/**
 * This method was created in VisualAge.
 * @param value java.lang.Object
 */
public void setValue(Object value) {
	Object tValue = getName();
	if (iNameCustomEditor == null) {
		iName = ((Name) value);
		iPropertyChange.firePropertyChange("value", tValue, value);
	} else iNameCustomEditor.setTheNameThis((Name) value);
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean supportsCustomEditor() {
	return true;
}
}
