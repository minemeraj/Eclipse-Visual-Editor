package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class LiveGridBagConstraints extends java.awt.Frame implements java.awt.event.ActionListener, java.awt.event.ItemListener, java.awt.event.TextListener, java.awt.event.WindowListener, java.beans.PropertyChangeListener {
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private java.awt.Panel fieldGridBagPanel = new java.awt.Panel();
	private java.awt.Choice ivjAnchorChoice = null;
	private java.awt.Button ivjButton1 = null;
	private java.awt.Button ivjButton2 = null;
	private java.awt.Button ivjButton3 = null;
	private java.awt.Button ivjButton4 = null;
	private java.awt.Choice ivjChoice1 = null;
	private java.awt.Component ivjComponent1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="452,420"
	private boolean ivjConnPtoP10Aligning = false;
	private boolean ivjConnPtoP11Aligning = false;
	private boolean ivjConnPtoP12Aligning = false;
	private boolean ivjConnPtoP13Aligning = false;
	private boolean ivjConnPtoP14Aligning = false;
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private boolean ivjConnPtoP5Aligning = false;
	private boolean ivjConnPtoP6Aligning = false;
	private boolean ivjConnPtoP7Aligning = false;
	private boolean ivjConnPtoP8Aligning = false;
	private boolean ivjConnPtoP9Aligning = false;
	private java.awt.Panel ivjContentsPane = null;
	private java.awt.Choice ivjFillChoice = null;
	private GridBagBean ivjGridBagBean1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="655,165"
	private java.awt.GridBagLayout ivjGridBagLayout1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="326,509"
	private java.awt.Panel ivjgridBagPanel = null;  // @jve:visual-info  decl-index=0 visual-constraint="181,487"
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel10 = null;
	private java.awt.Label ivjLabel11 = null;
	private java.awt.Label ivjLabel12 = null;
	private java.awt.Label ivjLabel13 = null;
	private java.awt.Label ivjLabel14 = null;
	private java.awt.Label ivjLabel15 = null;
	private java.awt.Label ivjLabel16 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.Label ivjLabel6 = null;
	private java.awt.Label ivjLabel7 = null;
	private java.awt.Label ivjLabel8 = null;
	private java.awt.Label ivjLabel9 = null;
	private java.awt.Panel ivjPanel1 = null;
	private java.awt.Panel ivjPanel2 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField10 = null;
	private java.awt.TextField ivjTextField11 = null;
	private java.awt.TextField ivjTextField12 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
	private java.awt.TextField ivjTextField4 = null;
	private java.awt.TextField ivjTextField5 = null;
	private java.awt.TextField ivjTextField6 = null;
	private java.awt.TextField ivjTextField7 = null;
	private java.awt.TextField ivjTextField8 = null;
	private java.awt.TextField ivjTextField9 = null;
/**
 * Constructor
 */
public LiveGridBagConstraints() {
	super();
	initialize();
}
/**
 * LiveGridBagConstraints constructor comment.
 * @param title java.lang.String
 */
public LiveGridBagConstraints(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getButton3()) 
		connEtoC3(e);
	if (e.getSource() == getButton4()) 
		connEtoM3(e);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * connEtoC1:  (LiveGridBagConstraints.window.windowClosing(java.awt.event.WindowEvent) --> LiveGridBagConstraints.dispose()V)
 * @param arg1 java.awt.event.WindowEvent
 */
private void connEtoC1(java.awt.event.WindowEvent arg1) {
	try {
		this.dispose();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (gridBagPanel.this --> LiveGridBagConstraints.refreshComponentChoice(Ljava.awt.Choice;Ljava.awt.Panel;)V)
 * @param value java.awt.Panel
 */
private void connEtoC2(java.awt.Panel value) {
	try {
		com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints.refreshComponentChoice(getChoice1(), this.getGridBagPanel());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (Button4.action.actionPerformed(java.awt.event.ActionEvent) --> LiveGridBagConstraints.updateComponentConstraints(Ljava.awt.Component;Lcom.ibm.ivj.examples.vc.utilitybeans.GridBagBean;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		if ((getComponent1() != null)) {
			com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints.updateComponentConstraints(getComponent1(), getGridBagBean1());
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (Choice1.item.itemStateChanged(java.awt.event.ItemEvent) --> Button4.enabled)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoM1(java.awt.event.ItemEvent arg1) {
	try {
		getButton4().setEnabled(true);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (gridBagPanel.this --> Button4.enabled)
 * @param value java.awt.Panel
 */
private void connEtoM2(java.awt.Panel value) {
	try {
		getButton4().setEnabled(false);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (Button4.action.actionPerformed(java.awt.event.ActionEvent) --> LiveGridBagConstraints.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		this.dispose();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (Choice1.item.itemStateChanged(java.awt.event.ItemEvent) --> Component1.this)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoM4(java.awt.event.ItemEvent arg1) {
	try {
		if ((getgridBagPanel() != null)) {
			setComponent1(getgridBagPanel().getComponent(getChoice1().getSelectedIndex()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (Component1.this --> GridBagBean1.gridBagConstraints)
 * @param value java.awt.Component
 */
private void connEtoM5(java.awt.Component value) {
	try {
		if ((getGridBagLayout1() != null)) {
			getGridBagBean1().setGridBagConstraints(getGridBagLayout1().getConstraints(getComponent1()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (AnchorChoice.item.itemStateChanged(java.awt.event.ItemEvent) --> GridBagBean1.anchorFromChoice)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoM6(java.awt.event.ItemEvent arg1) {
	try {
		getGridBagBean1().setAnchorFromChoice(getAnchorChoice().getSelectedIndex());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (GridBagBean1.anchor --> AnchorChoice.select(I)V)
 * @param arg1 java.beans.PropertyChangeEvent
 */
private void connEtoM7(java.beans.PropertyChangeEvent arg1) {
	try {
		getAnchorChoice().select(getGridBagBean1().getAnchorAsChoice());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (FillChoice.item.itemStateChanged(java.awt.event.ItemEvent) --> GridBagBean1.fillFromChoice)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoM8(java.awt.event.ItemEvent arg1) {
	try {
		getGridBagBean1().setFillFromChoice(getFillChoice().getSelectedIndex());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  (GridBagBean1.fill --> FillChoice.select(I)V)
 * @param arg1 java.beans.PropertyChangeEvent
 */
private void connEtoM9(java.beans.PropertyChangeEvent arg1) {
	try {
		getFillChoice().select(getGridBagBean1().getFillAsChoice());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP10SetSource:  (GridBagBean1.insetsBottom <--> TextField8.text)
 */
private void connPtoP10SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP10Aligning == false) {
			ivjConnPtoP10Aligning = true;
			getTextField8().setText(getGridBagBean1().getInsetsBottom());
			ivjConnPtoP10Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP10Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP10SetTarget:  (GridBagBean1.insetsBottom <--> TextField8.text)
 */
private void connPtoP10SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP10Aligning == false) {
			ivjConnPtoP10Aligning = true;
			getGridBagBean1().setInsetsBottom(getTextField8().getText());
			ivjConnPtoP10Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP10Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP11SetSource:  (GridBagBean1.ipadX <--> TextField9.text)
 */
private void connPtoP11SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP11Aligning == false) {
			ivjConnPtoP11Aligning = true;
			getTextField9().setText(getGridBagBean1().getIpadX());
			ivjConnPtoP11Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP11Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP11SetTarget:  (GridBagBean1.ipadX <--> TextField9.text)
 */
private void connPtoP11SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP11Aligning == false) {
			ivjConnPtoP11Aligning = true;
			getGridBagBean1().setIpadX(getTextField9().getText());
			ivjConnPtoP11Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP11Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP12SetSource:  (GridBagBean1.ipadY <--> TextField10.text)
 */
private void connPtoP12SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP12Aligning == false) {
			ivjConnPtoP12Aligning = true;
			getTextField10().setText(getGridBagBean1().getIpadY());
			ivjConnPtoP12Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP12Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP12SetTarget:  (GridBagBean1.ipadY <--> TextField10.text)
 */
private void connPtoP12SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP12Aligning == false) {
			ivjConnPtoP12Aligning = true;
			getGridBagBean1().setIpadY(getTextField10().getText());
			ivjConnPtoP12Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP12Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP13SetSource:  (GridBagBean1.weightX <--> TextField11.text)
 */
private void connPtoP13SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP13Aligning == false) {
			ivjConnPtoP13Aligning = true;
			getTextField11().setText(getGridBagBean1().getWeightX());
			ivjConnPtoP13Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP13Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP13SetTarget:  (GridBagBean1.weightX <--> TextField11.text)
 */
private void connPtoP13SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP13Aligning == false) {
			ivjConnPtoP13Aligning = true;
			getGridBagBean1().setWeightX(getTextField11().getText());
			ivjConnPtoP13Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP13Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP14SetSource:  (GridBagBean1.weightY <--> TextField12.text)
 */
private void connPtoP14SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP14Aligning == false) {
			ivjConnPtoP14Aligning = true;
			getTextField12().setText(getGridBagBean1().getWeightY());
			ivjConnPtoP14Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP14Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP14SetTarget:  (GridBagBean1.weightY <--> TextField12.text)
 */
private void connPtoP14SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP14Aligning == false) {
			ivjConnPtoP14Aligning = true;
			getGridBagBean1().setWeightY(getTextField12().getText());
			ivjConnPtoP14Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP14Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetSource:  (LiveGridBagConstraints.gridBagPanel <--> gridBagPanel.this)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getgridBagPanel() != null)) {
				this.setGridBagPanel(getgridBagPanel());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (LiveGridBagConstraints.gridBagPanel <--> gridBagPanel.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			setgridBagPanel(this.getGridBagPanel());
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (gridBagPanel.layout <--> GridBagLayout1.this)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if ((getgridBagPanel() != null) && (getGridBagLayout1() != null)) {
			getgridBagPanel().setLayout(getGridBagLayout1());
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (gridBagPanel.layout <--> GridBagLayout1.this)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		setGridBagLayout1((java.awt.GridBagLayout)getgridBagPanel().getLayout());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (GridBagBean1.gridHeight <--> TextField1.text)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getTextField1().setText(getGridBagBean1().getGridHeight());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (GridBagBean1.gridHeight <--> TextField1.text)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getGridBagBean1().setGridHeight(getTextField1().getText());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (GridBagBean1.gridWidth <--> TextField2.text)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getTextField2().setText(getGridBagBean1().getGridWidth());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (GridBagBean1.gridWidth <--> TextField2.text)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getGridBagBean1().setGridWidth(getTextField2().getText());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (GridBagBean1.gridX <--> TextField3.text)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getTextField3().setText(getGridBagBean1().getGridX());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (GridBagBean1.gridX <--> TextField3.text)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getGridBagBean1().setGridX(getTextField3().getText());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetSource:  (GridBagBean1.gridY <--> TextField4.text)
 */
private void connPtoP6SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getTextField4().setText(getGridBagBean1().getGridY());
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetTarget:  (GridBagBean1.gridY <--> TextField4.text)
 */
private void connPtoP6SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getGridBagBean1().setGridY(getTextField4().getText());
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP7SetSource:  (GridBagBean1.insetsTop <--> TextField5.text)
 */
private void connPtoP7SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP7Aligning == false) {
			ivjConnPtoP7Aligning = true;
			getTextField5().setText(getGridBagBean1().getInsetsTop());
			ivjConnPtoP7Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP7Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP7SetTarget:  (GridBagBean1.insetsTop <--> TextField5.text)
 */
private void connPtoP7SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP7Aligning == false) {
			ivjConnPtoP7Aligning = true;
			getGridBagBean1().setInsetsTop(getTextField5().getText());
			ivjConnPtoP7Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP7Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP8SetSource:  (GridBagBean1.insetsLeft <--> TextField6.text)
 */
private void connPtoP8SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP8Aligning == false) {
			ivjConnPtoP8Aligning = true;
			getTextField6().setText(getGridBagBean1().getInsetsLeft());
			ivjConnPtoP8Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP8Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP8SetTarget:  (GridBagBean1.insetsLeft <--> TextField6.text)
 */
private void connPtoP8SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP8Aligning == false) {
			ivjConnPtoP8Aligning = true;
			getGridBagBean1().setInsetsLeft(getTextField6().getText());
			ivjConnPtoP8Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP8Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP9SetSource:  (GridBagBean1.insetsRight <--> TextField7.text)
 */
private void connPtoP9SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP9Aligning == false) {
			ivjConnPtoP9Aligning = true;
			getTextField7().setText(getGridBagBean1().getInsetsRight());
			ivjConnPtoP9Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP9Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP9SetTarget:  (GridBagBean1.insetsRight <--> TextField7.text)
 */
private void connPtoP9SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP9Aligning == false) {
			ivjConnPtoP9Aligning = true;
			getGridBagBean1().setInsetsRight(getTextField7().getText());
			ivjConnPtoP9Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP9Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Return the AnchorChoice property value.
 * @return java.awt.Choice
 */
private java.awt.Choice getAnchorChoice() {
	if (ivjAnchorChoice == null) {
		try {
			ivjAnchorChoice = new java.awt.Choice();
			ivjAnchorChoice.setName("AnchorChoice");
			initializeAnchorChoice(ivjAnchorChoice); 
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAnchorChoice;
}
/**
 * Return the Button1 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton1() {
	if (ivjButton1 == null) {
		try {
			ivjButton1 = new java.awt.Button();
			ivjButton1.setName("Button1");
			ivjButton1.setLabel("Property");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton1;
}
/**
 * Return the Button2 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton2() {
	if (ivjButton2 == null) {
		try {
			ivjButton2 = new java.awt.Button();
			ivjButton2.setName("Button2");
			ivjButton2.setLabel("Value");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton2;
}
/**
 * Return the Button3 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton3() {
	if (ivjButton3 == null) {
		try {
			ivjButton3 = new java.awt.Button();
			ivjButton3.setName("Button3");
			ivjButton3.setLabel("Set");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton3;
}
/**
 * Return the Button4 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton4() {
	if (ivjButton4 == null) {
		try {
			ivjButton4 = new java.awt.Button();
			ivjButton4.setName("Button4");
			ivjButton4.setEnabled(false);
			ivjButton4.setLabel("Quit");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton4;
}
/**
 * Return the Choice1 property value.
 * @return java.awt.Choice
 */
private java.awt.Choice getChoice1() {
	if (ivjChoice1 == null) {
		try {
			ivjChoice1 = new java.awt.Choice();
			ivjChoice1.setName("Choice1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjChoice1;
}
/**
 * Return the Component1 property value.
 * @return java.awt.Component
 */
private java.awt.Component getComponent1() {
	return ivjComponent1;
}
/**
 * Return the ContentsPane property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getContentsPane() {
	if (ivjContentsPane == null) {
		try {
			ivjContentsPane = new java.awt.Panel();
			ivjContentsPane.setName("ContentsPane");
			ivjContentsPane.setLayout(new java.awt.GridBagLayout());

			java.awt.GridBagConstraints constraintsLabel1 = new java.awt.GridBagConstraints();
			constraintsLabel1.gridx = -1; constraintsLabel1.gridy = -1;
			getContentsPane().add(getLabel1(), constraintsLabel1);

			java.awt.GridBagConstraints constraintsChoice1 = new java.awt.GridBagConstraints();
			constraintsChoice1.gridx = 0; constraintsChoice1.gridy = 1;
			constraintsChoice1.gridwidth = 2;
			constraintsChoice1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsChoice1.anchor = java.awt.GridBagConstraints.NORTH;
			constraintsChoice1.weightx = 1.0;
			getContentsPane().add(getChoice1(), constraintsChoice1);

			java.awt.GridBagConstraints constraintsButton1 = new java.awt.GridBagConstraints();
			constraintsButton1.gridx = 0; constraintsButton1.gridy = 2;
			constraintsButton1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsButton1.anchor = java.awt.GridBagConstraints.NORTH;
			getContentsPane().add(getButton1(), constraintsButton1);

			java.awt.GridBagConstraints constraintsButton2 = new java.awt.GridBagConstraints();
			constraintsButton2.gridx = 1; constraintsButton2.gridy = 2;
			constraintsButton2.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsButton2.anchor = java.awt.GridBagConstraints.NORTH;
			constraintsButton2.weightx = 1.0;
			getContentsPane().add(getButton2(), constraintsButton2);

			java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
			constraintsLabel2.gridx = 0; constraintsLabel2.gridy = 3;
			constraintsLabel2.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel2.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel2(), constraintsLabel2);

			java.awt.GridBagConstraints constraintsLabel3 = new java.awt.GridBagConstraints();
			constraintsLabel3.gridx = 0; constraintsLabel3.gridy = 4;
			constraintsLabel3.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel3.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel3(), constraintsLabel3);

			java.awt.GridBagConstraints constraintsLabel4 = new java.awt.GridBagConstraints();
			constraintsLabel4.gridx = 0; constraintsLabel4.gridy = 5;
			constraintsLabel4.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel4.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel4(), constraintsLabel4);

			java.awt.GridBagConstraints constraintsLabel5 = new java.awt.GridBagConstraints();
			constraintsLabel5.gridx = 0; constraintsLabel5.gridy = 6;
			constraintsLabel5.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel5.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel5(), constraintsLabel5);

			java.awt.GridBagConstraints constraintsLabel6 = new java.awt.GridBagConstraints();
			constraintsLabel6.gridx = 0; constraintsLabel6.gridy = 7;
			constraintsLabel6.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel6.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel6(), constraintsLabel6);

			java.awt.GridBagConstraints constraintsLabel7 = new java.awt.GridBagConstraints();
			constraintsLabel7.gridx = 0; constraintsLabel7.gridy = 8;
			constraintsLabel7.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel7.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel7(), constraintsLabel7);

			java.awt.GridBagConstraints constraintsLabel8 = new java.awt.GridBagConstraints();
			constraintsLabel8.gridx = 0; constraintsLabel8.gridy = 9;
			constraintsLabel8.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel8.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel8(), constraintsLabel8);

			java.awt.GridBagConstraints constraintsLabel9 = new java.awt.GridBagConstraints();
			constraintsLabel9.gridx = 0; constraintsLabel9.gridy = 10;
			constraintsLabel9.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel9.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel9(), constraintsLabel9);

			java.awt.GridBagConstraints constraintsLabel10 = new java.awt.GridBagConstraints();
			constraintsLabel10.gridx = 0; constraintsLabel10.gridy = 11;
			constraintsLabel10.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel10.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel10(), constraintsLabel10);

			java.awt.GridBagConstraints constraintsLabel11 = new java.awt.GridBagConstraints();
			constraintsLabel11.gridx = 0; constraintsLabel11.gridy = 12;
			constraintsLabel11.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel11.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel11(), constraintsLabel11);

			java.awt.GridBagConstraints constraintsLabel12 = new java.awt.GridBagConstraints();
			constraintsLabel12.gridx = 0; constraintsLabel12.gridy = 13;
			constraintsLabel12.anchor = java.awt.GridBagConstraints.WEST;
			constraintsLabel12.insets = new java.awt.Insets(0, 10, 0, 0);
			getContentsPane().add(getLabel12(), constraintsLabel12);

			java.awt.GridBagConstraints constraintsAnchorChoice = new java.awt.GridBagConstraints();
			constraintsAnchorChoice.gridx = 1; constraintsAnchorChoice.gridy = 3;
			constraintsAnchorChoice.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getAnchorChoice(), constraintsAnchorChoice);

			java.awt.GridBagConstraints constraintsFillChoice = new java.awt.GridBagConstraints();
			constraintsFillChoice.gridx = 1; constraintsFillChoice.gridy = 4;
			constraintsFillChoice.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getFillChoice(), constraintsFillChoice);

			java.awt.GridBagConstraints constraintsTextField1 = new java.awt.GridBagConstraints();
			constraintsTextField1.gridx = 1; constraintsTextField1.gridy = 5;
			constraintsTextField1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField1(), constraintsTextField1);

			java.awt.GridBagConstraints constraintsTextField2 = new java.awt.GridBagConstraints();
			constraintsTextField2.gridx = 1; constraintsTextField2.gridy = 6;
			constraintsTextField2.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField2(), constraintsTextField2);

			java.awt.GridBagConstraints constraintsTextField3 = new java.awt.GridBagConstraints();
			constraintsTextField3.gridx = 1; constraintsTextField3.gridy = 7;
			constraintsTextField3.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField3(), constraintsTextField3);

			java.awt.GridBagConstraints constraintsTextField4 = new java.awt.GridBagConstraints();
			constraintsTextField4.gridx = 1; constraintsTextField4.gridy = 8;
			constraintsTextField4.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField4(), constraintsTextField4);

			java.awt.GridBagConstraints constraintsPanel1 = new java.awt.GridBagConstraints();
			constraintsPanel1.gridx = 1; constraintsPanel1.gridy = 9;
			constraintsPanel1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsPanel1.anchor = java.awt.GridBagConstraints.WEST;
			getContentsPane().add(getPanel1(), constraintsPanel1);

			java.awt.GridBagConstraints constraintsTextField9 = new java.awt.GridBagConstraints();
			constraintsTextField9.gridx = 1; constraintsTextField9.gridy = 10;
			constraintsTextField9.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField9(), constraintsTextField9);

			java.awt.GridBagConstraints constraintsTextField10 = new java.awt.GridBagConstraints();
			constraintsTextField10.gridx = 1; constraintsTextField10.gridy = 11;
			constraintsTextField10.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField10(), constraintsTextField10);

			java.awt.GridBagConstraints constraintsTextField11 = new java.awt.GridBagConstraints();
			constraintsTextField11.gridx = 1; constraintsTextField11.gridy = 12;
			constraintsTextField11.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField11(), constraintsTextField11);

			java.awt.GridBagConstraints constraintsTextField12 = new java.awt.GridBagConstraints();
			constraintsTextField12.gridx = 1; constraintsTextField12.gridy = 13;
			constraintsTextField12.fill = java.awt.GridBagConstraints.HORIZONTAL;
			getContentsPane().add(getTextField12(), constraintsTextField12);

			java.awt.GridBagConstraints constraintsPanel2 = new java.awt.GridBagConstraints();
			constraintsPanel2.gridx = 1; constraintsPanel2.gridy = 14;
			constraintsPanel2.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsPanel2.weighty = 1.0;
			getContentsPane().add(getPanel2(), constraintsPanel2);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjContentsPane;
}
/**
 * Return the FillChoice property value.
 * @return java.awt.Choice
 */
private java.awt.Choice getFillChoice() {
	if (ivjFillChoice == null) {
		try {
			ivjFillChoice = new java.awt.Choice();
			ivjFillChoice.setName("FillChoice");
			initializeFillChoice(ivjFillChoice); 
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjFillChoice;
}
/**
 * Return the GridBagBean1 property value.
 * @return com.ibm.ivj.examples.vc.utilitybeans.GridBagBean
 */
private GridBagBean getGridBagBean1() {
	if (ivjGridBagBean1 == null) {
		try {
			ivjGridBagBean1 = new com.ibm.ivj.examples.vc.utilitybeans.GridBagBean();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGridBagBean1;
}
/**
 * Static method for getting GridBagLayout from parent of a Component
 * Returns null if the argument component's parent's layout is not a
 * 	GridBagLayout.
 */
protected static java.awt.GridBagLayout getGridBagComponentLayout(java.awt.Component gridBagComponent) {

	java.awt.GridBagLayout layout = null;
	if (gridBagComponent != null &&
			gridBagComponent.getParent() != null &&
			gridBagComponent.getParent().getLayout() != null &&
			gridBagComponent.getParent().getLayout() instanceof java.awt.GridBagLayout)
		layout =	(java.awt.GridBagLayout)(gridBagComponent.getParent().getLayout());
	return layout;
}
/**
 * Return the GridBagLayout1 property value.
 * @return java.awt.GridBagLayout
 */
private java.awt.GridBagLayout getGridBagLayout1() {
	return ivjGridBagLayout1;
}
/**
 * Return the gridBagPanel property value.
 * @return java.awt.Panel
 */
public java.awt.Panel getgridBagPanel() {
	return ivjgridBagPanel;
}
/**
 * Gets the gridBagPanel property (java.awt.Panel) value.
 * @return The gridBagPanel property value.
 * @see #setGridBagPanel
 */
public java.awt.Panel getGridBagPanel() {
	return fieldGridBagPanel;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Select a component");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label10 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel10() {
	if (ivjLabel10 == null) {
		try {
			ivjLabel10 = new java.awt.Label();
			ivjLabel10.setName("Label10");
			ivjLabel10.setText("ipadY");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel10;
}
/**
 * Return the Label11 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel11() {
	if (ivjLabel11 == null) {
		try {
			ivjLabel11 = new java.awt.Label();
			ivjLabel11.setName("Label11");
			ivjLabel11.setText("weightX");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel11;
}
/**
 * Return the Label12 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel12() {
	if (ivjLabel12 == null) {
		try {
			ivjLabel12 = new java.awt.Label();
			ivjLabel12.setName("Label12");
			ivjLabel12.setText("weightY");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel12;
}
/**
 * Return the Label13 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel13() {
	if (ivjLabel13 == null) {
		try {
			ivjLabel13 = new java.awt.Label();
			ivjLabel13.setName("Label13");
			ivjLabel13.setAlignment(java.awt.Label.RIGHT);
			ivjLabel13.setText("T");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel13;
}
/**
 * Return the Label14 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel14() {
	if (ivjLabel14 == null) {
		try {
			ivjLabel14 = new java.awt.Label();
			ivjLabel14.setName("Label14");
			ivjLabel14.setAlignment(java.awt.Label.RIGHT);
			ivjLabel14.setText("L");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel14;
}
/**
 * Return the Label15 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel15() {
	if (ivjLabel15 == null) {
		try {
			ivjLabel15 = new java.awt.Label();
			ivjLabel15.setName("Label15");
			ivjLabel15.setAlignment(java.awt.Label.RIGHT);
			ivjLabel15.setText("R");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel15;
}
/**
 * Return the Label16 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel16() {
	if (ivjLabel16 == null) {
		try {
			ivjLabel16 = new java.awt.Label();
			ivjLabel16.setName("Label16");
			ivjLabel16.setAlignment(java.awt.Label.RIGHT);
			ivjLabel16.setText("B");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel16;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("anchor");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("fill");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("gridHeight");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setText("gridWidth");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setText("gridX");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel6;
}
/**
 * Return the Label7 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel7() {
	if (ivjLabel7 == null) {
		try {
			ivjLabel7 = new java.awt.Label();
			ivjLabel7.setName("Label7");
			ivjLabel7.setText("gridY");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel7;
}
/**
 * Return the Label8 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel8() {
	if (ivjLabel8 == null) {
		try {
			ivjLabel8 = new java.awt.Label();
			ivjLabel8.setName("Label8");
			ivjLabel8.setText("insets");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel8;
}
/**
 * Return the Label9 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel9() {
	if (ivjLabel9 == null) {
		try {
			ivjLabel9 = new java.awt.Label();
			ivjLabel9.setName("Label9");
			ivjLabel9.setText("ipadX");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel9;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(new java.awt.FlowLayout());
			ivjPanel1.add(getLabel13());
			getPanel1().add(getTextField5(), getTextField5().getName());
			getPanel1().add(getLabel14(), getLabel14().getName());
			getPanel1().add(getTextField6(), getTextField6().getName());
			getPanel1().add(getLabel15(), getLabel15().getName());
			getPanel1().add(getTextField7(), getTextField7().getName());
			getPanel1().add(getLabel16(), getLabel16().getName());
			getPanel1().add(getTextField8(), getTextField8().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the Panel2 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel2() {
	if (ivjPanel2 == null) {
		try {
			ivjPanel2 = new java.awt.Panel();
			ivjPanel2.setName("Panel2");
			ivjPanel2.setLayout(new java.awt.GridLayout());
			ivjPanel2.add(getButton3());
			getPanel2().add(getButton4(), getButton4().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel2;
}
/**
 * Accessor for the propertyChange field.
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
			ivjTextField1.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField10 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField10() {
	if (ivjTextField10 == null) {
		try {
			ivjTextField10 = new java.awt.TextField();
			ivjTextField10.setName("TextField10");
			ivjTextField10.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField10;
}
/**
 * Return the TextField11 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField11() {
	if (ivjTextField11 == null) {
		try {
			ivjTextField11 = new java.awt.TextField();
			ivjTextField11.setName("TextField11");
			ivjTextField11.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField11;
}
/**
 * Return the TextField12 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField12() {
	if (ivjTextField12 == null) {
		try {
			ivjTextField12 = new java.awt.TextField();
			ivjTextField12.setName("TextField12");
			ivjTextField12.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField12;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Return the TextField4 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField4() {
	if (ivjTextField4 == null) {
		try {
			ivjTextField4 = new java.awt.TextField();
			ivjTextField4.setName("TextField4");
			ivjTextField4.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField4;
}
/**
 * Return the TextField5 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField5() {
	if (ivjTextField5 == null) {
		try {
			ivjTextField5 = new java.awt.TextField();
			ivjTextField5.setName("TextField5");
			ivjTextField5.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField5;
}
/**
 * Return the TextField6 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField6() {
	if (ivjTextField6 == null) {
		try {
			ivjTextField6 = new java.awt.TextField();
			ivjTextField6.setName("TextField6");
			ivjTextField6.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField6;
}
/**
 * Return the TextField7 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField7() {
	if (ivjTextField7 == null) {
		try {
			ivjTextField7 = new java.awt.TextField();
			ivjTextField7.setName("TextField7");
			ivjTextField7.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField7;
}
/**
 * Return the TextField8 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField8() {
	if (ivjTextField8 == null) {
		try {
			ivjTextField8 = new java.awt.TextField();
			ivjTextField8.setName("TextField8");
			ivjTextField8.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField8;
}
/**
 * Return the TextField9 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField9() {
	if (ivjTextField9 == null) {
		try {
			ivjTextField9 = new java.awt.TextField();
			ivjTextField9.setName("TextField9");
			ivjTextField9.setText("0");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField9;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	this.addWindowListener(this);
	this.addPropertyChangeListener(this);
	getChoice1().addItemListener(this);
	getButton3().addActionListener(this);
	getButton4().addActionListener(this);
	getAnchorChoice().addItemListener(this);
	getGridBagBean1().addPropertyChangeListener(this);
	getFillChoice().addItemListener(this);
	getTextField1().addTextListener(this);
	getTextField2().addTextListener(this);
	getTextField3().addTextListener(this);
	getTextField4().addTextListener(this);
	getTextField5().addTextListener(this);
	getTextField6().addTextListener(this);
	getTextField7().addTextListener(this);
	getTextField8().addTextListener(this);
	getTextField9().addTextListener(this);
	getTextField10().addTextListener(this);
	getTextField11().addTextListener(this);
	getTextField12().addTextListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP6SetTarget();
	connPtoP7SetTarget();
	connPtoP8SetTarget();
	connPtoP9SetTarget();
	connPtoP10SetTarget();
	connPtoP11SetTarget();
	connPtoP12SetTarget();
	connPtoP13SetTarget();
	connPtoP14SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("LiveGridBagConstraints");
		setLayout(new java.awt.BorderLayout());
		setSize(375, 375);
		setTitle("Live! GridBagConstraints");
		add(getContentsPane(), "Center");
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * This method was created by a SmartGuide.
 * @param anchorChoice java.awt.Choice
 */
public static void initializeAnchorChoice(java.awt.Choice anchorChoice) {
			anchorChoice.addItem("CENTER");
			anchorChoice.addItem("EAST");
			anchorChoice.addItem("NORTH");
			anchorChoice.addItem("NORTHEAST");
			anchorChoice.addItem("NORTHWEST");
			anchorChoice.addItem("SOUTH");
			anchorChoice.addItem("SOUTHEAST");
			anchorChoice.addItem("SOUTHWEST");
			anchorChoice.addItem("WEST");
}
/**
 * This method was created by a SmartGuide.
 * @param anchorChoice java.awt.Choice
 */
public static void initializeFillChoice(java.awt.Choice fillChoice) {
			fillChoice.addItem("BOTH");
			fillChoice.addItem("HORIZONTAL");
			fillChoice.addItem("NONE");
			fillChoice.addItem("VERTICAL");
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	if (e.getSource() == getChoice1()) 
		connEtoM1(e);
	if (e.getSource() == getChoice1()) 
		connEtoM4(e);
	if (e.getSource() == getAnchorChoice()) 
		connEtoM6(e);
	if (e.getSource() == getFillChoice()) 
		connEtoM8(e);
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints aLiveGridBagConstraints;
		aLiveGridBagConstraints = new com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aLiveGridBagConstraints };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aLiveGridBagConstraints.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Frame");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == this && (evt.getPropertyName().equals("gridBagPanel"))) 
		connPtoP1SetTarget();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("anchor"))) 
		connEtoM7(evt);
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("fill"))) 
		connEtoM9(evt);
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("gridHeight"))) 
		connPtoP3SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("gridWidth"))) 
		connPtoP4SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("gridX"))) 
		connPtoP5SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("gridY"))) 
		connPtoP6SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("insetsTop"))) 
		connPtoP7SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("insetsLeft"))) 
		connPtoP8SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("insetsRight"))) 
		connPtoP9SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("insetsBottom"))) 
		connPtoP10SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("ipadX"))) 
		connPtoP11SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("ipadY"))) 
		connPtoP12SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("weightX"))) 
		connPtoP13SetSource();
	if (evt.getSource() == getGridBagBean1() && (evt.getPropertyName().equals("weightY"))) 
		connPtoP14SetSource();
}
/**
 * Static method for refreshing a java.awt.Choice component with new
 * values that represent the list of components in the GridBagPanel.
 */
protected static void refreshComponentChoice(java.awt.Choice awtChoice, java.awt.Panel gridBagPanel) {
	/* fill a Choice component with a list of components' string values */
	java.awt.Component[] components = gridBagPanel.getComponents();
	awtChoice.removeAll();
	for (int i=0;i<components.length;i++)
	{
		java.awt.Component comp = components[i];
		awtChoice.addItem(comp.getName() + " " + comp);
	}
	awtChoice.select(0);
	
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Set the Component1 to a new value.
 * @param newValue java.awt.Component
 */
private void setComponent1(java.awt.Component newValue) {
	if (ivjComponent1 != newValue) {
		try {
			ivjComponent1 = newValue;
			connEtoM5(ivjComponent1);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the GridBagLayout1 to a new value.
 * @param newValue java.awt.GridBagLayout
 */
private void setGridBagLayout1(java.awt.GridBagLayout newValue) {
	if (ivjGridBagLayout1 != newValue) {
		try {
			ivjGridBagLayout1 = newValue;
			connPtoP2SetSource();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the gridBagPanel to a new value.
 * @param newValue java.awt.Panel
 */
public void setgridBagPanel(java.awt.Panel newValue) {
	if (ivjgridBagPanel != newValue) {
		try {
			java.awt.Panel oldValue = getgridBagPanel();
			ivjgridBagPanel = newValue;
			connPtoP1SetSource();
			connEtoC2(ivjgridBagPanel);
			connEtoM2(ivjgridBagPanel);
			connPtoP2SetTarget();
			firePropertyChange("gridBagPanel", oldValue, newValue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Sets the gridBagPanel property (java.awt.Panel) value.
 * @param gridBagPanel The new value for the property.
 * @see #getGridBagPanel
 */
public void setGridBagPanel(java.awt.Panel gridBagPanel) {
	java.awt.Panel oldValue = fieldGridBagPanel;
	fieldGridBagPanel = gridBagPanel;
	firePropertyChange("gridBagPanel", oldValue, gridBagPanel);
}
/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
public void textValueChanged(java.awt.event.TextEvent e) {
	if (e.getSource() == getTextField1()) 
		connPtoP3SetTarget();
	if (e.getSource() == getTextField2()) 
		connPtoP4SetTarget();
	if (e.getSource() == getTextField3()) 
		connPtoP5SetTarget();
	if (e.getSource() == getTextField4()) 
		connPtoP6SetTarget();
	if (e.getSource() == getTextField5()) 
		connPtoP7SetTarget();
	if (e.getSource() == getTextField6()) 
		connPtoP8SetTarget();
	if (e.getSource() == getTextField7()) 
		connPtoP9SetTarget();
	if (e.getSource() == getTextField8()) 
		connPtoP10SetTarget();
	if (e.getSource() == getTextField9()) 
		connPtoP11SetTarget();
	if (e.getSource() == getTextField10()) 
		connPtoP12SetTarget();
	if (e.getSource() == getTextField11()) 
		connPtoP13SetTarget();
	if (e.getSource() == getTextField12()) 
		connPtoP14SetTarget();
}
/**
 * Static method for replacing the GridBagConstraints of the argument component
 * with the constraints object contained in the GridBagBean.
 */ 
protected static void updateComponentConstraints(java.awt.Component gridBagComponent, GridBagBean gridBagBean ) {
	/* get the layout of the parent of the component */
	java.awt.GridBagLayout layout = getGridBagComponentLayout(gridBagComponent);
	if (layout == null)
		throw new IllegalArgumentException("Component must be in a GridBagLayout container.");
	layout.setConstraints(gridBagComponent, gridBagBean.getGridBagConstraints());
	gridBagComponent.getParent().doLayout();
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowActivated(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowClosed(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowClosing(java.awt.event.WindowEvent e) {
	if (e.getSource() == this) 
		connEtoC1(e);
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowDeactivated(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowDeiconified(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowIconified(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowOpened(java.awt.event.WindowEvent e) {
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
