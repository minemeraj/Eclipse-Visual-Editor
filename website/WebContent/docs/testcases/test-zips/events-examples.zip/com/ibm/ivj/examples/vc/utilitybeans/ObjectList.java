package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/*
 * IBM Visual Age for Java -  ObjectList Class
 * 
 * This class demonstrates how to extend a java awt class, specifically, 
 * how to extend java.awt.List to manage any Objects rather than just Strings.
 * The string that is ultimately displayed in the list is the result of calling
 * the toString() method on the object.
 *
 * To see ObjectList in action, see the CustomerInfoS1 example in the 
 * customerinfo visual composition (vc) package.
 *
 */
public class ObjectList extends java.awt.List {
java.util.Vector objects = new java.util.Vector();
/**
 * ObjectList constructor comment.
 */
public ObjectList() {
	super();
}
/**
 * ObjectList constructor comment.
 * @param rows int
 */
public ObjectList(int rows) {
	super(rows);
}
/**
 * ObjectList constructor comment.
 * @param rows int
 * @param multipleMode boolean
 */
public ObjectList(int rows, boolean multipleMode) {
	super(rows, multipleMode);
}
/**
 * This method was created by a SmartGuide.
 * @param object java.lang.Object
 */
public void add(Object object) {
	addObject(object, -1);
}
	/**
	 * Adds the specified object to the scrolling list at the specified
	 * position.
	 * @param item the item to be added
	 * @param index the position at which to put in the item. The
	 * index is zero-based. If index is -1 then the item is added to
	 * the end. If index is greater than the number of items in the
	 * list, the item gets added at the end.
	 */
	public synchronized void add(Object object, int index) {
	addObject(object, index);
	}
	/**
	 * Adds the specified item to the scrolling list at the specified
	 * position.
	 * @param item the item to be added
	 * @param index the position at which to put in the item. The
	 * index is zero-based. If index is -1 then the item is added to
	 * the end. If index is greater than the number of items in the
	 * list, the item gets added at the end.
	 */
	public synchronized void addItem(String item, int index)
	{
		addObject((Object)item, index);
	}
	/**
	 * Adds the specified item to the end of scrolling list.
	 * @param item the item to be added
	 */
	public void addObject(Object object) {
	addObject(object, -1);
	}
	/**
	 * Adds the specified object to the scrolling list at the specified
	 * position.
	 * @param object the object to be added
	 * @param index the position at which to put in the item. The
	 * index is zero-based. If index is -1 then the item is added to
	 * the end. If index is greater than the number of items in the
	 * list, the item gets added at the end.
	 */
	public synchronized void addObject(Object object, int index)
	{
		super.addItem(object.toString(), index);

		if (index < -1 || index >= getItemCount())
			index = -1;

		if (index == -1)
	   	objects.addElement(object);
		else
	   	objects.insertElementAt(object, index);
	}
	/**
	 * Removes an item from the list.
	 */
	public synchronized void delItem(int position)
	{
		objects.removeElementAt(position);
		super.delItem(position);
	}
	/**
	 * Removes an object from the list.
	 */
	public synchronized void delObject(int position)
	{
		delItem(position);
	}
	/**
	 * Gets the object associated with the specified index.
	 * @param index the position of the item
	 * @see #getObjectCount
	 */
	public Object getObject(int index) {
	return objects.elementAt(index);
	}
	/**
	 * Returns the number of objects in the list.
	 * @see #getObject
	 */
	public int getObjectCount() {
	return getItemCount();
	}
	/**
	 * Returns the objects in the list.
	 * @see #select
	 * @see #deselect
	 * @see #isIndexSelected
	 */
	public synchronized Object[] getObjects() {
	Object itemCopies[] = new Object[getObjectCount()];
	objects.copyInto(itemCopies);
	return itemCopies;
	}
	/**
	 * Returns the selected object on the list or null if no object is selected.
	 * @see #select
	 * @see #deselect
	 * @see #isIndexSelected
	 */
	public synchronized Object getSelectedObject() {
	int index = getSelectedIndex();
	return (index < 0) ? null : getObject(index);
	}
	/**
	 * Returns the selected objects on the list in an array of Objects.
	 * @see #select
	 * @see #deselect
	 * @see #isIndexSelected
	 */
	public synchronized Object[] getSelectedObjects() {
	int sel[] = getSelectedIndexes();
	Object str[] = new Object[sel.length];
	for (int i = 0 ; i < sel.length ; i++) {
	    str[i] = getObject(sel[i]);
	}
	return str;
	}
	/**
	 * Removes all items from the list.
	 * @see #remove
	 * @see #delItems
	 */
	public synchronized void removeAll() {
	objects = new java.util.Vector();
	super.removeAll();
	}
	/**
	 * Replaces the object at the given index.
	 * @param newObject the new object to replace the existing object
	 * @param index the position of the object to replace
	 */
	public synchronized void replaceObject(Object object, int index) {
	remove(index);
	add(object, index);
	}
	/**
	 * Select the first occurrence of object from the list.
	 * @param object  the object to select from the list
	 * @exception IllegalArgumentException  If the object doesn't exist in the list.
	 */
	public synchronized void select(Object object) {
		int index = objects.indexOf(object);
		if (index < 0) {
	    throw new IllegalArgumentException("object " + object +
					       " not found in list");
	} else {
	    select(index);
	}
	}
}
