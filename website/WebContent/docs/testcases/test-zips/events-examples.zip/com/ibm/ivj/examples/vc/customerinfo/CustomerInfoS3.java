package com.ibm.ivj.examples.vc.customerinfo;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class CustomerInfoS3 extends java.awt.Frame {
	private java.awt.Panel ivjContentsPane = null;
	private Customer ivjCustomer1 = null;
	private com.ibm.ivj.examples.vc.utilitybeans.ObjectList ivjCustomerList = null;
	private CustomerView ivjCustomerView1 = null;
	private java.awt.Button ivjDeleteButton = null;
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Button ivjNewButton = null;
	private java.awt.Panel ivjPanel1 = null;
	private java.awt.Button ivjUpdateButton = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public CustomerInfoS3() {
	super();
	initialize();
}
/**
 * CustomerInfoS1 constructor comment.
 * @param title java.lang.String
 */
public CustomerInfoS3(String title) {
	super(title);
}
/**
 * connEtoC1:  (CustomerInfoS1.window.windowClosing(java.awt.event.WindowEvent) --> CustomerInfoS1.dispose()V)
 * @param arg1 java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.WindowEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> CustomerInfoS1.showMessageBox()I)
 * @return int
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private int connEtoC2(java.awt.event.ActionEvent arg1) {
	int connEtoC2Result = 0;
	try {
		// user code begin {1}
		// user code end
		connEtoC2Result = this.showMessageBox();
		connEtoC3(connEtoC2Result);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
	return connEtoC2Result;
}
/**
 * connEtoC3:  ( (DeleteButton,action.actionPerformed(java.awt.event.ActionEvent) --> CustomerInfoS1,showMessageBox()I).normalResult --> CustomerInfoS1.messageBoxAction(I)V)
 * @param result int
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(int result) {
	try {
		// user code begin {1}
		// user code end
		this.messageBoxAction(result);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (CustomerList.item.itemStateChanged(java.awt.event.ItemEvent) --> CustomerInfoS1.setButtonState()V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.setButtonState();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (UpdateButton.action.actionPerformed(java.awt.event.ActionEvent) --> CustomerInfoS1.setButtonState()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.setButtonState();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (NewButton.action.actionPerformed(java.awt.event.ActionEvent) --> CustomerList.addObject(Ljava.lang.Object;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getCustomerList().addObject(getCustomer1().clone());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (UpdateButton.action.actionPerformed(java.awt.event.ActionEvent) --> CustomerList.replaceObject(Ljava.lang.Object;I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getCustomerList().replaceObject(getCustomer1().clone(), getCustomerList().getSelectedIndex());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (CustomerList.item.itemStateChanged(java.awt.event.ItemEvent) --> Customer1.copyFrom(Lcom.ibm.ivj.examples.vc.customerinfo.Customer;)V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getCustomer1().copyFrom((com.ibm.ivj.examples.vc.customerinfo.Customer)getCustomerList().getSelectedObject());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> NewButton.enabled)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getNewButton().setEnabled(false);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> UpdateButton.enabled)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getUpdateButton().setEnabled(false);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (Customer1.this <--> CustomerView1.customer1This)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getCustomerView1().setCustomer1This(getCustomer1());
		// user code begin {1}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the ContentsPane property value.
 * @return java.awt.Panel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Panel getContentsPane() {
	if (ivjContentsPane == null) {
		try {
			ivjContentsPane = new java.awt.Panel();
			ivjContentsPane.setName("ContentsPane");
			ivjContentsPane.setLayout(new java.awt.GridBagLayout());
			ivjContentsPane.setBackground(java.awt.Color.lightGray);

			java.awt.GridBagConstraints constraintsLabel1 = new java.awt.GridBagConstraints();
			constraintsLabel1.gridx = 0; constraintsLabel1.gridy = 0;
			constraintsLabel1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsLabel1.insets = new java.awt.Insets(0, 5, 0, 5);
			getContentsPane().add(getLabel1(), constraintsLabel1);

			java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
			constraintsLabel2.gridx = 1; constraintsLabel2.gridy = 0;
			constraintsLabel2.insets = new java.awt.Insets(0, 5, 0, 0);
			getContentsPane().add(getLabel2(), constraintsLabel2);

			java.awt.GridBagConstraints constraintsCustomerList = new java.awt.GridBagConstraints();
			constraintsCustomerList.gridx = 0; constraintsCustomerList.gridy = 1;
			constraintsCustomerList.gridwidth = 2;
			constraintsCustomerList.fill = java.awt.GridBagConstraints.BOTH;
			constraintsCustomerList.weightx = 1.0;
			constraintsCustomerList.weighty = 1.0;
			constraintsCustomerList.insets = new java.awt.Insets(10, 10, 10, 10);
			getContentsPane().add(getCustomerList(), constraintsCustomerList);

			java.awt.GridBagConstraints constraintsCustomerView1 = new java.awt.GridBagConstraints();
			constraintsCustomerView1.gridx = 0; constraintsCustomerView1.gridy = 2;
			constraintsCustomerView1.gridwidth = 2;
			constraintsCustomerView1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsCustomerView1.weightx = 1.0;
			constraintsCustomerView1.insets = new java.awt.Insets(0, 20, 0, 20);
			getContentsPane().add(getCustomerView1(), constraintsCustomerView1);

			java.awt.GridBagConstraints constraintsPanel1 = new java.awt.GridBagConstraints();
			constraintsPanel1.gridx = 0; constraintsPanel1.gridy = 3;
			constraintsPanel1.gridwidth = 2;
			constraintsPanel1.anchor = java.awt.GridBagConstraints.EAST;
			constraintsPanel1.insets = new java.awt.Insets(10, 10, 10, 10);
			getContentsPane().add(getPanel1(), constraintsPanel1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjContentsPane;
}
/**
 * Return the Customer1 property value.
 * @return com.ibm.ivj.examples.vc.customerinfo.Customer
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private Customer getCustomer1() {
	if (ivjCustomer1 == null) {
		try {
			ivjCustomer1 = new com.ibm.ivj.examples.vc.customerinfo.Customer();
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjCustomer1;
}
/**
 * Return the CustomerList property value.
 * @return com.ibm.ivj.examples.vc.utilitybeans.ObjectList
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.ibm.ivj.examples.vc.utilitybeans.ObjectList getCustomerList() {
	if (ivjCustomerList == null) {
		try {
			ivjCustomerList = new com.ibm.ivj.examples.vc.utilitybeans.ObjectList();
			ivjCustomerList.setName("CustomerList");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjCustomerList;
}
/**
 * Return the CustomerView1 property value.
 * @return com.ibm.ivj.examples.vc.customerinfo.CustomerView
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private CustomerView getCustomerView1() {
	if (ivjCustomerView1 == null) {
		try {
			ivjCustomerView1 = new com.ibm.ivj.examples.vc.customerinfo.CustomerView();
			ivjCustomerView1.setName("CustomerView1");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjCustomerView1;
}
/**
 * Return the DeleteButton property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Button getDeleteButton() {
	if (ivjDeleteButton == null) {
		try {
			ivjDeleteButton = new java.awt.Button();
			ivjDeleteButton.setName("DeleteButton");
			ivjDeleteButton.setEnabled(false);
			ivjDeleteButton.setLabel("Delete");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDeleteButton;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Press New to create a customer");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("or  select a customer and press Update or Delete");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the NewButton property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Button getNewButton() {
	if (ivjNewButton == null) {
		try {
			ivjNewButton = new java.awt.Button();
			ivjNewButton.setName("NewButton");
			ivjNewButton.setLabel("New");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjNewButton;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(new java.awt.FlowLayout());
			ivjPanel1.add(getNewButton());
			getPanel1().add(getUpdateButton(), getUpdateButton().getName());
			getPanel1().add(getDeleteButton(), getDeleteButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the UpdateButton property value.
 * @return java.awt.Button
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.Button getUpdateButton() {
	if (ivjUpdateButton == null) {
		try {
			ivjUpdateButton = new java.awt.Button();
			ivjUpdateButton.setName("UpdateButton");
			ivjUpdateButton.setEnabled(false);
			ivjUpdateButton.setLabel("Update");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjUpdateButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() throws java.lang.Exception {
	// user code begin {1}
	// user code end
	this.addWindowListener(new java.awt.event.WindowAdapter() {
		public void windowClosing(java.awt.event.WindowEvent e) {
			connEtoC1(e);
		};
	});
	getNewButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoM1(e);
		};
	});
	getUpdateButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoM2(e);
		};
	});
	getCustomerList().addItemListener(new java.awt.event.ItemListener() {
		public void itemStateChanged(java.awt.event.ItemEvent e) {
			connEtoM3(e);
		};
	});
	getCustomerList().addItemListener(new java.awt.event.ItemListener() {
		public void itemStateChanged(java.awt.event.ItemEvent e) {
			connEtoC4(e);
		};
	});
	getUpdateButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoC5(e);
		};
	});
	getDeleteButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoM4(e);
		};
	});
	getDeleteButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoM5(e);
		};
	});
	getDeleteButton().addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			connEtoC2(e);
		};
	});
	connPtoP1SetTarget();
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("CustomerInfoS1");
		setLayout(new java.awt.BorderLayout());
		setSize(500, 400);
		add(getContentsPane(), "Center");
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.ibm.ivj.examples.vc.customerinfo.CustomerInfoS3 aCustomerInfo;
		aCustomerInfo = new com.ibm.ivj.examples.vc.customerinfo.CustomerInfoS3();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aCustomerInfo };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aCustomerInfo.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Frame");
		exception.printStackTrace(System.out);
	}
}
/**
 * Comment
 */
public void messageBoxAction(int selectedOption) {
	if (selectedOption == 0)
		ivjCustomerList.delObject(ivjCustomerList.getSelectedIndex());
	else
		if (selectedOption == 1)
			ivjCustomerList.deselect(ivjCustomerList.getSelectedIndex());
		else
			if (selectedOption == 2)
				ivjCustomerList.removeAll();
	setButtonState();
	this.repaint(1);
	return;
}
/**
 * This method was created in VisualAge.
 */
protected void setButtonState() {
	if (getCustomerList().getSelectedIndex() >= 0) {
		getUpdateButton().setEnabled(true);
		getDeleteButton().setEnabled(true);
		getNewButton().setEnabled(false);
	} else {
		getUpdateButton().setEnabled(false);
		getDeleteButton().setEnabled(false);
		getNewButton().setEnabled(true);
	}
}
/**
 * Comment
 */
public int showMessageBox() {

	Object[] options = {"Yes", "No","Delete'em All"};
	javax.swing.Icon icon = null;
	Object message = "Do you really want to delete the selected item?";
	Object selectedOption = options[1];
	
	return javax.swing.JOptionPane.showOptionDialog(this,message,"Title",0,3,icon,options, selectedOption);
}
}
