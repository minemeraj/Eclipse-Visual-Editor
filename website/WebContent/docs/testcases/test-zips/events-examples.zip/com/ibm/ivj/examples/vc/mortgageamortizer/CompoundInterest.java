package com.ibm.ivj.examples.vc.mortgageamortizer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class CompoundInterest {
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private double fieldPrincipalAmount = 0;
	private double fieldAmortizationPeriod = 0;
	private double fieldInterestRate = 0;
	private double fieldPaymentsPerYear = 0;
	private double fieldTimesPerYear = 0;
	private double fieldPaymentAmount = 0;
	private double fieldEffectiveAnnualRate = 0;
	private double fieldTotalInterestCost = 0;
	private double fieldInterestRatePerPayment = 0;
	private boolean recalculationNeeded = true;
/**
 * CompoundInterest constructor comment.
 */
public CompoundInterest() {
	super();
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the amortizationPeriod property (double) value.
 * @return The amortizationPeriod property value.
 * @see #setAmortizationPeriod
 */
public double getAmortizationPeriod() {
	return fieldAmortizationPeriod;
}
/**
 * Gets the effectiveAnnualRate property (double) value.
 * @return The effectiveAnnualRate property value.
 * @see #setEffectiveAnnualRate
 */
public double getEffectiveAnnualRate() {
	/* If any input value has changed since last recalc, the recalc */
	if (recalculationNeeded) recalculate ();
	return fieldEffectiveAnnualRate;
}
/**
 * Gets the interestRate property (double) value.
 * @return The interestRate property value.
 * @see #setInterestRate
 */
public double getInterestRate() {
	return fieldInterestRate;
}
/**
 * Gets the interestRatePerPayment property (double) value.
 * @return The interestRatePerPayment property value.
 * @see #setInterestRatePerPayment
 */
public double getInterestRatePerPayment() {
	/* If any input value has changed since last recalc, the recalc */
	if (recalculationNeeded) recalculate ();
	return fieldInterestRatePerPayment;
}
/**
 * Gets the paymentAmount property (double) value.
 * @return The paymentAmount property value.
 * @see #setPaymentAmount
 */
public double getPaymentAmount() {
	/* If any input value has changed since last recalc, the recalc */
	if (recalculationNeeded) recalculate ();
	return fieldPaymentAmount;
}
/**
 * Gets the paymentsPerYear property (double) value.
 * @return The paymentsPerYear property value.
 * @see #setPaymentsPerYear
 */
public double getPaymentsPerYear() {
	return fieldPaymentsPerYear;
}
/**
 * Gets the principalAmount property (double) value.
 * @return The principalAmount property value.
 * @see #setPrincipalAmount
 */
public double getPrincipalAmount() {
	return fieldPrincipalAmount;
}
/**
 * Accessor for the propertyChange field.
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Gets the timesPerYear property (double) value.
 * @return The timesPerYear property value.
 * @see #setTimesPerYear
 */
public double getTimesPerYear() {
	return fieldTimesPerYear;
}
/**
 * Gets the totalInterestCost property (double) value.
 * @return The totalInterestCost property value.
 * @see #setTotalInterestCost
 */
public double getTotalInterestCost() {
	/* If any input value has changed since last recalc, the recalc */
	if (recalculationNeeded) recalculate ();
	return fieldTotalInterestCost;
}
/**
 * This method will perform a recalculation of the amortization
 * data based on a new set of input values, and will reset the 
 * recalculationNeeded flag.
 */
protected synchronized void recalculate() {
	recalculationNeeded = false;

	setEffectiveAnnualRate(
		 Math.exp(getTimesPerYear() *
						Math.log(1.0 + (getInterestRate()/getTimesPerYear())) ) - 1.0);

	setInterestRatePerPayment(
		(Math.exp(Math.log(getEffectiveAnnualRate() + 1.0)
						/(getAmortizationPeriod() * getPaymentsPerYear())) - 1.0)  *
			getAmortizationPeriod() * getPaymentsPerYear());
 		
	setPaymentAmount( getPrincipalAmount() * (getInterestRatePerPayment() / getPaymentsPerYear()) /
		(1.0 - Math.pow(getInterestRatePerPayment() / getPaymentsPerYear() + 1.0 ,
			-1 * getAmortizationPeriod() * getPaymentsPerYear()) )) ;

	setTotalInterestCost( getPaymentAmount() * getAmortizationPeriod() * 
		getPaymentsPerYear() - getPrincipalAmount() );
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Sets the amortizationPeriod property (double) value.
 * @param amortizationPeriod The new value for the property.
 * @see #getAmortizationPeriod
 */
public void setAmortizationPeriod(double amortizationPeriod) {
	double oldValue = fieldAmortizationPeriod;
	fieldAmortizationPeriod = amortizationPeriod;
	/* if an input value has changed, remember to recalculate */
	if (fieldAmortizationPeriod != oldValue) recalculationNeeded = true;
	firePropertyChange("amortizationPeriod", new Double(oldValue), new Double(amortizationPeriod));
}
/**
 * Sets the effectiveAnnualRate property (double) value.
 * @param effectiveAnnualRate The new value for the property.
 * @see #getEffectiveAnnualRate
 */
public void setEffectiveAnnualRate(double effectiveAnnualRate) {
	double oldValue = fieldEffectiveAnnualRate;
	fieldEffectiveAnnualRate = effectiveAnnualRate;
	firePropertyChange("effectiveAnnualRate", new Double(oldValue), new Double(effectiveAnnualRate));
}
/**
 * Sets the interestRate property (double) value.
 * @param interestRate The new value for the property.
 * @see #getInterestRate
 */
public void setInterestRate(double interestRate) {
	double oldValue = fieldInterestRate;
	fieldInterestRate = interestRate;
	/* if an input value has changed, remember to recalculate */
	if ( fieldInterestRate != oldValue ) recalculationNeeded=true;
	/* Scale double to percentage, if necessary. */
	/* This allows the interest rate to be specified as .10 to represent 10%, */
	/* or as 10 to represent 10%. */
	if (fieldInterestRate > 1.0d) fieldInterestRate = fieldInterestRate / 100d;
	firePropertyChange("interestRate", new Double(oldValue), new Double(interestRate));
}
/**
 * Sets the interestRatePerPayment property (double) value.
 * @param interestRatePerPayment The new value for the property.
 * @see #getInterestRatePerPayment
 */
public void setInterestRatePerPayment(double interestRatePerPayment) {
	double oldValue = fieldInterestRatePerPayment;
	fieldInterestRatePerPayment = interestRatePerPayment;
	firePropertyChange("interestRatePerPayment", new Double(oldValue), new Double(interestRatePerPayment));
}
/**
 * Sets the paymentAmount property (double) value.
 * @param paymentAmount The new value for the property.
 * @see #getPaymentAmount
 */
public void setPaymentAmount(double paymentAmount) {
	double oldValue = fieldPaymentAmount;
	fieldPaymentAmount = paymentAmount;
	firePropertyChange("paymentAmount", new Double(oldValue), new Double(paymentAmount));
}
/**
 * Sets the paymentsPerYear property (double) value.
 * @param paymentsPerYear The new value for the property.
 * @see #getPaymentsPerYear
 */
public void setPaymentsPerYear(double paymentsPerYear) {
	double oldValue = fieldPaymentsPerYear;
	fieldPaymentsPerYear = paymentsPerYear;
	/* if an input value has changed, remember to recalculate */
	if (fieldPaymentsPerYear != oldValue) recalculationNeeded = true;
	firePropertyChange("paymentsPerYear", new Double(oldValue), new Double(paymentsPerYear));
}
/**
 * Sets the principalAmount property (double) value.
 * @param principalAmount The new value for the property.
 * @see #getPrincipalAmount
 */
public void setPrincipalAmount(double principalAmount) {
	double oldValue = fieldPrincipalAmount;
	fieldPrincipalAmount = principalAmount;
	/* if an input value has changed, remember to recalculate */
	if (fieldPrincipalAmount != oldValue) recalculationNeeded = true;
	firePropertyChange("principalAmount", new Double(oldValue), new Double(principalAmount));
}
/**
 * Sets the timesPerYear property (double) value.
 * @param timesPerYear The new value for the property.
 * @see #getTimesPerYear
 */
public void setTimesPerYear(double timesPerYear) {
	double oldValue = fieldTimesPerYear;
	fieldTimesPerYear = timesPerYear;
	/* if an input value has changed, remember to recalculate */
	if (fieldTimesPerYear != oldValue) recalculationNeeded = true;
	firePropertyChange("timesPerYear", new Double(oldValue), new Double(timesPerYear));
}
/**
 * Sets the totalInterestCost property (double) value.
 * @param totalInterestCost The new value for the property.
 * @see #getTotalInterestCost
 */
public void setTotalInterestCost(double totalInterestCost) {
	double oldValue = fieldTotalInterestCost;
	fieldTotalInterestCost = totalInterestCost;
	firePropertyChange("totalInterestCost", new Double(oldValue), new Double(totalInterestCost));
}
}
