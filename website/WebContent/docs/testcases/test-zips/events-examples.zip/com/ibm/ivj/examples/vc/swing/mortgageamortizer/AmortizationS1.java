package com.ibm.ivj.examples.vc.swing.mortgageamortizer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class AmortizationS1 extends javax.swing.JApplet implements java.awt.event.ActionListener, java.awt.event.KeyListener, java.awt.event.MouseListener, java.beans.PropertyChangeListener {
	private CompoundInterest ivjCompoundInterest1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="183,413"
	private java.text.NumberFormat ivjCurrencyFormatter = null;  // @jve:visual-info  decl-index=0 visual-constraint="724,84"
	private javax.swing.JPanel ivjJAppletContentPane = null;
	private javax.swing.JButton ivjJButton1 = null;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JLabel ivjJLabel10 = null;
	private javax.swing.JLabel ivjJLabel11 = null;
	private javax.swing.JLabel ivjJLabel12 = null;
	private javax.swing.JLabel ivjJLabel2 = null;
	private javax.swing.JLabel ivjJLabel3 = null;
	private javax.swing.JLabel ivjJLabel4 = null;
	private javax.swing.JLabel ivjJLabel5 = null;
	private javax.swing.JLabel ivjJLabel6 = null;
	private javax.swing.JLabel ivjJLabel7 = null;
	private javax.swing.JLabel ivjJLabel8 = null;
	private javax.swing.JLabel ivjJLabel9 = null;
	private javax.swing.JMenuItem ivjJMenuItem1 = null;
	private javax.swing.JMenuItem ivjJMenuItem2 = null;
	private javax.swing.JPanel ivjJPanel1 = null;
	private javax.swing.JPopupMenu ivjJPopupMenu1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="370,416"
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JSeparator ivjJSeparator1 = null;
	private javax.swing.JTextField ivjJTextField1 = null;
	private javax.swing.JTextField ivjJTextField2 = null;
	private javax.swing.JTextField ivjJTextField3 = null;
	private javax.swing.JTextField ivjJTextField4 = null;
	private javax.swing.JTextField ivjJTextField5 = null;
	private java.text.NumberFormat ivjPercentFormatter = null;  // @jve:visual-info  decl-index=0 visual-constraint="725,178"
	private javax.swing.JTable ivjScrollPaneTable = null;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private boolean ivjConnPtoP5Aligning = false;
	private boolean ivjConnPtoP6Aligning = false;
/**
 * AmortizationS1 constructor comment.
 */
public AmortizationS1() {
	super();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getJButton1()) 
		connEtoM1(e);
	if (e.getSource() == getJButton1()) 
		connEtoM2(e);
	if (e.getSource() == getJButton1()) 
		connEtoM3(e);
	if (e.getSource() == getJMenuItem1()) 
		connEtoM10(e);
	if (e.getSource() == getJMenuItem2()) 
		connEtoM11(e);
}
/**
 * connEtoC1:  (ScrollPaneTable.mouse.mouseReleased(java.awt.event.MouseEvent) --> AmortizationS1.genericPopupDisplay(Ljava.awt.event.MouseEvent;Lcom.sun.java.swing.JPopupMenu;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoC1(java.awt.event.MouseEvent arg1) {
	try {
		this.genericPopupDisplay(arg1, getJPopupMenu1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (JButton1.action.actionPerformed(java.awt.event.ActionEvent) --> JLabel10.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		if ((getCurrencyFormatter() != null)) {
			getJLabel10().setText(getCurrencyFormatter().format(getCompoundInterest1().getPaymentAmount()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM10:  (JMenuItem1.action.actionPerformed(java.awt.event.ActionEvent) --> CompoundInterest1.removeRow(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM10(java.awt.event.ActionEvent arg1) {
	try {
		getCompoundInterest1().removeRow(getScrollPaneTable().getSelectedRow());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM11:  (JMenuItem2.action.actionPerformed(java.awt.event.ActionEvent) --> CompoundInterest1.removeAllRows()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM11(java.awt.event.ActionEvent arg1) {
	try {
		getCompoundInterest1().removeAllRows();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (JButton1.action.actionPerformed(java.awt.event.ActionEvent) --> JLabel11.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		if ((getPercentFormatter() != null)) {
			getJLabel11().setText(getPercentFormatter().format(getCompoundInterest1().getEffectiveAnnualRate()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (JButton1.action.actionPerformed(java.awt.event.ActionEvent) --> JLabel12.text)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		if ((getCurrencyFormatter() != null)) {
			getJLabel12().setText(getCurrencyFormatter().format(getCompoundInterest1().getTotalInterestCost()));
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (AmortizationS1.init() --> CurrencyFormatter.getCurrencyInstance()Ljava.text.NumberFormat;)
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat connEtoM4() {
	java.text.NumberFormat connEtoM4Result = null;
	try {
		connEtoM4Result = java.text.NumberFormat.getCurrencyInstance();
		connEtoM5(connEtoM4Result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	return connEtoM4Result;
}
/**
 * connEtoM5:  ( (AmortizationS1,init() --> CurrencyFormatter,getCurrencyInstance()Ljava.text.NumberFormat;).normalResult --> CurrencyFormatter.this)
 * @param result java.text.NumberFormat
 */
private void connEtoM5(java.text.NumberFormat result) {
	try {
		setCurrencyFormatter(result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (AmortizationS1.init() --> PercentFormatter.getPercentInstance()Ljava.text.NumberFormat;)
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat connEtoM6() {
	java.text.NumberFormat connEtoM6Result = null;
	try {
		connEtoM6Result = java.text.NumberFormat.getPercentInstance();
		connEtoM7(connEtoM6Result);
		connEtoM8(connEtoM6Result);
		connEtoM9(connEtoM6Result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	return connEtoM6Result;
}
/**
 * connEtoM7:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.this)
 * @param result java.text.NumberFormat
 */
private void connEtoM7(java.text.NumberFormat result) {
	try {
		setPercentFormatter(result);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.setMinimumFractionDigits(I)V)
 * @param result java.text.NumberFormat
 */
private void connEtoM8(java.text.NumberFormat result) {
	try {
		getPercentFormatter().setMinimumFractionDigits(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  ( (AmortizationS1,init() --> PercentFormatter,getPercentInstance()Ljava.text.NumberFormat;).normalResult --> PercentFormatter.setMaximumFractionDigits(I)V)
 * @param result java.text.NumberFormat
 */
private void connEtoM9(java.text.NumberFormat result) {
	try {
		getPercentFormatter().setMaximumFractionDigits(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (JTextField1.text <--> CompoundInterest1.principalAmount)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getScrollPaneTable().setModel(getCompoundInterest1());
		getScrollPaneTable().createDefaultColumnsFromModel();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (JTextField1.text <--> CompoundInterest1.principalAmount)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getJTextField1().setText(String.valueOf(getCompoundInterest1().getPrincipalAmount()));
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (JTextField1.text <--> CompoundInterest1.principalAmount)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getCompoundInterest1().setPrincipalAmount(new Double(getJTextField1().getText()).doubleValue());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (JTextField2.text <--> CompoundInterest1.amortizationPeriod)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getJTextField2().setText(String.valueOf(getCompoundInterest1().getAmortizationPeriod()));
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (JTextField2.text <--> CompoundInterest1.amortizationPeriod)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getCompoundInterest1().setAmortizationPeriod(new Double(getJTextField2().getText()).doubleValue());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (JTextField3.text <--> CompoundInterest1.interestRate)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getJTextField3().setText(String.valueOf(getCompoundInterest1().getInterestRate()));
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (JTextField3.text <--> CompoundInterest1.interestRate)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			getCompoundInterest1().setInterestRate(new Double(getJTextField3().getText()).doubleValue());
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (JTextField4.text <--> CompoundInterest1.paymentsPerYear)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getJTextField4().setText(String.valueOf(getCompoundInterest1().getPaymentsPerYear()));
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (JTextField4.text <--> CompoundInterest1.paymentsPerYear)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			getCompoundInterest1().setPaymentsPerYear(new Double(getJTextField4().getText()).doubleValue());
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetSource:  (JTextField5.text <--> CompoundInterest1.timesPerYear)
 */
private void connPtoP6SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getJTextField5().setText(String.valueOf(getCompoundInterest1().getTimesPerYear()));
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetTarget:  (JTextField5.text <--> CompoundInterest1.timesPerYear)
 */
private void connPtoP6SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP6Aligning == false) {
			ivjConnPtoP6Aligning = true;
			getCompoundInterest1().setTimesPerYear(new Double(getJTextField5().getText()).doubleValue());
			ivjConnPtoP6Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP6Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 * @param e java.awt.event.MouseEvent
 * @param p javax.swing.JPopupMenu
 */
protected final void genericPopupDisplay(java.awt.event.MouseEvent e, javax.swing.JPopupMenu p) {
	  if ((e.isPopupTrigger()))  {
	  p.show(e.getComponent(), e.getX(), e.getY());
  }	
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.swing.mortgageamortizer.AmortizationS1 created using VisualAge for Java.";
}
/**
 * Return the CompoundInterest1 property value.
 * @return com.ibm.ivj.examples.vc.swing.mortgageamortizer.CompoundInterest
 */
private CompoundInterest getCompoundInterest1() {
	if (ivjCompoundInterest1 == null) {
		try {
			ivjCompoundInterest1 = new com.ibm.ivj.examples.vc.swing.mortgageamortizer.CompoundInterest();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCompoundInterest1;
}
/**
 * Return the CurrencyFormatter property value.
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat getCurrencyFormatter() {
	return ivjCurrencyFormatter;
}
/**
 * Return the JAppletContentPane property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJAppletContentPane() {
	if (ivjJAppletContentPane == null) {
		try {
			ivjJAppletContentPane = new javax.swing.JPanel();
			ivjJAppletContentPane.setName("JAppletContentPane");
			ivjJAppletContentPane.setLayout(new java.awt.BorderLayout());
			getJAppletContentPane().add(getJLabel1(), "North");
			getJAppletContentPane().add(getJPanel1(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJAppletContentPane;
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new javax.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setText("Re-calculate");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton1;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setOpaque(true);
			ivjJLabel1.setText("Loan Amortization Calculator");
			ivjJLabel1.setBackground(java.awt.Color.green);
			ivjJLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JLabel10 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel10() {
	if (ivjJLabel10 == null) {
		try {
			ivjJLabel10 = new javax.swing.JLabel();
			ivjJLabel10.setName("JLabel10");
			ivjJLabel10.setText("$***,***.**");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel10;
}
/**
 * Return the JLabel11 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel11() {
	if (ivjJLabel11 == null) {
		try {
			ivjJLabel11 = new javax.swing.JLabel();
			ivjJLabel11.setName("JLabel11");
			ivjJLabel11.setText("***.**%");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel11;
}
/**
 * Return the JLabel12 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel12() {
	if (ivjJLabel12 == null) {
		try {
			ivjJLabel12 = new javax.swing.JLabel();
			ivjJLabel12.setName("JLabel12");
			ivjJLabel12.setText("$***,***,***.**");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel12;
}
/**
 * Return the JLabel2 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel2() {
	if (ivjJLabel2 == null) {
		try {
			ivjJLabel2 = new javax.swing.JLabel();
			ivjJLabel2.setName("JLabel2");
			ivjJLabel2.setText("Principal Amount");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel2;
}
/**
 * Return the JLabel3 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel3() {
	if (ivjJLabel3 == null) {
		try {
			ivjJLabel3 = new javax.swing.JLabel();
			ivjJLabel3.setName("JLabel3");
			ivjJLabel3.setText("Amortization Period (Years)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel3;
}
/**
 * Return the JLabel4 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel4() {
	if (ivjJLabel4 == null) {
		try {
			ivjJLabel4 = new javax.swing.JLabel();
			ivjJLabel4.setName("JLabel4");
			ivjJLabel4.setText("Annual Interest Rate");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel4;
}
/**
 * Return the JLabel5 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel5() {
	if (ivjJLabel5 == null) {
		try {
			ivjJLabel5 = new javax.swing.JLabel();
			ivjJLabel5.setName("JLabel5");
			ivjJLabel5.setText("Payments Per Year (#/Yr)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel5;
}
/**
 * Return the JLabel6 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel6() {
	if (ivjJLabel6 == null) {
		try {
			ivjJLabel6 = new javax.swing.JLabel();
			ivjJLabel6.setName("JLabel6");
			ivjJLabel6.setText("Compounded Times Per Year (X/Yr)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel6;
}
/**
 * Return the JLabel7 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel7() {
	if (ivjJLabel7 == null) {
		try {
			ivjJLabel7 = new javax.swing.JLabel();
			ivjJLabel7.setName("JLabel7");
			ivjJLabel7.setText("Payment Amount");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel7;
}
/**
 * Return the JLabel8 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel8() {
	if (ivjJLabel8 == null) {
		try {
			ivjJLabel8 = new javax.swing.JLabel();
			ivjJLabel8.setName("JLabel8");
			ivjJLabel8.setText("Effective Annual Interest Rate(EAR)");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel8;
}
/**
 * Return the JLabel9 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel9() {
	if (ivjJLabel9 == null) {
		try {
			ivjJLabel9 = new javax.swing.JLabel();
			ivjJLabel9.setName("JLabel9");
			ivjJLabel9.setText("Total Interest Cost");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel9;
}
/**
 * Return the JMenuItem1 property value.
 * @return javax.swing.JMenuItem
 */
private javax.swing.JMenuItem getJMenuItem1() {
	if (ivjJMenuItem1 == null) {
		try {
			ivjJMenuItem1 = new javax.swing.JMenuItem();
			ivjJMenuItem1.setName("JMenuItem1");
			ivjJMenuItem1.setText("Delete");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJMenuItem1;
}
/**
 * Return the JMenuItem2 property value.
 * @return javax.swing.JMenuItem
 */
private javax.swing.JMenuItem getJMenuItem2() {
	if (ivjJMenuItem2 == null) {
		try {
			ivjJMenuItem2 = new javax.swing.JMenuItem();
			ivjJMenuItem2.setName("JMenuItem2");
			ivjJMenuItem2.setText("Delete All");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJMenuItem2;
}
/**
 * Return the JPanel1 property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJPanel1() {
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new javax.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			java.awt.GridBagConstraints constraintsJLabel2 = new java.awt.GridBagConstraints();
			constraintsJLabel2.gridx = 0; constraintsJLabel2.gridy = 0;
			constraintsJLabel2.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel2(), constraintsJLabel2);

			java.awt.GridBagConstraints constraintsJLabel3 = new java.awt.GridBagConstraints();
			constraintsJLabel3.gridx = 0; constraintsJLabel3.gridy = 1;
			constraintsJLabel3.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel3(), constraintsJLabel3);

			java.awt.GridBagConstraints constraintsJLabel4 = new java.awt.GridBagConstraints();
			constraintsJLabel4.gridx = 0; constraintsJLabel4.gridy = 2;
			constraintsJLabel4.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel4(), constraintsJLabel4);

			java.awt.GridBagConstraints constraintsJLabel5 = new java.awt.GridBagConstraints();
			constraintsJLabel5.gridx = 0; constraintsJLabel5.gridy = 3;
			constraintsJLabel5.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel5(), constraintsJLabel5);

			java.awt.GridBagConstraints constraintsJLabel6 = new java.awt.GridBagConstraints();
			constraintsJLabel6.gridx = 0; constraintsJLabel6.gridy = 4;
			constraintsJLabel6.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel6(), constraintsJLabel6);

			java.awt.GridBagConstraints constraintsJTextField1 = new java.awt.GridBagConstraints();
			constraintsJTextField1.gridx = 1; constraintsJTextField1.gridy = 0;
			constraintsJTextField1.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJTextField1.insets = new java.awt.Insets(0, 10, 0, 10);
			getJPanel1().add(getJTextField1(), constraintsJTextField1);

			java.awt.GridBagConstraints constraintsJTextField2 = new java.awt.GridBagConstraints();
			constraintsJTextField2.gridx = 1; constraintsJTextField2.gridy = 1;
			constraintsJTextField2.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJTextField2.insets = new java.awt.Insets(0, 10, 0, 10);
			getJPanel1().add(getJTextField2(), constraintsJTextField2);

			java.awt.GridBagConstraints constraintsJTextField3 = new java.awt.GridBagConstraints();
			constraintsJTextField3.gridx = 1; constraintsJTextField3.gridy = 2;
			constraintsJTextField3.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJTextField3.insets = new java.awt.Insets(0, 10, 0, 10);
			getJPanel1().add(getJTextField3(), constraintsJTextField3);

			java.awt.GridBagConstraints constraintsJTextField4 = new java.awt.GridBagConstraints();
			constraintsJTextField4.gridx = 1; constraintsJTextField4.gridy = 3;
			constraintsJTextField4.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJTextField4.insets = new java.awt.Insets(0, 10, 0, 10);
			getJPanel1().add(getJTextField4(), constraintsJTextField4);

			java.awt.GridBagConstraints constraintsJTextField5 = new java.awt.GridBagConstraints();
			constraintsJTextField5.gridx = 1; constraintsJTextField5.gridy = 4;
			constraintsJTextField5.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJTextField5.insets = new java.awt.Insets(0, 10, 0, 10);
			getJPanel1().add(getJTextField5(), constraintsJTextField5);

			java.awt.GridBagConstraints constraintsJLabel7 = new java.awt.GridBagConstraints();
			constraintsJLabel7.gridx = 2; constraintsJLabel7.gridy = 0;
			constraintsJLabel7.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel7(), constraintsJLabel7);

			java.awt.GridBagConstraints constraintsJLabel8 = new java.awt.GridBagConstraints();
			constraintsJLabel8.gridx = 2; constraintsJLabel8.gridy = 1;
			constraintsJLabel8.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel8(), constraintsJLabel8);

			java.awt.GridBagConstraints constraintsJLabel9 = new java.awt.GridBagConstraints();
			constraintsJLabel9.gridx = 2; constraintsJLabel9.gridy = 2;
			constraintsJLabel9.anchor = java.awt.GridBagConstraints.EAST;
			getJPanel1().add(getJLabel9(), constraintsJLabel9);

			java.awt.GridBagConstraints constraintsJLabel10 = new java.awt.GridBagConstraints();
			constraintsJLabel10.gridx = 3; constraintsJLabel10.gridy = 0;
			constraintsJLabel10.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJLabel10.insets = new java.awt.Insets(0, 10, 0, 0);
			getJPanel1().add(getJLabel10(), constraintsJLabel10);

			java.awt.GridBagConstraints constraintsJLabel11 = new java.awt.GridBagConstraints();
			constraintsJLabel11.gridx = 3; constraintsJLabel11.gridy = 1;
			constraintsJLabel11.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJLabel11.insets = new java.awt.Insets(0, 10, 0, 0);
			getJPanel1().add(getJLabel11(), constraintsJLabel11);

			java.awt.GridBagConstraints constraintsJLabel12 = new java.awt.GridBagConstraints();
			constraintsJLabel12.gridx = 3; constraintsJLabel12.gridy = 2;
			constraintsJLabel12.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJLabel12.insets = new java.awt.Insets(0, 10, 0, 0);
			getJPanel1().add(getJLabel12(), constraintsJLabel12);

			java.awt.GridBagConstraints constraintsJButton1 = new java.awt.GridBagConstraints();
			constraintsJButton1.gridx = 2; constraintsJButton1.gridy = 3;
			constraintsJButton1.gridwidth = 2;
constraintsJButton1.gridheight = 2;
			getJPanel1().add(getJButton1(), constraintsJButton1);

			java.awt.GridBagConstraints constraintsJScrollPane1 = new java.awt.GridBagConstraints();
			constraintsJScrollPane1.gridx = 0; constraintsJScrollPane1.gridy = 5;
			constraintsJScrollPane1.gridwidth = 4;
			constraintsJScrollPane1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsJScrollPane1.insets = new java.awt.Insets(40, 10, 0, 10);
			getJPanel1().add(getJScrollPane1(), constraintsJScrollPane1);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPanel1;
}
/**
 * Return the JPopupMenu1 property value.
 * @return javax.swing.JPopupMenu
 */
private javax.swing.JPopupMenu getJPopupMenu1() {
	if (ivjJPopupMenu1 == null) {
		try {
			ivjJPopupMenu1 = new javax.swing.JPopupMenu();
			ivjJPopupMenu1.setName("JPopupMenu1");
			ivjJPopupMenu1.add(getJMenuItem1());
			ivjJPopupMenu1.add(getJSeparator1());
			ivjJPopupMenu1.add(getJMenuItem2());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPopupMenu1;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPane1.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPane1.setMaximumSize(new java.awt.Dimension(250, 100));
			ivjJScrollPane1.setPreferredSize(new java.awt.Dimension(250, 100));
			ivjJScrollPane1.setMinimumSize(new java.awt.Dimension(250, 100));
			getJScrollPane1().setViewportView(getScrollPaneTable());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JSeparator1 property value.
 * @return javax.swing.JSeparator
 */
private javax.swing.JSeparator getJSeparator1() {
	if (ivjJSeparator1 == null) {
		try {
			ivjJSeparator1 = new javax.swing.JSeparator();
			ivjJSeparator1.setName("JSeparator1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJSeparator1;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setText("100000");
			ivjJTextField1.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Return the JTextField2 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField2() {
	if (ivjJTextField2 == null) {
		try {
			ivjJTextField2 = new javax.swing.JTextField();
			ivjJTextField2.setName("JTextField2");
			ivjJTextField2.setText("30");
			ivjJTextField2.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField2;
}
/**
 * Return the JTextField3 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField3() {
	if (ivjJTextField3 == null) {
		try {
			ivjJTextField3 = new javax.swing.JTextField();
			ivjJTextField3.setName("JTextField3");
			ivjJTextField3.setText("10.00");
			ivjJTextField3.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField3;
}
/**
 * Return the JTextField4 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField4() {
	if (ivjJTextField4 == null) {
		try {
			ivjJTextField4 = new javax.swing.JTextField();
			ivjJTextField4.setName("JTextField4");
			ivjJTextField4.setText("12");
			ivjJTextField4.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField4;
}
/**
 * Return the JTextField5 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField5() {
	if (ivjJTextField5 == null) {
		try {
			ivjJTextField5 = new javax.swing.JTextField();
			ivjJTextField5.setName("JTextField5");
			ivjJTextField5.setText("12");
			ivjJTextField5.setColumns(9);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField5;
}
/**
 * Return the PercentFormatter property value.
 * @return java.text.NumberFormat
 */
private java.text.NumberFormat getPercentFormatter() {
	return ivjPercentFormatter;
}
/**
 * Return the ScrollPaneTable property value.
 * @return javax.swing.JTable
 */
private javax.swing.JTable getScrollPaneTable() {
	if (ivjScrollPaneTable == null) {
		try {
			ivjScrollPaneTable = new javax.swing.JTable();
			ivjScrollPaneTable.setName("ScrollPaneTable");
			getJScrollPane1().setColumnHeaderView(ivjScrollPaneTable.getTableHeader());
			getJScrollPane1().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTable.setPreferredSize(new java.awt.Dimension(613, 100));
			ivjScrollPaneTable.setBounds(0, 0, 200, 200);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjScrollPaneTable;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		setName("Amortization");
		setSize(660, 350);
		setContentPane(getJAppletContentPane());
		initConnections();
		connEtoM4();
		connEtoM6();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getJButton1().addActionListener(this);
	getScrollPaneTable().addMouseListener(this);
	getJTextField1().addKeyListener(this);
	getCompoundInterest1().addPropertyChangeListener(this);
	getJTextField2().addKeyListener(this);
	getJTextField3().addKeyListener(this);
	getJTextField4().addKeyListener(this);
	getJTextField5().addKeyListener(this);
	getJMenuItem1().addActionListener(this);
	getJMenuItem2().addActionListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP6SetTarget();
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
public void keyPressed(java.awt.event.KeyEvent e) {
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
public void keyReleased(java.awt.event.KeyEvent e) {
	if (e.getSource() == getJTextField1()) 
		connPtoP2SetTarget();
	if (e.getSource() == getJTextField2()) 
		connPtoP3SetTarget();
	if (e.getSource() == getJTextField3()) 
		connPtoP4SetTarget();
	if (e.getSource() == getJTextField4()) 
		connPtoP5SetTarget();
	if (e.getSource() == getJTextField5()) 
		connPtoP6SetTarget();
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
public void keyTyped(java.awt.event.KeyEvent e) {
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.swing.mortgageamortizer.AmortizationS1 aAmortization;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.swing.mortgageamortizer.AmortizationS1");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aAmortization = (com.ibm.ivj.examples.vc.swing.mortgageamortizer.AmortizationS1)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.swing.mortgageamortizer.AmortizationS1");
		frame.add("Center", aAmortization);
		frame.setSize(aAmortization.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JApplet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(java.awt.event.MouseEvent e) {
	if (e.getSource() == getScrollPaneTable()) 
		connEtoC1(e);
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("principalAmount"))) 
		connPtoP2SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("amortizationPeriod"))) 
		connPtoP3SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("interestRate"))) 
		connPtoP4SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("paymentsPerYear"))) 
		connPtoP5SetSource();
	if (evt.getSource() == getCompoundInterest1() && (evt.getPropertyName().equals("timesPerYear"))) 
		connPtoP6SetSource();
}
/**
 * Set the CurrencyFormatter to a new value.
 * @param newValue java.text.NumberFormat
 */
private void setCurrencyFormatter(java.text.NumberFormat newValue) {
	if (ivjCurrencyFormatter != newValue) {
		try {
			ivjCurrencyFormatter = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the PercentFormatter to a new value.
 * @param newValue java.text.NumberFormat
 */
private void setPercentFormatter(java.text.NumberFormat newValue) {
	if (ivjPercentFormatter != newValue) {
		try {
			ivjPercentFormatter = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
