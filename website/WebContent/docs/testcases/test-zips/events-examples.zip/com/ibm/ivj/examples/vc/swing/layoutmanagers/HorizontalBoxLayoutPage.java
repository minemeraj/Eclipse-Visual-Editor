package com.ibm.ivj.examples.vc.swing.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class HorizontalBoxLayoutPage extends javax.swing.JPanel {
	private javax.swing.JButton ivjJButton1 = null;
	private javax.swing.JButton ivjJButton2 = null;
	private javax.swing.JButton ivjJButton3 = null;
	private javax.swing.JButton ivjJButton4 = null;
	private javax.swing.JButton ivjJButton5 = null;
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
/**
 * Constructor
 */
public HorizontalBoxLayoutPage() {
	super();
	initialize();
}
/**
 * HorizontalBoxLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public HorizontalBoxLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * HorizontalBoxLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public HorizontalBoxLayoutPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * HorizontalBoxLayoutPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public HorizontalBoxLayoutPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new javax.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setText("");
			ivjJButton1.setBackground(java.awt.Color.magenta);
			ivjJButton1.setMaximumSize(new java.awt.Dimension(90, 40));
			ivjJButton1.setMinimumSize(new java.awt.Dimension(45, 40));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton1;
}
/**
 * Return the JButton2 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton2() {
	if (ivjJButton2 == null) {
		try {
			ivjJButton2 = new javax.swing.JButton();
			ivjJButton2.setName("JButton2");
			ivjJButton2.setText("");
			ivjJButton2.setBackground(java.awt.Color.cyan);
			ivjJButton2.setMaximumSize(new java.awt.Dimension(90, 40));
			ivjJButton2.setPreferredSize(new java.awt.Dimension(35, 11));
			ivjJButton2.setMinimumSize(new java.awt.Dimension(45, 40));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton2;
}
/**
 * Return the JButton3 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton3() {
	if (ivjJButton3 == null) {
		try {
			ivjJButton3 = new javax.swing.JButton();
			ivjJButton3.setName("JButton3");
			ivjJButton3.setText("");
			ivjJButton3.setBackground(java.awt.Color.green);
			ivjJButton3.setMaximumSize(new java.awt.Dimension(90, 40));
			ivjJButton3.setPreferredSize(new java.awt.Dimension(35, 11));
			ivjJButton3.setMinimumSize(new java.awt.Dimension(45, 40));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton3;
}
/**
 * Return the JButton4 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton4() {
	if (ivjJButton4 == null) {
		try {
			ivjJButton4 = new javax.swing.JButton();
			ivjJButton4.setName("JButton4");
			ivjJButton4.setText("");
			ivjJButton4.setBackground(java.awt.Color.orange);
			ivjJButton4.setMaximumSize(new java.awt.Dimension(90, 40));
			ivjJButton4.setPreferredSize(new java.awt.Dimension(35, 11));
			ivjJButton4.setMinimumSize(new java.awt.Dimension(45, 40));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton4;
}
/**
 * Return the JButton5 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getJButton5() {
	if (ivjJButton5 == null) {
		try {
			ivjJButton5 = new javax.swing.JButton();
			ivjJButton5.setName("JButton5");
			ivjJButton5.setText("");
			ivjJButton5.setBackground(java.awt.Color.pink);
			ivjJButton5.setMaximumSize(new java.awt.Dimension(90, 40));
			ivjJButton5.setPreferredSize(new java.awt.Dimension(35, 11));
			ivjJButton5.setMinimumSize(new java.awt.Dimension(45, 40));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJButton5;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setPreferredSize(new java.awt.Dimension(423, 124));
			ivjJScrollPane1.setMaximumSize(new java.awt.Dimension(200, 100));
			ivjJScrollPane1.setMinimumSize(new java.awt.Dimension(100, 100));
			getJScrollPane1().setViewportView(getJTextArea1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setPreferredSize(new java.awt.Dimension(420, 140));
			ivjJTextArea1.setText("BoxLayout manager allows multiple components\n to be layed out either vertically\nor horizontally. The components will not wrap\n so, for   example, a horizontal\narrangement of components will stay horizontally \narranged when the frame is resized. \nThis is a BoxLayout with axis property of BoxLayout\n is set to X_AXIS. All components \nare arranged horizontally.");
			ivjJTextArea1.setBounds(0, 0, 12, 17);
			ivjJTextArea1.setMaximumSize(new java.awt.Dimension(200, 100));
			ivjJTextArea1.setMinimumSize(new java.awt.Dimension(100, 100));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("HorizontalBoxLayoutPage");
		setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.X_AXIS));
		setBackground(new java.awt.Color(230,230,230));
		setSize(500, 270);
		add(getJScrollPane1());
		add(getJButton1(), getJButton1().getName());
		add(getJButton2(), getJButton2().getName());
		add(getJButton3(), getJButton3().getName());
		add(getJButton4(), getJButton4().getName());
		add(getJButton5(), getJButton5().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		com.ibm.ivj.examples.vc.swing.layoutmanagers.HorizontalBoxLayoutPage aHorizontalBoxLayoutPage;
		aHorizontalBoxLayoutPage = new com.ibm.ivj.examples.vc.swing.layoutmanagers.HorizontalBoxLayoutPage();
		frame.getContentPane().add("Center", aHorizontalBoxLayoutPage);
		frame.setSize(aHorizontalBoxLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
