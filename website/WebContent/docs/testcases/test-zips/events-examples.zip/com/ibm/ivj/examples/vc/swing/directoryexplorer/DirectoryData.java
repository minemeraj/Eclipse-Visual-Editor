package com.ibm.ivj.examples.vc.swing.directoryexplorer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import java.io.*;
/**
 * This type was created in VisualAge.
 */
public class DirectoryData {
	private String fieldDirectory = new String();
	private File fieldFileObject = new File("");
	private boolean fieldHasChildDirectories = false;
/**
 * DirectoryData constructor comment.
 */
public DirectoryData() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param file java.io.File
 */
public DirectoryData(java.io.File file) {
	super();
	setFileObject(file);	
}
/**
 * This method was created in VisualAge.
 * @param dirName java.lang.String
 */
public DirectoryData(java.lang.String dirName) {
	this(new File(dirName));		
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean calculateHasFileDirectories() {

	File parentFile = getFileObject();
	String [] files = parentFile.list();	
	String parentPath = parentFile.getPath() + File.separator;
	boolean dirFound = false;
	
	for (int i = 0; (i < files.length) && !dirFound; i++)
		if ((new File(parentPath + files[i])).isDirectory())
			dirFound = true;
	return dirFound;
}
/**
 * Gets the directory property (java.lang.String) value.
 * @return The directory property value.
 * @see #setDirectory
 */
public String getDirectory() {
	fieldDirectory = getFileObject().getPath();
	return fieldDirectory;
}
/**
 * Gets the fileObject property (java.io.File) value.
 * @return The fileObject property value.
 * @see #setFileObject
 */
public File getFileObject() {
	return fieldFileObject;
}
/**
 * Gets the hasChildDirectories property (boolean) value.
 * @return The hasChildDirectories property value.
 * @see #setHasChildDirectories
 */
public boolean getHasChildDirectories() {
	fieldHasChildDirectories = calculateHasFileDirectories();	
	return fieldHasChildDirectories;
}
/**
 * Sets the directory property (java.lang.String) value.
 * @param directory The new value for the property.
 * @see #getDirectory
 */
public void setDirectory(String directory) {
	fieldDirectory = directory;	
	setFileObject(new File(directory));
}
/**
 * Sets the fileObject property (java.io.File) value.
 * @param fileObject The new value for the property.
 * @see #getFileObject
 */
public void setFileObject(File fileObject) {
	fieldFileObject = fileObject;
}
/**
 * Sets the hasChildDirectories property (boolean) value.
 * @param hasChildDirectories The new value for the property.
 * @see #getHasChildDirectories
 */
public void setHasChildDirectories(boolean hasChildDirectories) {
	fieldHasChildDirectories = hasChildDirectories;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public java.lang.String toString() {
	return getFileObject().getName();
}
}
