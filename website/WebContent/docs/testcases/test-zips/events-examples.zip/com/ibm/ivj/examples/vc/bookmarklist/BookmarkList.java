package com.ibm.ivj.examples.vc.bookmarklist;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import java.applet.*;
import java.awt.*;
/**
 * This type was created in VisualAge.
 */
public class BookmarkList extends Applet implements java.awt.event.ActionListener, java.awt.event.ItemListener, java.awt.event.TextListener {
	private Button ivjAddButton = null;
	private AppletContext ivjappletContext1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="73,495"
	private BorderLayout ivjBookmarkListBorderLayout = null;
	private Button ivjDeleteButton = null;
	private Label ivjLabel1 = null;
	private Button ivjLinkButton = null;
	private Panel ivjPanel1 = null;
	private GridLayout ivjPanel1GridLayout = null;
	private Panel ivjPanel2 = null;
	private GridLayout ivjPanel2GridLayout = null;
	private TextField ivjURLEntry = null;
	private List ivjURLList = null;
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getAddButton()) 
		connEtoM1(e);
	if (e.getSource() == getDeleteButton()) 
		connEtoM2(e);
	if (e.getSource() == getLinkButton()) 
		connEtoC4(e);
	if (e.getSource() == getLinkButton()) 
		connEtoM3(e);
	if (e.getSource() == getURLEntry()) 
		connEtoM6(e);
	if (e.getSource() == getDeleteButton()) 
		connEtoC5(e);
}
/**
 * connEtoC1:  (URLEntry.text.textValueChanged(java.awt.event.TextEvent) --> BookmarkList.setButtonState()V)
 * @param arg1 java.awt.event.TextEvent
 */
private void connEtoC1(java.awt.event.TextEvent arg1) {
	try {
		this.setButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (URLList.item.itemStateChanged(java.awt.event.ItemEvent) --> BookmarkList.setButtonState()V)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoC2(java.awt.event.ItemEvent arg1) {
	try {
		this.setButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (BookmarkList.init() --> BookmarkList.setButtonState()V)
 */
private void connEtoC3() {
	try {
		this.setButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (LinkButton.action.actionPerformed(java.awt.event.ActionEvent) --> BookmarkList.setButtonState()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		this.setButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> BookmarkList.setButtonState()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		this.setButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (AddButton.action.actionPerformed(java.awt.event.ActionEvent) --> URLList.add(Ljava.lang.String;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		getURLList().add(getURLEntry().getText());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> URLList.remove(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		getURLList().remove(getURLList().getSelectedIndex());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (LinkButton.action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1.showDocument(Ljava.net.URL;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		getappletContext1().showDocument(this.getUrlFromString(getURLList().getSelectedItem()));
	} catch (java.lang.Throwable ivjExc) {
		connEtoM4(ivjExc);
	}
}
/**
 * connEtoM4:  ( (LinkButton,action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1,showDocument(Ljava.net.URL;)V).exceptionOccurred --> appletContext1.showStatus(Ljava.lang.String;)V)
 * @param exception java.lang.Throwable
 */
private void connEtoM4(java.lang.Throwable exception) {
	try {
		getappletContext1().showStatus(String.valueOf(exception));
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (URLList.item.itemStateChanged(java.awt.event.ItemEvent) --> URLEntry.text)
 * @param arg1 java.awt.event.ItemEvent
 */
private void connEtoM5(java.awt.event.ItemEvent arg1) {
	try {
		getURLEntry().setText(getURLList().getSelectedItem());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (URLEntry.action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1.showDocument(Ljava.net.URL;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		getappletContext1().showDocument(this.getUrlFromString(getURLEntry().getText()));
	} catch (java.lang.Throwable ivjExc) {
		connEtoM7(ivjExc);
	}
}
/**
 * connEtoM7:  ( (URLEntry,action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1,showDocument(Ljava.net.URL;)V).exceptionOccurred --> appletContext1.showStatus(Ljava.lang.String;)V)
 * @param exception java.lang.Throwable
 */
private void connEtoM7(java.lang.Throwable exception) {
	try {
		getappletContext1().showStatus(String.valueOf(exception));
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (BookmarkList.appletContext <--> appletContext1.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		setappletContext1(this.getAppletContext());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Return the AddButton property value.
 * @return java.awt.Button
 */
private java.awt.Button getAddButton() {
	if (ivjAddButton == null) {
		try {
			ivjAddButton = new java.awt.Button();
			ivjAddButton.setName("AddButton");
			ivjAddButton.setLabel("Add URL to list");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAddButton;
}
/**
 * Return the appletContext1 property value.
 * @return java.applet.AppletContext
 */
private java.applet.AppletContext getappletContext1() {
	return ivjappletContext1;
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.bookmarklist.BookmarkList created using VisualAge for Java.";
}
/**
 * Return the BookmarkListBorderLayout property value.
 * @return java.awt.BorderLayout
 */
private java.awt.BorderLayout getBookmarkListBorderLayout() {
	java.awt.BorderLayout ivjBookmarkListBorderLayout = null;
	try {
		/* Create part */
		ivjBookmarkListBorderLayout = new java.awt.BorderLayout();
		ivjBookmarkListBorderLayout.setVgap(15);
		ivjBookmarkListBorderLayout.setHgap(15);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjBookmarkListBorderLayout;
}
/**
 * Return the DeleteButton property value.
 * @return java.awt.Button
 */
private java.awt.Button getDeleteButton() {
	if (ivjDeleteButton == null) {
		try {
			ivjDeleteButton = new java.awt.Button();
			ivjDeleteButton.setName("DeleteButton");
			ivjDeleteButton.setLabel("Delete URL");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjDeleteButton;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Enter a URL address:");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the LinkButton property value.
 * @return java.awt.Button
 */
private java.awt.Button getLinkButton() {
	if (ivjLinkButton == null) {
		try {
			ivjLinkButton = new java.awt.Button();
			ivjLinkButton.setName("LinkButton");
			ivjLinkButton.setLabel("Link to URL");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLinkButton;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(getPanel1GridLayout());
			ivjPanel1.add(getLabel1());
			getPanel1().add(getURLEntry(), getURLEntry().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the Panel1GridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getPanel1GridLayout() {
	java.awt.GridLayout ivjPanel1GridLayout = null;
	try {
		/* Create part */
		ivjPanel1GridLayout = new java.awt.GridLayout(2, 1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjPanel1GridLayout;
}
/**
 * Return the Panel2 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel2() {
	if (ivjPanel2 == null) {
		try {
			ivjPanel2 = new java.awt.Panel();
			ivjPanel2.setName("Panel2");
			ivjPanel2.setLayout(getPanel2GridLayout());
			ivjPanel2.add(getAddButton());
			ivjPanel2.add(getDeleteButton());
			getPanel2().add(getLinkButton(), getLinkButton().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel2;
}
/**
 * Return the Panel2GridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getPanel2GridLayout() {
	java.awt.GridLayout ivjPanel2GridLayout = null;
	try {
		/* Create part */
		ivjPanel2GridLayout = new java.awt.GridLayout(3, 1);
		ivjPanel2GridLayout.setVgap(10);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjPanel2GridLayout;
}
/**
 * Return the URLEntry property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getURLEntry() {
	if (ivjURLEntry == null) {
		try {
			ivjURLEntry = new java.awt.TextField();
			ivjURLEntry.setName("URLEntry");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjURLEntry;
}
/**
 * Insert the method's description here.
 * Creation date: (8/18/99 10:07:31 AM)
 * @return java.net.URL
 * @param Str java.lang.String
 */
public java.net.URL getUrlFromString(String Str) {
	java.net.URL url = null;
	try {
		url = new java.net.URL(Str);
	} catch (Throwable e) {
		handleException(e); }
	return url;
}
/**
 * Return the URLList property value.
 * @return java.awt.List
 */
private java.awt.List getURLList() {
	if (ivjURLList == null) {
		try {
			ivjURLList = new java.awt.List();
			ivjURLList.setName("URLList");
			initializeURLList(ivjURLList);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjURLList;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
 System.out.println("--------- UNCAUGHT EXCEPTION ---------");
 exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		super.init();
		setName("BookmarkList");
		setLayout(getBookmarkListBorderLayout());
		setBackground(java.awt.Color.lightGray);
		setSize(400, 400);
		add(getPanel1(), "North");
		add(getPanel2(), "East");
		add(getURLList(), "Center");
		initConnections();
		connEtoC3();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getAddButton().addActionListener(this);
	getDeleteButton().addActionListener(this);
	getLinkButton().addActionListener(this);
	getURLList().addItemListener(this);
	getURLEntry().addActionListener(this);
	getURLEntry().addTextListener(this);
	connPtoP1SetTarget();
}
/**
 * This method was created in VisualAge.
 * @param URLList java.awt.List
 */
protected static void initializeURLList (java.awt.List URLList) {
	URLList.add("http://www.software.ibm.com/ad/vajava");
	URLList.add("http://www.ibm.com");
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	if (e.getSource() == getURLList()) 
		connEtoM5(e);
	if (e.getSource() == getURLList()) 
		connEtoC2(e);
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.bookmarklist.BookmarkList aBookmarkList;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.bookmarklist.BookmarkList");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aBookmarkList = (com.ibm.ivj.examples.vc.bookmarklist.BookmarkList)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.bookmarklist.BookmarkList");
		frame.add("Center", aBookmarkList);
		frame.setSize(aBookmarkList.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Set the appletContext1 to a new value.
 * @param newValue java.applet.AppletContext
 */
private void setappletContext1(java.applet.AppletContext newValue) {
	if (ivjappletContext1 != newValue) {
		try {
			ivjappletContext1 = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the button state (enabled/disabled) based on whether there is
 * text in the URLEntry field and/or an item selected in URLList.
 */
public void setButtonState() {
	String text = getURLEntry().getText();
	int index = getURLList().getSelectedIndex();
	java.awt.Button addButton 		= getAddButton();
	java.awt.Button deleteButton 	= getDeleteButton();
	java.awt.Button linkButton 		= getLinkButton();
	
	if (text.equals(""))
		addButton.setEnabled(false);
	else
		addButton.setEnabled(true);
	
	if (index < 0)
	{
		deleteButton.setEnabled(false);
		linkButton.setEnabled(false);
	}
	else
	{
		deleteButton.setEnabled(true);
		linkButton.setEnabled(true);
	}
	getAppletContext().showStatus("");
}
/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
public void textValueChanged(java.awt.event.TextEvent e) {
	if (e.getSource() == getURLEntry()) 
		connEtoC1(e);
}
}  // @jve:visual-info  decl-index=0 visual-constraint="55,56"
