package com.ibm.ivj.examples.vc.todolist;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import java.applet.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
/**
 * This type was created in VisualAge.
 */
public class ToDoList extends JApplet {
	private DefaultListModel ivjDefaultListModel1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="216,369"
	private JPanel ivjJAppletContentPane = null;
	private JLabel ivjJLabel1 = null;
	private JLabel ivjJLabel11 = null;
	private JList ivjJList1 = null;
	private JScrollPane ivjJScrollPane1 = null;
	private JTextField ivjJTextField1 = null;
	private JButton ivjAddButton = null;
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private JButton ivjReadButton = null;
	private JButton ivjRemoveButton = null;
	private JButton ivjSaveButton = null;
	static String FILE_NAME = "todo.lst";

class IvjEventHandler implements java.awt.event.ActionListener, javax.swing.event.ListSelectionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == ToDoList.this.getAddButton()) 
				connEtoM1(e);
			if (e.getSource() == ToDoList.this.getRemoveButton()) 
				connEtoC1(e);
			if (e.getSource() == ToDoList.this.getReadButton()) 
				connEtoC3(e);
			if (e.getSource() == ToDoList.this.getSaveButton()) 
				connEtoC4(e);
		};
		public void valueChanged(javax.swing.event.ListSelectionEvent e) {
			if (e.getSource() == ToDoList.this.getJList1()) 
				connEtoC2();
		};
	};
/**
 * This method was created in VisualAge.
 */
public ToDoList() {
	super();	
	}
/**
 * connEtoC1:  (RemoveButton.action.actionPerformed(java.awt.event.ActionEvent) --> ToDoList.removeButton_ActionPerformed(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		this.removeButton_ActionPerformed(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JList1.listSelection. --> ToDoList.jList1_ListSelectionEvents()V)
 */
private void connEtoC2() {
	try {
		this.jList1_ListSelectionEvents();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (ReadButton.action.actionPerformed(java.awt.event.ActionEvent) --> ToDoList.readToDoFile()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		this.readToDoFile();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (SaveButton.action.actionPerformed(java.awt.event.ActionEvent) --> ToDoList.writeToDoFile()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		this.writeToDoFile();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (AddButton.action.actionPerformed(java.awt.event.ActionEvent) --> DefaultListModel1.addElement(Ljava.lang.Object;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		getDefaultListModel1().addElement(getJTextField1().getText());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (DefaultListModel1.this <--> JList1.model)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getJList1().setModel(getDefaultListModel1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Return the JButton1 property value.
 * @return com.sun.java.swing.JButton
 */
private javax.swing.JButton getAddButton() {
	if (ivjAddButton == null) {
		try {
			ivjAddButton = new javax.swing.JButton();
			ivjAddButton.setName("AddButton");
			ivjAddButton.setLocation(new java.awt.Point(256, 28));
			ivjAddButton.setText("Add");
			ivjAddButton.setMaximumSize(new java.awt.Dimension(57, 25));
			ivjAddButton.setActionCommand("Add");
			ivjAddButton.setPreferredSize(new java.awt.Dimension(57, 25));
			ivjAddButton.setBounds(new java.awt.Rectangle(256, 28, 131, 25));
			ivjAddButton.setBounds(198, 54, 131, 25);
			ivjAddButton.setMinimumSize(new java.awt.Dimension(57, 25));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAddButton;
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.todolist.ToDoList created using VisualAge for Java.";
}
/**
 * Return the DefaultListModel1 property value.
 * @return com.sun.java.swing.DefaultListModel
 */
private javax.swing.DefaultListModel getDefaultListModel1() {
	if (ivjDefaultListModel1 == null) {
		try {
			ivjDefaultListModel1 = new javax.swing.DefaultListModel();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjDefaultListModel1;
}
/**
 * Return the JAppletContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
private javax.swing.JPanel getJAppletContentPane() {
	if (ivjJAppletContentPane == null) {
		try {
			ivjJAppletContentPane = new javax.swing.JPanel();
			ivjJAppletContentPane.setName("JAppletContentPane");
			ivjJAppletContentPane.setPreferredSize(new java.awt.Dimension(0, 0));
			ivjJAppletContentPane.setLayout(null);
			ivjJAppletContentPane.setBounds(0, 0, 0, 0);
			ivjJAppletContentPane.setMinimumSize(new java.awt.Dimension(0, 0));
			getJAppletContentPane().add(getJTextField1(), getJTextField1().getName());
			getJAppletContentPane().add(getJLabel1(), getJLabel1().getName());
			getJAppletContentPane().add(getJScrollPane1(), getJScrollPane1().getName());
			getJAppletContentPane().add(getJLabel11(), getJLabel11().getName());
			getJAppletContentPane().add(getAddButton(), getAddButton().getName());
			getJAppletContentPane().add(getRemoveButton(), getRemoveButton().getName());
			getJAppletContentPane().add(getReadButton(), getReadButton().getName());
			getJAppletContentPane().add(getSaveButton(), getSaveButton().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJAppletContentPane;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setLocation(new java.awt.Point(32, 21));
			ivjJLabel1.setText("To-Do Item");
			ivjJLabel1.setSize(new java.awt.Dimension(98, 15));
			ivjJLabel1.setMaximumSize(new java.awt.Dimension(61, 15));
			ivjJLabel1.setPreferredSize(new java.awt.Dimension(61, 15));
			ivjJLabel1.setBounds(new java.awt.Rectangle(32, 21, 98, 15));
			ivjJLabel1.setBounds(32, 33, 98, 15);
			ivjJLabel1.setMinimumSize(new java.awt.Dimension(61, 15));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JLabel11 property value.
 * @return com.sun.java.swing.JLabel
 */
private javax.swing.JLabel getJLabel11() {
	if (ivjJLabel11 == null) {
		try {
			ivjJLabel11 = new javax.swing.JLabel();
			ivjJLabel11.setName("JLabel11");
			ivjJLabel11.setLocation(new java.awt.Point(32, 97));
			ivjJLabel11.setText("To-Do List");
			ivjJLabel11.setSize(new java.awt.Dimension(98, 15));
			ivjJLabel11.setMaximumSize(new java.awt.Dimension(57, 15));
			ivjJLabel11.setPreferredSize(new java.awt.Dimension(57, 15));
			ivjJLabel11.setBounds(new java.awt.Rectangle(32, 97, 98, 15));
			ivjJLabel11.setBounds(32, 104, 98, 15);
			ivjJLabel11.setMinimumSize(new java.awt.Dimension(57, 15));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel11;
}
/**
 * Return the JList1 property value.
 * @return com.sun.java.swing.JList
 */
private javax.swing.JList getJList1() {
	if (ivjJList1 == null) {
		try {
			ivjJList1 = new javax.swing.JList();
			ivjJList1.setName("JList1");
			ivjJList1.setBounds(new java.awt.Rectangle(0, 0, 160, 120));
			ivjJList1.setSize(new java.awt.Dimension(160, 120));
			ivjJList1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJList1;
}
/**
 * Return the JScrollPane1 property value.
 * @return com.sun.java.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setOpaque(true);
			ivjJScrollPane1.setLocation(new java.awt.Point(32, 133));
			ivjJScrollPane1.setSize(new java.awt.Dimension(140, 86));
			ivjJScrollPane1.setPreferredSize(new java.awt.Dimension(259, 131));
			ivjJScrollPane1.setBounds(new java.awt.Rectangle(32, 133, 140, 86));
			ivjJScrollPane1.setBounds(32, 133, 140, 143);
			ivjJScrollPane1.setMinimumSize(new java.awt.Dimension(259, 131));
			getJScrollPane1().setViewportView(getJList1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setLocation(new java.awt.Point(32, 57));
			ivjJTextField1.setBounds(new java.awt.Rectangle(32, 57, 140, 19));
			ivjJTextField1.setSize(new java.awt.Dimension(140, 19));
			ivjJTextField1.setBounds(32, 57, 140, 19);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Return the JButton3 property value.
 * @return com.sun.java.swing.JButton
 */
private javax.swing.JButton getReadButton() {
	if (ivjReadButton == null) {
		try {
			ivjReadButton = new javax.swing.JButton();
			ivjReadButton.setName("ReadButton");
			ivjReadButton.setLocation(new java.awt.Point(256, 134));
			ivjReadButton.setText("Open To-Do File");
			ivjReadButton.setSize(new java.awt.Dimension(131, 25));
			ivjReadButton.setMaximumSize(new java.awt.Dimension(131, 25));
			ivjReadButton.setActionCommand("Open To-Do File");
			ivjReadButton.setPreferredSize(new java.awt.Dimension(131, 25));
			ivjReadButton.setBounds(new java.awt.Rectangle(256, 134, 131, 25));
			ivjReadButton.setBounds(198, 215, 131, 25);
			ivjReadButton.setMinimumSize(new java.awt.Dimension(131, 25));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjReadButton;
}
/**
 * Return the JButton2 property value.
 * @return com.sun.java.swing.JButton
 */
private javax.swing.JButton getRemoveButton() {
	if (ivjRemoveButton == null) {
		try {
			ivjRemoveButton = new javax.swing.JButton();
			ivjRemoveButton.setName("RemoveButton");
			ivjRemoveButton.setLocation(new java.awt.Point(256, 81));
			ivjRemoveButton.setText("Remove");
			ivjRemoveButton.setSize(new java.awt.Dimension(131, 25));
			ivjRemoveButton.setMaximumSize(new java.awt.Dimension(81, 25));
			ivjRemoveButton.setActionCommand("Remove");
			ivjRemoveButton.setPreferredSize(new java.awt.Dimension(81, 25));
			ivjRemoveButton.setBounds(new java.awt.Rectangle(256, 81, 131, 25));
			ivjRemoveButton.setEnabled(false);
			ivjRemoveButton.setMinimumSize(new java.awt.Dimension(81, 25));
			ivjRemoveButton.setBounds(198, 134, 131, 25);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjRemoveButton;
}
/**
 * Return the JButton31 property value.
 * @return com.sun.java.swing.JButton
 */
private javax.swing.JButton getSaveButton() {
	if (ivjSaveButton == null) {
		try {
			ivjSaveButton = new javax.swing.JButton();
			ivjSaveButton.setName("SaveButton");
			ivjSaveButton.setLocation(new java.awt.Point(256, 187));
			ivjSaveButton.setText("Save To-Do File");
			ivjSaveButton.setSize(new java.awt.Dimension(131, 25));
			ivjSaveButton.setMaximumSize(new java.awt.Dimension(129, 25));
			ivjSaveButton.setActionCommand("Save To-Do File");
			ivjSaveButton.setPreferredSize(new java.awt.Dimension(129, 25));
			ivjSaveButton.setBounds(new java.awt.Rectangle(256, 187, 131, 25));
			ivjSaveButton.setBounds(198, 251, 131, 25);
			ivjSaveButton.setMinimumSize(new java.awt.Dimension(129, 25));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjSaveButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		setName("ToDoList");
		setBounds(new java.awt.Rectangle(0, 0, 426, 240));
		setSize(new java.awt.Dimension(426, 240));
		setSize(359, 306);
		setContentPane(getJAppletContentPane());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getAddButton().addActionListener(ivjEventHandler);
	getRemoveButton().addActionListener(ivjEventHandler);
	getJList1().addListSelectionListener(ivjEventHandler);
	getReadButton().addActionListener(ivjEventHandler);
	getSaveButton().addActionListener(ivjEventHandler);
	connPtoP1SetTarget();
}
/**
 * Comment
 */
public void jButton1_ActionPerformed(java.awt.event.ActionEvent actionEvent) {
	// testing event-to-code programming
	return;
}
/**
 * Comment
 */
public void jList1_ListSelectionEvents() {
	if (getJList1().getSelectedIndex() < 0)
		getRemoveButton().setEnabled(false);
	else
		getRemoveButton().setEnabled(true);	
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Frame frame = new java.awt.Frame();
		ToDoList aToDoList;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.todolist.ToDoList");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aToDoList = (ToDoList)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.todolist.ToDoList");
		frame.add("Center", aToDoList);
		frame.setSize(aToDoList.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JApplet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Reads ToDoList contents from a file specified by FILE_NAME
 */
public void readToDoFile() {
	FileReader fileInStream;
	BufferedReader dataInStream;
	String result;
	try {
		// read the file and fill the list
		fileInStream = new FileReader(FILE_NAME);
		dataInStream = new BufferedReader(fileInStream);
		// clear the existing entries from the list
		getDefaultListModel1().removeAllElements();
		// for each line in the file create an item in the list
		while ((result = dataInStream.readLine()) != null) {
			if (result.length() != 0)
				getDefaultListModel1().addElement(result);
		}
		fileInStream.close();
		dataInStream.close();
	} catch (Throwable exc) {
		handleException(exc);
	}
	return;
}
/**
 * Comment
 */
public void removeButton_ActionPerformed(java.awt.event.ActionEvent actionEvent) {
		// Grab selected item
	Object itemToBeRemoved = getJList1().getSelectedValue();

	// Remove item from model
	getDefaultListModel1().removeElement(itemToBeRemoved);

	// Echo item to text field
	getJTextField1().setText(itemToBeRemoved.toString());

	// Refresh list from model
	getJList1().setModel(getDefaultListModel1());
	return;
}
/**
 * Writes ToDoList contents to a file specified by FILE_NAME
 */
public void writeToDoFile() {
	FileWriter fileOutStream;
	PrintWriter dataOutStream;
	// carriage return and line feed constant
	String crlf = System.getProperties().getProperty("line.separator");

	// write the file from the list
	try {
		fileOutStream = new FileWriter(FILE_NAME);
		dataOutStream = new PrintWriter(fileOutStream);
		// for every item in the list, write a line to the output file
		for (int i = 0; i < getDefaultListModel1().size(); i++)
			dataOutStream.write(getDefaultListModel1().getElementAt(i) + crlf);
		fileOutStream.close();
		dataOutStream.close();
	} catch (Throwable exc) {
		handleException(exc);
	}
	return;
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
