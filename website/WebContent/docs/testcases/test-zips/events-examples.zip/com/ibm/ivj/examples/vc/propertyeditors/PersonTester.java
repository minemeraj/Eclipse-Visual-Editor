package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class PersonTester extends javax.swing.JApplet implements java.beans.PropertyChangeListener {
	private Name ivjAName = null;  // @jve:visual-info  decl-index=0 visual-constraint="429,130"
	private Person ivjAPerson = null;  // @jve:visual-info  decl-index=0 visual-constraint="433,36"
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JLabel ivjJLabel2 = null;
	private javax.swing.JLabel ivjJLabel3 = null;
	private javax.swing.JPanel ivjJPanel1 = null;
	private javax.swing.JLabel ivjIncomeLabel = null;
	private javax.swing.JLabel ivjJLabel7 = null;
	private javax.swing.JLabel ivjNameLabel = null;
	private javax.swing.JLabel ivjPhoneLabel = null;
	private javax.swing.JLabel ivjSexLabel = null;
/**
 * PersonTester constructor comment.
 */
public PersonTester() {
	super();
}
/**
 * connEtoM1:  (PersonTester.init() --> IncomeLabel.setText(Ljava.lang.String;)V)
 */
private void connEtoM1() {
	try {
		getIncomeLabel().setText(this.connEtoM1_Value());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Comment
 */
public java.lang.String connEtoM1_Value() {
	return getAPerson().getIncomeAsString();
}
/**
 * connPtoP1SetSource:  (APerson.name <--> name1.this)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getAName() != null)) {
				getAPerson().setName(getAName());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (APerson.name <--> name1.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			setAName(getAPerson().getName());
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (APerson.phoneNumber <--> JLabel5.text)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getAPerson().setPhoneNumber(getPhoneLabel().getText());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (APerson.phoneNumber <--> JLabel5.text)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			getPhoneLabel().setText(getAPerson().getPhoneNumber());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (APerson.sex <--> JLabel6.text)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getAPerson().setSex(getSexLabel().getText());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (APerson.sex <--> JLabel6.text)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			getSexLabel().setText(getAPerson().getSex());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (AName.valueAsString <--> JLabel4.text)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			if ((getAName() != null)) {
				getNameLabel().setText(getAName().getValueAsString());
			}
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * Return the name1 property value.
 * @return com.ibm.ivj.examples.vc.propertyeditors.Name
 */
private Name getAName() {
	return ivjAName;
}
/**
 * Return the APerson property value.
 * @return com.ibm.ivj.examples.vc.propertyeditors.Person
 */
private Person getAPerson() {
	if (ivjAPerson == null) {
		try {
			ivjAPerson = new com.ibm.ivj.examples.vc.propertyeditors.Person();
			ivjAPerson.setSex("female");
			ivjAPerson.setName(new com.ibm.ivj.examples.vc.propertyeditors.Name("Mrs.", "Susan", "Gail", "Carpenter"));
			ivjAPerson.setPhoneNumber("555-1212");
			ivjAPerson.setIncomeRange(com.ibm.ivj.examples.vc.propertyeditors.Person.belowTwenty);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAPerson;
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.propertyeditors.PersonTester created using VisualAge for Java.";
}
/**
 * Return the IncomeLabel property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getIncomeLabel() {
	if (ivjIncomeLabel == null) {
		try {
			ivjIncomeLabel = new javax.swing.JLabel();
			ivjIncomeLabel.setName("IncomeLabel");
			ivjIncomeLabel.setText("[Name]");
			ivjIncomeLabel.setBounds(177, 164, 177, 15);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjIncomeLabel;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("[Phone Number]");
			ivjJLabel1.setBounds(25, 27, 52, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JLabel2 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel2() {
	if (ivjJLabel2 == null) {
		try {
			ivjJLabel2 = new javax.swing.JLabel();
			ivjJLabel2.setName("JLabel2");
			ivjJLabel2.setText("[Male or Female]");
			ivjJLabel2.setBounds(24, 72, 116, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel2;
}
/**
 * Return the JLabel3 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel3() {
	if (ivjJLabel3 == null) {
		try {
			ivjJLabel3 = new javax.swing.JLabel();
			ivjJLabel3.setName("JLabel3");
			ivjJLabel3.setText("[Annual Income]");
			ivjJLabel3.setBounds(26, 117, 38, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel3;
}
/**
 * Return the JLabel7 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel7() {
	if (ivjJLabel7 == null) {
		try {
			ivjJLabel7 = new javax.swing.JLabel();
			ivjJLabel7.setName("JLabel7");
			ivjJLabel7.setText("Name:");
			ivjJLabel7.setBounds(26, 164, 90, 15);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel7;
}
/**
 * Return the JPanel1 property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJPanel1() {
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new javax.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(null);
			getJPanel1().add(getJLabel1(), getJLabel1().getName());
			getJPanel1().add(getJLabel2(), getJLabel2().getName());
			getJPanel1().add(getJLabel3(), getJLabel3().getName());
			getJPanel1().add(getNameLabel(), getNameLabel().getName());
			getJPanel1().add(getPhoneLabel(), getPhoneLabel().getName());
			getJPanel1().add(getSexLabel(), getSexLabel().getName());
			getJPanel1().add(getJLabel7(), getJLabel7().getName());
			getJPanel1().add(getIncomeLabel(), getIncomeLabel().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPanel1;
}
/**
 * Return the NameLabel property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new javax.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Carpenter");
			ivjNameLabel.setBounds(177, 27, 170, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjNameLabel;
}
/**
 * Return the PhoneLabel property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getPhoneLabel() {
	if (ivjPhoneLabel == null) {
		try {
			ivjPhoneLabel = new javax.swing.JLabel();
			ivjPhoneLabel.setName("PhoneLabel");
			ivjPhoneLabel.setText("Gail");
			ivjPhoneLabel.setBounds(177, 72, 96, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPhoneLabel;
}
/**
 * Return the SexLabel property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getSexLabel() {
	if (ivjSexLabel == null) {
		try {
			ivjSexLabel = new javax.swing.JLabel();
			ivjSexLabel.setName("SexLabel");
			ivjSexLabel.setText("Mrs.");
			ivjSexLabel.setBounds(177, 117, 100, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjSexLabel;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		setName("PersonTester");
		setSize(383, 221);
		setContentPane(getJPanel1());
		initConnections();
		connEtoM1();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getAPerson().addPropertyChangeListener(this);
	getPhoneLabel().addPropertyChangeListener(this);
	getSexLabel().addPropertyChangeListener(this);
	connPtoP1SetTarget();
	connPtoP4SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.propertyeditors.PersonTester aPersonTester;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.propertyeditors.PersonTester");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aPersonTester = (com.ibm.ivj.examples.vc.propertyeditors.PersonTester)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.propertyeditors.PersonTester");
		frame.add("Center", aPersonTester);
		frame.setSize(aPersonTester.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getAPerson() && (evt.getPropertyName().equals("name"))) 
		connPtoP1SetTarget();
	if (evt.getSource() == getAName() && (evt.getPropertyName().equals("valueAsString"))) 
		connPtoP4SetTarget();
	if (evt.getSource() == getAPerson() && (evt.getPropertyName().equals("phoneNumber"))) 
		connPtoP2SetTarget();
	if (evt.getSource() == getPhoneLabel() && (evt.getPropertyName().equals("text"))) 
		connPtoP2SetSource();
	if (evt.getSource() == getAPerson() && (evt.getPropertyName().equals("sex"))) 
		connPtoP3SetTarget();
	if (evt.getSource() == getSexLabel() && (evt.getPropertyName().equals("text"))) 
		connPtoP3SetSource();
}
/**
 * Set the AName to a new value.
 * @param newValue com.ibm.ivj.examples.vc.propertyeditors.Name
 */
private void setAName(Name newValue) {
	if (ivjAName != newValue) {
		try {
			/* Stop listening for events from the current object */
			if (ivjAName != null) {
				ivjAName.removePropertyChangeListener(this);
			}
			ivjAName = newValue;

			/* Listen for events from the new object */
			if (ivjAName != null) {
				ivjAName.addPropertyChangeListener(this);
			}
			connPtoP1SetSource();
			connPtoP4SetTarget();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
}  // @jve:visual-info  decl-index=0 visual-constraint="24,24"
