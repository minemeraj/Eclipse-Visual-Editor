package com.ibm.ivj.examples.vc.customerinfo;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class CustomerView extends java.awt.Panel implements java.awt.event.TextListener, java.beans.PropertyChangeListener {
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private AddressView ivjAddressView1 = null;
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private Customer ivjCustomer1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="604,129"
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
/**
 * Constructor
 */
public CustomerView() {
	super();
	initialize();
}
/**
 * CustomerView constructor comment.
 * @param layout java.awt.LayoutManager
 */
public CustomerView(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * connPtoP1SetSource:  (Customer1.address <--> AddressView1.address1This)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getCustomer1() != null)) {
				getCustomer1().setAddress(getAddressView1().getAddress1This());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (Customer1.address <--> AddressView1.address1This)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getCustomer1() != null)) {
				getAddressView1().setAddress1This(getCustomer1().getAddress());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (Customer1.name <--> TextField1.text)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			if ((getCustomer1() != null)) {
				getCustomer1().setName(getTextField1().getText());
			}
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (Customer1.name <--> TextField1.text)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			if ((getCustomer1() != null)) {
				getTextField1().setText(getCustomer1().getName());
			}
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (Customer1.phone <--> TextField2.text)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getCustomer1() != null)) {
				getCustomer1().setPhone(getTextField2().getText());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (Customer1.phone <--> TextField2.text)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getCustomer1() != null)) {
				getTextField2().setText(getCustomer1().getPhone());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 * @param propertyName java.lang.String
 * @param oldValue java.lang.Object
 * @param newValue java.lang.Object
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Return the AddressView1 property value.
 * @return com.ibm.ivj.examples.vc.customerinfo.AddressView
 */
private AddressView getAddressView1() {
	if (ivjAddressView1 == null) {
		try {
			ivjAddressView1 = new com.ibm.ivj.examples.vc.customerinfo.AddressView();
			ivjAddressView1.setName("AddressView1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAddressView1;
}
/**
 * Return the Customer1 property value.
 * @return com.ibm.ivj.examples.vc.customerinfo.Customer
 */
private Customer getCustomer1() {
	return ivjCustomer1;
}
/**
 * Method generated to support the promotion of the customer1This attribute.
 * @return com.ibm.ivj.examples.vc.customerinfo.Customer
 */
public Customer getCustomer1This() {
		return getCustomer1();
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Name");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("Address");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("Phone");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Accessor for the propertyChange field.
 * @return java.beans.PropertyChangeSupport
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getAddressView1().addPropertyChangeListener(this);
	getTextField1().addTextListener(this);
	getTextField2().addTextListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("CustomerView");
		setLayout(new java.awt.GridBagLayout());
		setSize(450, 200);

		java.awt.GridBagConstraints constraintsTextField1 = new java.awt.GridBagConstraints();
		constraintsTextField1.gridx = 1; constraintsTextField1.gridy = 0;
		constraintsTextField1.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsTextField1.weightx = 1.0;
		add(getTextField1(), constraintsTextField1);

		java.awt.GridBagConstraints constraintsLabel1 = new java.awt.GridBagConstraints();
		constraintsLabel1.gridx = 0; constraintsLabel1.gridy = 0;
		constraintsLabel1.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel1.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel1(), constraintsLabel1);

		java.awt.GridBagConstraints constraintsAddressView1 = new java.awt.GridBagConstraints();
		constraintsAddressView1.gridx = 1; constraintsAddressView1.gridy = 1;
		constraintsAddressView1.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsAddressView1.weightx = 1.0;
		constraintsAddressView1.insets = new java.awt.Insets(4, 0, 4, 0);
		add(getAddressView1(), constraintsAddressView1);

		java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
		constraintsLabel2.gridx = 0; constraintsLabel2.gridy = 1;
		constraintsLabel2.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel2.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel2(), constraintsLabel2);

		java.awt.GridBagConstraints constraintsTextField2 = new java.awt.GridBagConstraints();
		constraintsTextField2.gridx = 1; constraintsTextField2.gridy = 2;
		constraintsTextField2.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsTextField2.weightx = 1.0;
		add(getTextField2(), constraintsTextField2);

		java.awt.GridBagConstraints constraintsLabel3 = new java.awt.GridBagConstraints();
		constraintsLabel3.gridx = 0; constraintsLabel3.gridy = 2;
		constraintsLabel3.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel3.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel3(), constraintsLabel3);
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.customerinfo.CustomerView aCustomerView;
		aCustomerView = new com.ibm.ivj.examples.vc.customerinfo.CustomerView();
		frame.add("Center", aCustomerView);
		frame.setSize(aCustomerView.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getCustomer1() && (evt.getPropertyName().equals("address"))) 
		connPtoP1SetTarget();
	if (evt.getSource() == getAddressView1() && (evt.getPropertyName().equals("address1This"))) 
		connPtoP1SetSource();
	if (evt.getSource() == getCustomer1() && (evt.getPropertyName().equals("name"))) 
		connPtoP2SetTarget();
	if (evt.getSource() == getCustomer1() && (evt.getPropertyName().equals("phone"))) 
		connPtoP3SetTarget();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Set the Customer1 to a new value.
 * @param newValue com.ibm.ivj.examples.vc.customerinfo.Customer
 */
private void setCustomer1(Customer newValue) {
	if (ivjCustomer1 != newValue) {
		try {
			com.ibm.ivj.examples.vc.customerinfo.Customer oldValue = getCustomer1();
			/* Stop listening for events from the current object */
			if (ivjCustomer1 != null) {
				ivjCustomer1.removePropertyChangeListener(this);
			}
			ivjCustomer1 = newValue;

			/* Listen for events from the new object */
			if (ivjCustomer1 != null) {
				ivjCustomer1.addPropertyChangeListener(this);
			}
			connPtoP1SetTarget();
			connPtoP2SetTarget();
			connPtoP3SetTarget();
			firePropertyChange("customer1This", oldValue, newValue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method generated to support the promotion of the customer1This attribute.
 * @param arg1 com.ibm.ivj.examples.vc.customerinfo.Customer
 */
public void setCustomer1This(Customer arg1) {
		setCustomer1(arg1);
}
/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
public void textValueChanged(java.awt.event.TextEvent e) {
	if (e.getSource() == getTextField1()) 
		connPtoP2SetSource();
	if (e.getSource() == getTextField2()) 
		connPtoP3SetSource();
}
}  // @jve:visual-info  decl-index=0 visual-constraint="38,43"
