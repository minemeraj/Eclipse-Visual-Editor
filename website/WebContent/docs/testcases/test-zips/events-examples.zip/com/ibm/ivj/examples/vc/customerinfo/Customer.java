package com.ibm.ivj.examples.vc.customerinfo;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class Customer implements java.lang.Cloneable {
	private String fieldName = new String();
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private Address fieldAddress = new Address();
	private String fieldPhone = new String();
/**
 * Customer constructor comment.
 */
public Customer() {
	super();
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @exception java.lang.CloneNotSupportedException The exception description.
 */
public java.lang.Object clone() throws CloneNotSupportedException {
	/* Perform the clone method. */
	Customer customerObj = new Customer();
	customerObj.setName(this.getName());
	customerObj.setAddress((Address)this.getAddress().clone());
	customerObj.setPhone(this.getPhone());
	return customerObj;
}
/**
 * This method was created in VisualAge.
 * @param source com.ibm.ivj.examples.vc.customerinfo.Customer
 */
public void copyFrom (Customer source) {
	/* Perform the cloneInto method. */
	this.setName(source.getName());
	this.getAddress().copyFrom(source.getAddress());
	this.setPhone(source.getPhone());
}
/**
 * Compares two objects for equality. Returns a boolean that indicates
 * whether this object is equivalent to the specified object. This method
 * is used when an object is stored in a hashtable.
 * @param obj the Object to compare with
 * @return true if these Objects are equal; false otherwise.
 * @see java.util.Hashtable
 */
public boolean equals(Object obj) {
	if (this == obj)
		 return true;

	if (obj == null)
		return false;

	// If this class does not directly inherit from  Object  ,
	// if (!super.equals(obj)) return false;

	if (this.getClass() != obj.getClass()) 
		return false;

	Customer customerObj = (Customer)obj;

	if (this.getName() == null  &&  customerObj.getName() != null) 
			return false;
	else if (this.getName() != null  &&  !this.getName().equals(customerObj.getName()))
		return false;

	if (this.getPhone() == null  &&  customerObj.getPhone() != null) 
			return false;
	else if (this.getPhone() != null  &&  !this.getPhone().equals(customerObj.getPhone()))
		return false;

	if (this.getAddress() == null  &&  customerObj.getAddress() != null) 
			return false;
	else if (this.getAddress() != null  &&  !this.getAddress().equals(customerObj.getAddress()))
		return false;

	// passed all tests,
	return true;
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the address property (com.ibm.ivj.examples.vc.customerinfo.Address) value.
 * @return The address property value.
 * @see #setAddress
 */
public Address getAddress() {
	return fieldAddress;
}
/**
 * Gets the name property (java.lang.String) value.
 * @return The name property value.
 * @see #setName
 */
public String getName() {
	return fieldName;
}
/**
 * Gets the phone property (java.lang.String) value.
 * @return The phone property value.
 * @see #setPhone
 */
public String getPhone() {
	return fieldPhone;
}
/**
 * Accessor for the propertyChange field.
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Generates a hash code for the receiver.
 * This method is supported primarily for
 * hash tables, such as those provided in java.util.
 * @return an integer hash code for the receiver
 * @see java.util.Hashtable
 */
public int hashCode() {
	// Insert code to generate a hash code for the receiver here.
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: if two objects are equal (equals(Object) returns true) they must have the same hash code
	return super.hashCode();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Sets the address property (com.ibm.ivj.examples.vc.customerinfo.Address) value.
 * @param address The new value for the property.
 * @see #getAddress
 */
public void setAddress(Address address) {
	Address oldValue = fieldAddress;
	fieldAddress = address;
	firePropertyChange("address", oldValue, address);
}
/**
 * Sets the name property (java.lang.String) value.
 * @param name The new value for the property.
 * @see #getName
 */
public void setName(String name) {
	String oldValue = fieldName;
	fieldName = name;
	firePropertyChange("name", oldValue, name);
}
/**
 * Sets the phone property (java.lang.String) value.
 * @param phone The new value for the property.
 * @see #getPhone
 */
public void setPhone(String phone) {
	String oldValue = fieldPhone;
	fieldPhone = phone;
	firePropertyChange("phone", oldValue, phone);
}
/**
 * Returns a String that represents the value of this object.
 * @return a string representation of the receiver
 */
public String toString() {
	return 	getName()+", "+
				getAddress()+", "+
				getPhone();
}
}
