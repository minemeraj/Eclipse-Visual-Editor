package com.ibm.ivj.examples.vc.swing.directoryexplorer;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class DirectoryExplorer extends javax.swing.JFrame implements javax.swing.event.TreeSelectionListener {
	private boolean ivjConnPtoP3Aligning = false;
	private DirectoryTreeModel ivjDirectoryTreeModel1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="84,359"
	private FileTableModel ivjFileTableModel1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="597,129"
	private javax.swing.JPanel ivjJFrameContentPane = null;
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JScrollPane ivjJScrollPane2 = null;
	private javax.swing.JSplitPane ivjJSplitPane1 = null;
	private javax.swing.JTree ivjJTree1 = null;
	private javax.swing.tree.DefaultMutableTreeNode ivjlastPathComponent1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="358,348"
	private javax.swing.JTable ivjScrollPaneTable = null;
	private javax.swing.tree.TreePath ivjselectionPath1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="207,346"
	private DirectoryData ivjuserObject1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="528,353"
/**
 * Constructor
 */
public DirectoryExplorer() {
	super();
	initialize();
}
/**
 * DirectoryExplorer constructor comment.
 * @param title java.lang.String
 */
public DirectoryExplorer(String title) {
	super(title);
}
/**
 * connPtoP1SetTarget:  (DirectoryTreeModel1.this <--> JTree1.model)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getJTree1().setModel(getDirectoryTreeModel1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (FileTableModel1.this <--> ScrollPaneTable.model)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		getScrollPaneTable().setModel(getFileTableModel1());
		getScrollPaneTable().createDefaultColumnsFromModel();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (JTree1.selectionPath <--> selectionPath1.this)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getselectionPath1() != null)) {
				getJTree1().setSelectionPath(getselectionPath1());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (JTree1.selectionPath <--> selectionPath1.this)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			setselectionPath1(getJTree1().getSelectionPath());
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (selectionPath1.lastPathComponent <--> lastPathComponent1.this)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		setlastPathComponent1((javax.swing.tree.DefaultMutableTreeNode)getselectionPath1().getLastPathComponent());
	} catch (java.lang.NullPointerException myExc) {
		// Initially nothing is selected in the tree. So selection path will
		// be null. So, don't do anything when we get NullPointerException.
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (lastPathComponent1.userObject <--> userObject1.this)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if ((getlastPathComponent1() != null) && (getuserObject1() != null)) {
			getlastPathComponent1().setUserObject(getuserObject1());
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (lastPathComponent1.userObject <--> userObject1.this)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		setuserObject1((com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryData)getlastPathComponent1().getUserObject());
	} catch (java.lang.NullPointerException myExc) {
		// Initially nothing is selected in the tree. So selection path will
		// be null and beacuse of that last path component will be null too.
		// So, don't do anything when we get NullPointerException.
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP6SetTarget:  (userObject1.directory <--> FileTableModel1.directory)
 */
private void connPtoP6SetTarget() {
	/* Set the target from the source */
	try {
		if ((getuserObject1() != null)) {
			getFileTableModel1().setDirectory(getuserObject1().getDirectory());
		}
	} catch (java.lang.NullPointerException myExc) {
		// Initially nothing is selected in the tree. So selection path will
		// be null and beacuse of that userObject will be null too.
		// So, don't do anything when we get NullPointerException.		

	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP7SetTarget:  (userObject1.directory <--> DirectoryExplorer.title)
 */
private void connPtoP7SetTarget() {
	/* Set the target from the source */
	try {
		if ((getuserObject1() != null)) {
			this.setTitle(getuserObject1().getDirectory());
		}
	} catch (java.lang.NullPointerException myExc) {
		// Initially nothing is selected. Since selection path will
		// be null so, userObject will be null initially. So, don't
		// do anything when we get NullPointerException.
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Return the DirectoryTreeModel1 property value.
 * @return com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryTreeModel
 */
private DirectoryTreeModel getDirectoryTreeModel1() {
	if (ivjDirectoryTreeModel1 == null) {
		try {
			ivjDirectoryTreeModel1 = new com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryTreeModel();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjDirectoryTreeModel1;
}
/**
 * Return the FileTableModel1 property value.
 * @return com.ibm.ivj.examples.vc.swing.directoryexplorer.FileTableModel
 */
private FileTableModel getFileTableModel1() {
	if (ivjFileTableModel1 == null) {
		try {
			ivjFileTableModel1 = new com.ibm.ivj.examples.vc.swing.directoryexplorer.FileTableModel();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjFileTableModel1;
}
/**
 * Return the JFrameContentPane property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new javax.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(new java.awt.BorderLayout());
			getJFrameContentPane().add(getJSplitPane1(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJFrameContentPane;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setPreferredSize(new java.awt.Dimension(150, 20));
			ivjJScrollPane1.setMaximumSize(new java.awt.Dimension(21, 20));
			ivjJScrollPane1.setMinimumSize(new java.awt.Dimension(21, 20));
			getJScrollPane1().setViewportView(getJTree1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JScrollPane2 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane2() {
	if (ivjJScrollPane2 == null) {
		try {
			ivjJScrollPane2 = new javax.swing.JScrollPane();
			ivjJScrollPane2.setName("JScrollPane2");
			ivjJScrollPane2.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			ivjJScrollPane2.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			ivjJScrollPane2.setMaximumSize(new java.awt.Dimension(21, 20));
			ivjJScrollPane2.setPreferredSize(new java.awt.Dimension(21, 20));
			ivjJScrollPane2.setMinimumSize(new java.awt.Dimension(21, 20));
			getJScrollPane2().setViewportView(getScrollPaneTable());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane2;
}
/**
 * Return the JSplitPane1 property value.
 * @return javax.swing.JSplitPane
 */
private javax.swing.JSplitPane getJSplitPane1() {
	if (ivjJSplitPane1 == null) {
		try {
			ivjJSplitPane1 = new javax.swing.JSplitPane(javax.swing.JSplitPane.HORIZONTAL_SPLIT);
			ivjJSplitPane1.setName("JSplitPane1");
			ivjJSplitPane1.setDividerSize(5);
			ivjJSplitPane1.setDividerLocation(150);
			getJSplitPane1().add(getJScrollPane1(), "left");
			getJSplitPane1().add(getJScrollPane2(), "right");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJSplitPane1;
}
/**
 * Return the JTree1 property value.
 * @return javax.swing.JTree
 */
private javax.swing.JTree getJTree1() {
	if (ivjJTree1 == null) {
		try {
			ivjJTree1 = new javax.swing.JTree();
			ivjJTree1.setName("JTree1");
			ivjJTree1.setBounds(0, 0, 70, 36);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTree1;
}
/**
 * Return the lastPathComponent1 property value.
 * @return javax.swing.tree.DefaultMutableTreeNode
 */
private javax.swing.tree.DefaultMutableTreeNode getlastPathComponent1() {
	return ivjlastPathComponent1;
}
/**
 * Return the ScrollPaneTable property value.
 * @return javax.swing.JTable
 */
private javax.swing.JTable getScrollPaneTable() {
	if (ivjScrollPaneTable == null) {
		try {
			ivjScrollPaneTable = new javax.swing.JTable();
			ivjScrollPaneTable.setName("ScrollPaneTable");
			getJScrollPane2().setColumnHeaderView(ivjScrollPaneTable.getTableHeader());
			getJScrollPane2().getViewport().setBackingStoreEnabled(true);
			ivjScrollPaneTable.setBounds(0, 0, 200, 200);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjScrollPaneTable;
}
/**
 * Return the selectionPath1 property value.
 * @return javax.swing.tree.TreePath
 */
private javax.swing.tree.TreePath getselectionPath1() {
	return ivjselectionPath1;
}
/**
 * Return the userObject1 property value.
 * @return com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryData
 */
private DirectoryData getuserObject1() {
	return ivjuserObject1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getJTree1().addTreeSelectionListener(this);
	connPtoP1SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP6SetTarget();
	connPtoP7SetTarget();
	connPtoP2SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("DirectoryExplorer");
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setSize(506, 273);
		setContentPane(getJFrameContentPane());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryExplorer aDirectoryExplorer;
		aDirectoryExplorer = new com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryExplorer();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aDirectoryExplorer };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aDirectoryExplorer.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
/**
 * Set the lastPathComponent1 to a new value.
 * @param newValue javax.swing.tree.DefaultMutableTreeNode
 */
private void setlastPathComponent1(javax.swing.tree.DefaultMutableTreeNode newValue) {
	if (ivjlastPathComponent1 != newValue) {
		try {
			ivjlastPathComponent1 = newValue;
			connPtoP5SetTarget();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the selectionPath1 to a new value.
 * @param newValue javax.swing.tree.TreePath
 */
private void setselectionPath1(javax.swing.tree.TreePath newValue) {
	if (ivjselectionPath1 != newValue) {
		try {
			ivjselectionPath1 = newValue;
			connPtoP3SetSource();
			connPtoP4SetTarget();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the userObject1 to a new value.
 * @param newValue com.ibm.ivj.examples.vc.swing.directoryexplorer.DirectoryData
 */
private void setuserObject1(DirectoryData newValue) {
	if (ivjuserObject1 != newValue) {
		try {
			ivjuserObject1 = newValue;
			connPtoP5SetSource();
			connPtoP6SetTarget();
			connPtoP7SetTarget();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method to handle events for the TreeSelectionListener interface.
 * @param e javax.swing.event.TreeSelectionEvent
 */
public void valueChanged(javax.swing.event.TreeSelectionEvent e) {
	if (e.getSource() == getJTree1()) 
		connPtoP3SetTarget();
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
