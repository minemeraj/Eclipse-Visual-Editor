package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class GridBagLayoutPage extends java.awt.Panel implements java.awt.event.ActionListener, java.awt.event.ComponentListener, java.awt.event.WindowListener {
	private java.awt.Button ivjButton1 = null;
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints ivjLiveGridBagConstraints1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="669,267"
	private java.awt.TextArea ivjTextArea1 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
/**
 * Constructor
 */
public GridBagLayoutPage() {
	super();
	initialize();
}
/**
 * GridBagLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public GridBagLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getButton1()) 
		connEtoM1(e);
	if (e.getSource() == getButton1()) 
		connEtoM2(e);
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentHidden(java.awt.event.ComponentEvent e) {
	if (e.getSource() == this) 
		connEtoM4(e);
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentMoved(java.awt.event.ComponentEvent e) {
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentResized(java.awt.event.ComponentEvent e) {
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentShown(java.awt.event.ComponentEvent e) {
}
/**
 * connEtoM1:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> LiveGridBagConstraints1.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		getLiveGridBagConstraints1().show();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (Button1.action.actionPerformed(java.awt.event.ActionEvent) --> Button1.enabled)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		getButton1().setEnabled(false);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (LiveGridBagConstraints1.window.windowClosed(java.awt.event.WindowEvent) --> Button1.enabled)
 * @param arg1 java.awt.event.WindowEvent
 */
private void connEtoM3(java.awt.event.WindowEvent arg1) {
	try {
		getButton1().setEnabled(true);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (GridBagLayoutPage.component.componentHidden(java.awt.event.ComponentEvent) --> LiveGridBagConstraints1.dispose()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM4(java.awt.event.ComponentEvent arg1) {
	try {
		getLiveGridBagConstraints1().dispose();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (GridBagLayoutPage.this <--> LiveGridBagConstraints1.gridBagPanel)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getLiveGridBagConstraints1().setGridBagPanel(this);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Return the Button1 property value.
 * @return java.awt.Button
 */
private java.awt.Button getButton1() {
	if (ivjButton1 == null) {
		try {
			ivjButton1 = new java.awt.Button();
			ivjButton1.setName("Button1");
			ivjButton1.setLabel("Tinker with Constraints");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjButton1;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setAlignment(java.awt.Label.RIGHT);
			ivjLabel1.setText("Name");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setAlignment(java.awt.Label.RIGHT);
			ivjLabel2.setText("Rank");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setAlignment(java.awt.Label.RIGHT);
			ivjLabel3.setText("Serial#");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the LiveGridBagConstraints1 property value.
 * @return com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints
 */
private com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints getLiveGridBagConstraints1() {
	if (ivjLiveGridBagConstraints1 == null) {
		try {
			ivjLiveGridBagConstraints1 = new com.ibm.ivj.examples.vc.utilitybeans.LiveGridBagConstraints();
			ivjLiveGridBagConstraints1.setName("LiveGridBagConstraints1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLiveGridBagConstraints1;
}
/**
 * Return the TextArea1 property value.
 * @return java.awt.TextArea
 */
private java.awt.TextArea getTextArea1() {
	if (ivjTextArea1 == null) {
		try {
			ivjTextArea1 = new java.awt.TextArea();
			ivjTextArea1.setName("TextArea1");
			ivjTextArea1.setText("This is GridBagLayout.\nIt is the most complex and most powerful of the supplied layout managers.\nThis LayoutManager lets you control exactly where components end up relative to other components,\ntheir alignment, and their use of free space.\nThe layout information for each component is kept in the framing spec as a GridBagConstraint. ");
			ivjTextArea1.setBackground(java.awt.Color.white);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextArea1;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
			ivjTextField1.setBackground(java.awt.Color.white);
			ivjTextField1.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setBackground(java.awt.Color.white);
			ivjTextField2.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setBackground(java.awt.Color.white);
			ivjTextField3.setColumns(10);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getButton1().addActionListener(this);
	getLiveGridBagConstraints1().addWindowListener(this);
	this.addComponentListener(this);
	connPtoP1SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("GridBagLayoutPage");
		setLayout(new java.awt.GridBagLayout());
		setBackground(java.awt.Color.blue);
		setSize(600, 300);

		java.awt.GridBagConstraints constraintsLabel1 = new java.awt.GridBagConstraints();
		constraintsLabel1.gridx = 0; constraintsLabel1.gridy = 0;
		constraintsLabel1.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getLabel1(), constraintsLabel1);

		java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
		constraintsLabel2.gridx = 0; constraintsLabel2.gridy = 1;
		constraintsLabel2.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getLabel2(), constraintsLabel2);

		java.awt.GridBagConstraints constraintsLabel3 = new java.awt.GridBagConstraints();
		constraintsLabel3.gridx = 0; constraintsLabel3.gridy = 2;
		constraintsLabel3.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getLabel3(), constraintsLabel3);

		java.awt.GridBagConstraints constraintsTextField1 = new java.awt.GridBagConstraints();
		constraintsTextField1.gridx = 1; constraintsTextField1.gridy = 0;
		constraintsTextField1.anchor = java.awt.GridBagConstraints.WEST;
		constraintsTextField1.insets = new java.awt.Insets(10, 0, 0, 0);
		add(getTextField1(), constraintsTextField1);

		java.awt.GridBagConstraints constraintsTextField2 = new java.awt.GridBagConstraints();
		constraintsTextField2.gridx = 1; constraintsTextField2.gridy = 1;
		constraintsTextField2.anchor = java.awt.GridBagConstraints.WEST;
		add(getTextField2(), constraintsTextField2);

		java.awt.GridBagConstraints constraintsTextField3 = new java.awt.GridBagConstraints();
		constraintsTextField3.gridx = 1; constraintsTextField3.gridy = 2;
		constraintsTextField3.anchor = java.awt.GridBagConstraints.WEST;
		add(getTextField3(), constraintsTextField3);

		java.awt.GridBagConstraints constraintsButton1 = new java.awt.GridBagConstraints();
		constraintsButton1.gridx = 2; constraintsButton1.gridy = 0;
constraintsButton1.gridheight = 3;
		constraintsButton1.fill = java.awt.GridBagConstraints.VERTICAL;
		constraintsButton1.insets = new java.awt.Insets(20, 0, 20, 0);
		add(getButton1(), constraintsButton1);

		java.awt.GridBagConstraints constraintsTextArea1 = new java.awt.GridBagConstraints();
		constraintsTextArea1.gridx = 0; constraintsTextArea1.gridy = 3;
		constraintsTextArea1.gridwidth = 3;
		constraintsTextArea1.fill = java.awt.GridBagConstraints.BOTH;
		constraintsTextArea1.weightx = 1.0;
		constraintsTextArea1.weighty = 1.0;
		constraintsTextArea1.insets = new java.awt.Insets(10, 10, 10, 10);
		add(getTextArea1(), constraintsTextArea1);
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.GridBagLayoutPage aGridBagLayoutPage;
		aGridBagLayoutPage = new com.ibm.ivj.examples.vc.layoutmanagers.GridBagLayoutPage();
		frame.add("Center", aGridBagLayoutPage);
		frame.setSize(aGridBagLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowActivated(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowClosed(java.awt.event.WindowEvent e) {
	if (e.getSource() == getLiveGridBagConstraints1()) 
		connEtoM3(e);
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowClosing(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowDeactivated(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowDeiconified(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowIconified(java.awt.event.WindowEvent e) {
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
public void windowOpened(java.awt.event.WindowEvent e) {
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
