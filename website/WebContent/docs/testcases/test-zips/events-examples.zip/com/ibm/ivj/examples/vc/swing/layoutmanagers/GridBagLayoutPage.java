package com.ibm.ivj.examples.vc.swing.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class GridBagLayoutPage extends javax.swing.JPanel {
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JLabel ivjJLabel2 = null;
	private javax.swing.JLabel ivjJLabel3 = null;
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
	private javax.swing.JTextField ivjJTextField1 = null;
	private javax.swing.JTextField ivjJTextField2 = null;
	private javax.swing.JTextField ivjJTextField3 = null;
/**
 * Constructor
 */
public GridBagLayoutPage() {
	super();
	initialize();
}
/**
 * GridBagLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public GridBagLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * GridBagLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public GridBagLayoutPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * GridBagLayoutPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public GridBagLayoutPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("Name");
			ivjJLabel1.setForeground(new java.awt.Color(230,230,230));
			ivjJLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JLabel2 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel2() {
	if (ivjJLabel2 == null) {
		try {
			ivjJLabel2 = new javax.swing.JLabel();
			ivjJLabel2.setName("JLabel2");
			ivjJLabel2.setText("Rank");
			ivjJLabel2.setForeground(new java.awt.Color(230,230,230));
			ivjJLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel2;
}
/**
 * Return the JLabel3 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel3() {
	if (ivjJLabel3 == null) {
		try {
			ivjJLabel3 = new javax.swing.JLabel();
			ivjJLabel3.setName("JLabel3");
			ivjJLabel3.setText("Serial#");
			ivjJLabel3.setForeground(new java.awt.Color(230,230,230));
			ivjJLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel3;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			ivjJScrollPane1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			getJScrollPane1().setViewportView(getJTextArea1());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setText("This is a GridBagLayout.\nIt is the most complex and most powerful of the supplied layout managers.\nThis LayoutManager lets you control exactly where components end up relative to\nother components,\ntheir alignment and their use of free space.\nThe layout information for each component is kept in the framing spec as a \nGridBagConstraint.\nTo learn more about GridBagConstraints please see\ncom.ibm.ivj.examples.vc.layoutmanagers example.");
			ivjJTextArea1.setBounds(0, 0, 12, 17);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Return the JTextField2 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField2() {
	if (ivjJTextField2 == null) {
		try {
			ivjJTextField2 = new javax.swing.JTextField();
			ivjJTextField2.setName("JTextField2");
			ivjJTextField2.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField2;
}
/**
 * Return the JTextField3 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField3() {
	if (ivjJTextField3 == null) {
		try {
			ivjJTextField3 = new javax.swing.JTextField();
			ivjJTextField3.setName("JTextField3");
			ivjJTextField3.setColumns(10);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField3;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("GridBagLayoutPage");
		setLayout(new java.awt.GridBagLayout());
		setBackground(java.awt.Color.blue);
		setSize(600, 300);

		java.awt.GridBagConstraints constraintsJLabel1 = new java.awt.GridBagConstraints();
		constraintsJLabel1.gridx = 0; constraintsJLabel1.gridy = 0;
		constraintsJLabel1.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getJLabel1(), constraintsJLabel1);

		java.awt.GridBagConstraints constraintsJLabel2 = new java.awt.GridBagConstraints();
		constraintsJLabel2.gridx = 0; constraintsJLabel2.gridy = 1;
		constraintsJLabel2.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getJLabel2(), constraintsJLabel2);

		java.awt.GridBagConstraints constraintsJLabel3 = new java.awt.GridBagConstraints();
		constraintsJLabel3.gridx = 0; constraintsJLabel3.gridy = 2;
		constraintsJLabel3.anchor = java.awt.GridBagConstraints.SOUTHWEST;
		add(getJLabel3(), constraintsJLabel3);

		java.awt.GridBagConstraints constraintsJTextField1 = new java.awt.GridBagConstraints();
		constraintsJTextField1.gridx = 1; constraintsJTextField1.gridy = 0;
		constraintsJTextField1.anchor = java.awt.GridBagConstraints.WEST;
		constraintsJTextField1.insets = new java.awt.Insets(10, 0, 0, 0);
		add(getJTextField1(), constraintsJTextField1);

		java.awt.GridBagConstraints constraintsJTextField2 = new java.awt.GridBagConstraints();
		constraintsJTextField2.gridx = 1; constraintsJTextField2.gridy = 1;
		constraintsJTextField2.anchor = java.awt.GridBagConstraints.WEST;
		add(getJTextField2(), constraintsJTextField2);

		java.awt.GridBagConstraints constraintsJTextField3 = new java.awt.GridBagConstraints();
		constraintsJTextField3.gridx = 1; constraintsJTextField3.gridy = 2;
		constraintsJTextField3.anchor = java.awt.GridBagConstraints.WEST;
		add(getJTextField3(), constraintsJTextField3);

		java.awt.GridBagConstraints constraintsJScrollPane1 = new java.awt.GridBagConstraints();
		constraintsJScrollPane1.gridx = 0; constraintsJScrollPane1.gridy = 3;
		constraintsJScrollPane1.gridwidth = 3;
		constraintsJScrollPane1.fill = java.awt.GridBagConstraints.BOTH;
		constraintsJScrollPane1.weightx = 1.0;
		constraintsJScrollPane1.weighty = 1.0;
		constraintsJScrollPane1.insets = new java.awt.Insets(10, 0, 0, 0);
		add(getJScrollPane1(), constraintsJScrollPane1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		com.ibm.ivj.examples.vc.swing.layoutmanagers.GridBagLayoutPage aGridBagLayoutPage;
		aGridBagLayoutPage = new com.ibm.ivj.examples.vc.swing.layoutmanagers.GridBagLayoutPage();
		frame.getContentPane().add("Center", aGridBagLayoutPage);
		frame.setSize(aGridBagLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
