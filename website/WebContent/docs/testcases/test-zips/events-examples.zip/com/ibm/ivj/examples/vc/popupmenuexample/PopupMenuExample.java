package com.ibm.ivj.examples.vc.popupmenuexample;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class PopupMenuExample extends java.applet.Applet implements java.awt.event.ActionListener, java.awt.event.MouseListener, java.beans.PropertyChangeListener {
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP2Aligning = false;
	private java.awt.Label ivjLabel = null;  // @jve:visual-info  decl-index=0 visual-constraint="761,315"
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.Label ivjLabel6 = null;
	private java.awt.Label ivjLabel7 = null;
	private java.awt.Menu ivjMenu2 = null;
	private java.awt.Menu ivjMenu3 = null;
	private java.awt.Menu ivjMenu4 = null;
	private java.awt.MenuItem ivjMenuItem1 = null;
	private java.awt.MenuItem ivjMenuItem10 = null;
	private java.awt.MenuItem ivjMenuItem11 = null;
	private java.awt.MenuItem ivjMenuItem2 = null;
	private java.awt.MenuItem ivjMenuItem3 = null;
	private java.awt.MenuItem ivjMenuItem4 = null;
	private java.awt.MenuItem ivjMenuItem5 = null;
	private java.awt.MenuItem ivjMenuItem6 = null;
	private java.awt.MenuItem ivjMenuItem7 = null;
	private java.awt.MenuItem ivjMenuItem8 = null;
	private java.awt.MenuItem ivjMenuItem9 = null;
	private java.awt.Component ivjownerComponent_of_PupupMenuBean1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="848,348"
	private java.awt.Panel ivjPanel1 = null;
	private java.awt.GridLayout ivjPanel1GridLayout = null;
	private com.ibm.ivj.examples.vc.utilitybeans.PopupMenuBean ivjPopupMenuBean1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="806,118"
/**
 * PopupMenuExample constructor comment.
 */
public PopupMenuExample() {
	super();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if (e.getSource() == getMenuItem1()) 
		connEtoM14(e);
	if (e.getSource() == getMenuItem2()) 
		connEtoM15(e);
	if (e.getSource() == getMenuItem3()) 
		connEtoM16(e);
	if (e.getSource() == getMenuItem4()) 
		connEtoM17(e);
	if (e.getSource() == getMenuItem5()) 
		connEtoM18(e);
	if (e.getSource() == getMenuItem6()) 
		connEtoM19(e);
	if (e.getSource() == getMenuItem7()) 
		connEtoM20(e);
	if (e.getSource() == getMenuItem8()) 
		connEtoM21(e);
	if (e.getSource() == getMenuItem9()) 
		connEtoM22(e);
	if (e.getSource() == getMenuItem10()) 
		connEtoM23(e);
	if (e.getSource() == getMenuItem11()) 
		connEtoM24(e);
}
/**
 * connEtoM10:  (Label4.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM10(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM11:  (Label5.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM11(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM12:  (Label6.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM12(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM13:  (Label7.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM13(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM14:  (MenuItem1.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.foreground)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM14(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setForeground(java.awt.Color.red);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM15:  (MenuItem2.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.foreground)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM15(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setForeground(java.awt.Color.yellow);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM16:  (MenuItem3.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.foreground)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM16(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setForeground(java.awt.Color.blue);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM17:  (MenuItem4.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.foreground)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM17(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setForeground(java.awt.Color.green);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM18:  (MenuItem5.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.font)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM18(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setFont(getMenuItem5().getFont());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM19:  (MenuItem6.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.font)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM19(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setFont(getMenuItem6().getFont());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM20:  (MenuItem7.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.font)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM20(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setFont(getMenuItem7().getFont());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM21:  (MenuItem8.action.actionPerformed(java.awt.event.ActionEvent) --> ownerComponent_of_PupupMenuBean1.font)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM21(java.awt.event.ActionEvent arg1) {
	try {
		getownerComponent_of_PupupMenuBean1().setFont(getMenuItem8().getFont());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM22:  (MenuItem9.action.actionPerformed(java.awt.event.ActionEvent) --> Label.alignment)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM22(java.awt.event.ActionEvent arg1) {
	try {
		getLabel().setAlignment(0);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM23:  (MenuItem10.action.actionPerformed(java.awt.event.ActionEvent) --> Label.alignment)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM23(java.awt.event.ActionEvent arg1) {
	try {
		getLabel().setAlignment(1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM24:  (MenuItem11.action.actionPerformed(java.awt.event.ActionEvent) --> Label.alignment)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM24(java.awt.event.ActionEvent arg1) {
	try {
		getLabel().setAlignment(2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (Label2.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM8(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  (Label3.mouse.mouseReleased(java.awt.event.MouseEvent) --> PopupMenuBean1.show(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
private void connEtoM9(java.awt.event.MouseEvent arg1) {
	try {
		getPopupMenuBean1().show(arg1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetSource:  (PopupMenuBean1.ownerComponent <--> ownerComponent_of_PupupMenuBean1.this)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getownerComponent_of_PupupMenuBean1() != null)) {
				getPopupMenuBean1().setOwnerComponent(getownerComponent_of_PupupMenuBean1());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (PopupMenuBean1.ownerComponent <--> ownerComponent_of_PupupMenuBean1.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			setownerComponent_of_PupupMenuBean1(getPopupMenuBean1().getOwnerComponent());
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (ownerComponent_of_PupupMenuBean1.this <--> Label.this)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			setownerComponent_of_PupupMenuBean1(getLabel());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (ownerComponent_of_PupupMenuBean1.this <--> Label.this)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			setLabel((java.awt.Label)getownerComponent_of_PupupMenuBean1());
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.popupmenuexample.PopupMenuExample created using VisualAge for Java.";
}
/**
 * Return the Label property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel() {
	return ivjLabel;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setAlignment(java.awt.Label.CENTER);
			ivjLabel1.setFont(new java.awt.Font("dialog", 0, 36));
			ivjLabel1.setText("Popup Menu Example");
			ivjLabel1.setBackground(java.awt.Color.blue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("This sample uses a subclass of");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setFont(new java.awt.Font("dialog", 0, 18));
			ivjLabel3.setText("java.awt.Popup");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("to improve the ease-of-use of popup menus for");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setFont(new java.awt.Font("dialog", 1, 36));
			ivjLabel5.setText("Visual Composition");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setText("Right mouse click over one of these labels");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel6;
}
/**
 * Return the Label7 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel7() {
	if (ivjLabel7 == null) {
		try {
			ivjLabel7 = new java.awt.Label();
			ivjLabel7.setName("Label7");
			ivjLabel7.setText("to see the popup menu.");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel7;
}
/**
 * Return the Menu2 property value.
 * @return java.awt.Menu
 */
private java.awt.Menu getMenu2() {
	if (ivjMenu2 == null) {
		try {
			ivjMenu2 = new java.awt.Menu();
			ivjMenu2.setLabel("Font");
			ivjMenu2.add(getMenuItem5());
			ivjMenu2.add(getMenuItem6());
			ivjMenu2.add(getMenuItem7());
			ivjMenu2.add(getMenuItem8());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenu2;
}
/**
 * Return the Menu3 property value.
 * @return java.awt.Menu
 */
private java.awt.Menu getMenu3() {
	if (ivjMenu3 == null) {
		try {
			ivjMenu3 = new java.awt.Menu();
			ivjMenu3.setLabel("Alignment");
			ivjMenu3.add(getMenuItem9());
			ivjMenu3.add(getMenuItem10());
			ivjMenu3.add(getMenuItem11());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenu3;
}
/**
 * Return the Menu4 property value.
 * @return java.awt.Menu
 */
private java.awt.Menu getMenu4() {
	if (ivjMenu4 == null) {
		try {
			ivjMenu4 = new java.awt.Menu();
			ivjMenu4.setLabel("Color");
			ivjMenu4.add(getMenuItem1());
			ivjMenu4.add(getMenuItem2());
			ivjMenu4.add(getMenuItem3());
			ivjMenu4.add(getMenuItem4());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenu4;
}
/**
 * Return the MenuItem1 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem1() {
	if (ivjMenuItem1 == null) {
		try {
			ivjMenuItem1 = new java.awt.MenuItem();
			ivjMenuItem1.setLabel("Red");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem1;
}
/**
 * Return the MenuItem10 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem10() {
	if (ivjMenuItem10 == null) {
		try {
			ivjMenuItem10 = new java.awt.MenuItem();
			ivjMenuItem10.setLabel("Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem10;
}
/**
 * Return the MenuItem11 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem11() {
	if (ivjMenuItem11 == null) {
		try {
			ivjMenuItem11 = new java.awt.MenuItem();
			ivjMenuItem11.setLabel("Right");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem11;
}
/**
 * Return the MenuItem2 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem2() {
	if (ivjMenuItem2 == null) {
		try {
			ivjMenuItem2 = new java.awt.MenuItem();
			ivjMenuItem2.setLabel("Yellow");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem2;
}
/**
 * Return the MenuItem3 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem3() {
	if (ivjMenuItem3 == null) {
		try {
			ivjMenuItem3 = new java.awt.MenuItem();
			ivjMenuItem3.setLabel("Blue");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem3;
}
/**
 * Return the MenuItem4 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem4() {
	if (ivjMenuItem4 == null) {
		try {
			ivjMenuItem4 = new java.awt.MenuItem();
			ivjMenuItem4.setLabel("Green");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem4;
}
/**
 * Return the MenuItem5 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem5() {
	if (ivjMenuItem5 == null) {
		try {
			ivjMenuItem5 = new java.awt.MenuItem();
			ivjMenuItem5.setFont(new java.awt.Font("monospaced", 3, 48));
			ivjMenuItem5.setLabel("Huge");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem5;
}
/**
 * Return the MenuItem6 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem6() {
	if (ivjMenuItem6 == null) {
		try {
			ivjMenuItem6 = new java.awt.MenuItem();
			ivjMenuItem6.setFont(new java.awt.Font("monospaced", 1, 24));
			ivjMenuItem6.setLabel("Large");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem6;
}
/**
 * Return the MenuItem7 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem7() {
	if (ivjMenuItem7 == null) {
		try {
			ivjMenuItem7 = new java.awt.MenuItem();
			ivjMenuItem7.setFont(new java.awt.Font("monospaced", 0, 12));
			ivjMenuItem7.setLabel("Medium");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem7;
}
/**
 * Return the MenuItem8 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem8() {
	if (ivjMenuItem8 == null) {
		try {
			ivjMenuItem8 = new java.awt.MenuItem();
			ivjMenuItem8.setFont(new java.awt.Font("monospaced", 2, 8));
			ivjMenuItem8.setLabel("Tiny");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem8;
}
/**
 * Return the MenuItem9 property value.
 * @return java.awt.MenuItem
 */
private java.awt.MenuItem getMenuItem9() {
	if (ivjMenuItem9 == null) {
		try {
			ivjMenuItem9 = new java.awt.MenuItem();
			ivjMenuItem9.setLabel("Left");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjMenuItem9;
}
/**
 * Return the ownerComponent_of_PupupMenuBean1 property value.
 * @return java.awt.Component
 */
private java.awt.Component getownerComponent_of_PupupMenuBean1() {
	return ivjownerComponent_of_PupupMenuBean1;
}
/**
 * Return the Panel1 property value.
 * @return java.awt.Panel
 */
private java.awt.Panel getPanel1() {
	if (ivjPanel1 == null) {
		try {
			ivjPanel1 = new java.awt.Panel();
			ivjPanel1.setName("Panel1");
			ivjPanel1.setLayout(getPanel1GridLayout());
			ivjPanel1.add(getLabel2());
			getPanel1().add(getLabel3(), getLabel3().getName());
			getPanel1().add(getLabel4(), getLabel4().getName());
			getPanel1().add(getLabel5(), getLabel5().getName());
			getPanel1().add(getLabel6(), getLabel6().getName());
			getPanel1().add(getLabel7(), getLabel7().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPanel1;
}
/**
 * Return the Panel1GridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getPanel1GridLayout() {
	java.awt.GridLayout ivjPanel1GridLayout = null;
	try {
		/* Create part */
		ivjPanel1GridLayout = new java.awt.GridLayout();
		ivjPanel1GridLayout.setRows(9);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjPanel1GridLayout;
}
/**
 * Return the PopupMenuBean1 property value.
 * @return com.ibm.ivj.examples.vc.utilitybeans.PopupMenuBean
 */
private com.ibm.ivj.examples.vc.utilitybeans.PopupMenuBean getPopupMenuBean1() {
	if (ivjPopupMenuBean1 == null) {
		try {
			ivjPopupMenuBean1 = new com.ibm.ivj.examples.vc.utilitybeans.PopupMenuBean();
			ivjPopupMenuBean1.setLabel("Popup");
			ivjPopupMenuBean1.add(getMenu4());
			ivjPopupMenuBean1.add(getMenu2());
			ivjPopupMenuBean1.add(getMenu3());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjPopupMenuBean1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		super.init();
		setName("PopupMenuExample");
		setLayout(new java.awt.BorderLayout());
		setSize(500, 400);
		add(getLabel1(), "North");
		add(getPanel1(), "Center");
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getLabel2().addMouseListener(this);
	getLabel3().addMouseListener(this);
	getLabel4().addMouseListener(this);
	getLabel5().addMouseListener(this);
	getLabel6().addMouseListener(this);
	getLabel7().addMouseListener(this);
	getPopupMenuBean1().addPropertyChangeListener(this);
	getMenuItem1().addActionListener(this);
	getMenuItem2().addActionListener(this);
	getMenuItem3().addActionListener(this);
	getMenuItem4().addActionListener(this);
	getMenuItem5().addActionListener(this);
	getMenuItem6().addActionListener(this);
	getMenuItem7().addActionListener(this);
	getMenuItem8().addActionListener(this);
	getMenuItem9().addActionListener(this);
	getMenuItem10().addActionListener(this);
	getMenuItem11().addActionListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.popupmenuexample.PopupMenuExample aPopupMenuExample;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.popupmenuexample.PopupMenuExample");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aPopupMenuExample = (com.ibm.ivj.examples.vc.popupmenuexample.PopupMenuExample)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.popupmenuexample.PopupMenuExample");
		frame.add("Center", aPopupMenuExample);
		frame.setSize(aPopupMenuExample.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.applet.Applet");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(java.awt.event.MouseEvent e) {
	if (e.getSource() == getLabel2()) 
		connEtoM8(e);
	if (e.getSource() == getLabel3()) 
		connEtoM9(e);
	if (e.getSource() == getLabel4()) 
		connEtoM10(e);
	if (e.getSource() == getLabel5()) 
		connEtoM11(e);
	if (e.getSource() == getLabel6()) 
		connEtoM12(e);
	if (e.getSource() == getLabel7()) 
		connEtoM13(e);
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getPopupMenuBean1() && (evt.getPropertyName().equals("ownerComponent"))) 
		connPtoP1SetTarget();
}
/**
 * Set the Label to a new value.
 * @param newValue java.awt.Label
 */
private void setLabel(java.awt.Label newValue) {
	if (ivjLabel != newValue) {
		try {
			ivjLabel = newValue;
			connPtoP2SetSource();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Set the ownerComponent_of_PupupMenuBean1 to a new value.
 * @param newValue java.awt.Component
 */
private void setownerComponent_of_PupupMenuBean1(java.awt.Component newValue) {
	if (ivjownerComponent_of_PupupMenuBean1 != newValue) {
		try {
			ivjownerComponent_of_PupupMenuBean1 = newValue;
			connPtoP1SetSource();
			connPtoP2SetTarget();
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
