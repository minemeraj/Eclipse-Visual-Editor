package com.ibm.ivj.examples.vc.customerinfo;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class Address implements java.lang.Cloneable {
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private String fieldStreet = new String();
	private String fieldCity = new String();
	private String fieldState = new String();
	private String fieldZipCode = new String();
/**
 * Address constructor comment.
 */
public Address() {
	super();
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @exception java.lang.CloneNotSupportedException The exception description.
 */
public java.lang.Object clone() throws CloneNotSupportedException {
	Address addressClone = new Address();
	addressClone.setStreet(this.getStreet());
	addressClone.setCity(this.getCity());
	addressClone.setState(this.getState());
	addressClone.setZipCode(this.getZipCode());
	return addressClone;
}
/**
 * This method was created in VisualAge.
 * @param source com.ibm.ivj.examples.vc.customerinfo.Address
 */
public void copyFrom (Address source) {
	this.setStreet(source.getStreet());
	this.setCity(source.getCity());
	this.setState(source.getState());
	this.setZipCode(source.getZipCode());
}
/**
 * Compares two Objects for equality.
 * Returns a boolean that indicates whether this Object is equivalent 
 * to the specified Object. This method is used when an Object is stored
 * in a hashtable.
 * @param	obj	the Object to compare with
 * @return	true if these Objects are equal; false otherwise.
 * @see		java.util.Hashtable
 */
public boolean equals(Object obj) {
	
	if (obj == null)
		return false;

	if (this == obj)
		return true;

	// If this class does not directly inherit from  Object  ,
	// if (!super.equals(obj)) return false;

	if (this.getClass() != obj.getClass()) 
		return false;

	Address addressObj = (Address)obj;

	if (this.getCity() == null  &&  addressObj.getCity() != null) 
			return false;
	else if (this.getCity() != null  &&  !this.getCity().equals(addressObj.getCity()))
		return false;

	if (this.getState() == null  &&  addressObj.getState() != null) 
			return false;
	else if (this.getState() != null  &&  !this.getState().equals(addressObj.getState()))
		return false;

	if (this.getStreet() == null  &&  addressObj.getStreet() != null) 
			return false;
	else if (this.getStreet() != null  &&  !this.getStreet().equals(addressObj.getStreet()))
		return false;

	if (this.getZipCode() == null  &&  addressObj.getZipCode() != null) 
			return false;
	else if (this.getZipCode() != null  &&  !this.getZipCode().equals(addressObj.getZipCode()))
		return false;

	// passed all tests,
	return true;
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the city property (java.lang.String) value.
 * @return The city property value.
 * @see #setCity
 */
public String getCity() {
	return fieldCity;
}
/**
 * Accessor for the propertyChange field.
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Gets the state property (java.lang.String) value.
 * @return The state property value.
 * @see #setState
 */
public String getState() {
	return fieldState;
}
/**
 * Gets the street property (java.lang.String) value.
 * @return The street property value.
 * @see #setStreet
 */
public String getStreet() {
	return fieldStreet;
}
/**
 * Gets the zipCode property (java.lang.String) value.
 * @return The zipCode property value.
 * @see #setZipCode
 */
public String getZipCode() {
	return fieldZipCode;
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Sets the city property (java.lang.String) value.
 * @param city The new value for the property.
 * @see #getCity
 */
public void setCity(String city) {
	String oldValue = fieldCity;
	fieldCity = city;
	firePropertyChange("city", oldValue, city);
}
/**
 * Sets the state property (java.lang.String) value.
 * @param state The new value for the property.
 * @see #getState
 */
public void setState(String state) {
	String oldValue = fieldState;
	fieldState = state;
	firePropertyChange("state", oldValue, state);
}
/**
 * Sets the street property (java.lang.String) value.
 * @param street The new value for the property.
 * @see #getStreet
 */
public void setStreet(String street) {
	String oldValue = fieldStreet;
	fieldStreet = street;
	firePropertyChange("street", oldValue, street);
}
/**
 * Sets the zipCode property (java.lang.String) value.
 * @param zipCode The new value for the property.
 * @see #getZipCode
 */
public void setZipCode(String zipCode) {
	String oldValue = fieldZipCode;
	fieldZipCode = zipCode;
	firePropertyChange("zipCode", oldValue, zipCode);
}
/**
 * Returns a String that represents the value of this object.
 */
public String toString() {
	return 	getStreet()+", "+
				getCity()+", "+
				getState()+", "+
				getZipCode();
}
}
