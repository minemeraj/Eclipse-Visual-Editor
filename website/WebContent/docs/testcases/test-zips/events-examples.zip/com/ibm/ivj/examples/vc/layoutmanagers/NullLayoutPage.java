package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class NullLayoutPage extends java.awt.Panel {
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel10 = null;
	private java.awt.Label ivjLabel11 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.Label ivjLabel6 = null;
	private java.awt.Label ivjLabel7 = null;
	private java.awt.Label ivjLabel8 = null;
	private java.awt.Label ivjLabel9 = null;
/**
 * Constructor
 */
public NullLayoutPage() {
	super();
	initialize();
}
/**
 * NullLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public NullLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setFont(new java.awt.Font("dialog", 1, 36));
			ivjLabel1.setText("Layout Managers");
			ivjLabel1.setBounds(10, 15, 300, 40);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label10 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel10() {
	if (ivjLabel10 == null) {
		try {
			ivjLabel10 = new java.awt.Label();
			ivjLabel10.setName("Label10");
			ivjLabel10.setFont(new java.awt.Font("dialog", 0, 10));
			ivjLabel10.setText(", therefore when you resize it,");
			ivjLabel10.setBounds(123, 216, 225, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel10;
}
/**
 * Return the Label11 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel11() {
	if (ivjLabel11 == null) {
		try {
			ivjLabel11 = new java.awt.Label();
			ivjLabel11.setName("Label11");
			ivjLabel11.setText("the labels remain fixed relative to the page origin.");
			ivjLabel11.setBounds(8, 254, 493, 22);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel11;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setAlignment(java.awt.Label.RIGHT);
			ivjLabel2.setText("are used to arrange components in a ");
			ivjLabel2.setBounds(17, 63, 210, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setFont(new java.awt.Font("dialog", 1, 18));
			ivjLabel3.setText("Container");
			ivjLabel3.setBounds(261, 66, 100, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("When the container is resized, moved,");
			ivjLabel4.setBounds(25, 95, 210, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setAlignment(java.awt.Label.RIGHT);
			ivjLabel5.setText("or components are added or removed, the");
			ivjLabel5.setBounds(12, 123, 250, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the Label6 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel6() {
	if (ivjLabel6 == null) {
		try {
			ivjLabel6 = new java.awt.Label();
			ivjLabel6.setName("Label6");
			ivjLabel6.setFont(new java.awt.Font("monospaced", 2, 18));
			ivjLabel6.setText("LayoutManager ");
			ivjLabel6.setBounds(277, 119, 150, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel6;
}
/**
 * Return the Label7 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel7() {
	if (ivjLabel7 == null) {
		try {
			ivjLabel7 = new java.awt.Label();
			ivjLabel7.setName("Label7");
			ivjLabel7.setText("grows, shrinks, aligns, hides, or shows components in a predefined layout.");
			ivjLabel7.setBounds(28, 150, 450, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel7;
}
/**
 * Return the Label8 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel8() {
	if (ivjLabel8 == null) {
		try {
			ivjLabel8 = new java.awt.Label();
			ivjLabel8.setName("Label8");
			ivjLabel8.setAlignment(java.awt.Label.RIGHT);
			ivjLabel8.setFont(new java.awt.Font("dialog", 0, 10));
			ivjLabel8.setText("The layout of this panel is");
			ivjLabel8.setBounds(17, 188, 200, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel8;
}
/**
 * Return the Label9 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel9() {
	if (ivjLabel9 == null) {
		try {
			ivjLabel9 = new java.awt.Label();
			ivjLabel9.setName("Label9");
			ivjLabel9.setAlignment(java.awt.Label.CENTER);
			ivjLabel9.setFont(new java.awt.Font("dialog", 1, 18));
			ivjLabel9.setText("NULL");
			ivjLabel9.setBackground(java.awt.Color.orange);
			ivjLabel9.setBounds(230, 185, 52, 23);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel9;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("NullLayoutPage");
		setLayout(null);
		setBackground(java.awt.Color.yellow);
		setSize(700, 300);
		add(getLabel1(), getLabel1().getName());
		add(getLabel2(), getLabel2().getName());
		add(getLabel3(), getLabel3().getName());
		add(getLabel4(), getLabel4().getName());
		add(getLabel5(), getLabel5().getName());
		add(getLabel6(), getLabel6().getName());
		add(getLabel7(), getLabel7().getName());
		add(getLabel8(), getLabel8().getName());
		add(getLabel9(), getLabel9().getName());
		add(getLabel10(), getLabel10().getName());
		add(getLabel11(), getLabel11().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.NullLayoutPage aNullLayoutPage;
		aNullLayoutPage = new com.ibm.ivj.examples.vc.layoutmanagers.NullLayoutPage();
		frame.add("Center", aNullLayoutPage);
		frame.setSize(aNullLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
