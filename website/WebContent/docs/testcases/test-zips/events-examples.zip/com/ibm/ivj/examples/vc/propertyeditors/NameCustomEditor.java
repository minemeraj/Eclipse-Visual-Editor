package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class NameCustomEditor extends java.awt.Panel implements java.awt.event.ItemListener, java.beans.PropertyChangeListener {
	protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
	private java.awt.Choice ivjChoice1 = null;
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private boolean ivjConnPtoP5Aligning = false;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JLabel ivjJLabel2 = null;
	private javax.swing.JLabel ivjJLabel3 = null;
	private javax.swing.JLabel ivjJLabel4 = null;
	private javax.swing.JTextField ivjJTextField1 = null;
	private javax.swing.JTextField ivjJTextField2 = null;
	private javax.swing.JTextField ivjJTextField3 = null;
	private Name ivjTheName = null;  // @jve:visual-info  decl-index=0 visual-constraint="347,83"
/**
 * Constructor
 */
public NameCustomEditor() {
	super();
	initialize();
}
/**
 * NameCustomEditor constructor comment.
 * @param layout java.awt.LayoutManager
 */
public NameCustomEditor(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
/**
 * connEtoM1:  (TheName.this --> Choice1.select(Ljava.lang.String;)V)
 * @param value com.ibm.ivj.examples.vc.propertyeditors.Name
 */
private void connEtoM1(Name value) {
	try {
		if ((getTheName() != null)) {
			getChoice1().select(getTheName().getTitle());
		}
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (Choice1.selectedItem <--> TheName.title)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getTheName() != null)) {
				getTheName().setTitle(getChoice1().getSelectedItem());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (TheName.first <--> JTextField1.text)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getTheName() != null)) {
				getTheName().setFirst(getJTextField1().getText());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (TheName.first <--> JTextField1.text)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getTheName() != null)) {
				getJTextField1().setText(getTheName().getFirst());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (TheName.middle <--> JTextField2.text)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			if ((getTheName() != null)) {
				getTheName().setMiddle(getJTextField2().getText());
			}
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (TheName.middle <--> JTextField2.text)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			if ((getTheName() != null)) {
				getJTextField2().setText(getTheName().getMiddle());
			}
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetSource:  (TheName.last <--> JTextField3.text)
 */
private void connPtoP5SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			if ((getTheName() != null)) {
				getTheName().setLast(getJTextField3().getText());
			}
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP5SetTarget:  (TheName.last <--> JTextField3.text)
 */
private void connPtoP5SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP5Aligning == false) {
			ivjConnPtoP5Aligning = true;
			if ((getTheName() != null)) {
				getJTextField3().setText(getTheName().getLast());
			}
			ivjConnPtoP5Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP5Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 * @param propertyName java.lang.String
 * @param oldValue java.lang.Object
 * @param newValue java.lang.Object
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Return the Choice1 property value.
 * @return java.awt.Choice
 */
private java.awt.Choice getChoice1() {
	if (ivjChoice1 == null) {
		try {
			ivjChoice1 = new java.awt.Choice();
			ivjChoice1.setName("Choice1");
			ivjChoice1.setBounds(114, 16, 83, 25);
			ivjChoice1.add("");
			ivjChoice1.add("Miss");
			ivjChoice1.add("Mr.");
			ivjChoice1.add("Mrs.");
			ivjChoice1.add("Ms.");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjChoice1;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("Title");
			ivjJLabel1.setBounds(26, 19, 37, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JLabel2 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel2() {
	if (ivjJLabel2 == null) {
		try {
			ivjJLabel2 = new javax.swing.JLabel();
			ivjJLabel2.setName("JLabel2");
			ivjJLabel2.setText("First");
			ivjJLabel2.setBounds(26, 56, 37, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel2;
}
/**
 * Return the JLabel3 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel3() {
	if (ivjJLabel3 == null) {
		try {
			ivjJLabel3 = new javax.swing.JLabel();
			ivjJLabel3.setName("JLabel3");
			ivjJLabel3.setText("Middle");
			ivjJLabel3.setBounds(26, 93, 51, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel3;
}
/**
 * Return the JLabel4 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel4() {
	if (ivjJLabel4 == null) {
		try {
			ivjJLabel4 = new javax.swing.JLabel();
			ivjJLabel4.setName("JLabel4");
			ivjJLabel4.setText("Last");
			ivjJLabel4.setBounds(26, 130, 35, 18);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel4;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1");
			ivjJTextField1.setBounds(114, 55, 108, 21);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Return the JTextField2 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField2() {
	if (ivjJTextField2 == null) {
		try {
			ivjJTextField2 = new javax.swing.JTextField();
			ivjJTextField2.setName("JTextField2");
			ivjJTextField2.setBounds(114, 92, 108, 21);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField2;
}
/**
 * Return the JTextField3 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getJTextField3() {
	if (ivjJTextField3 == null) {
		try {
			ivjJTextField3 = new javax.swing.JTextField();
			ivjJTextField3.setName("JTextField3");
			ivjJTextField3.setBounds(114, 129, 108, 21);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTextField3;
}
/**
 * Return the TheName property value.
 * @return com.ibm.ivj.examples.vc.propertyeditors.Name
 */
private Name getTheName() {
	return ivjTheName;
}
/**
 * Method generated to support the promotion of the theNameThis attribute.
 * @return com.ibm.ivj.examples.vc.propertyeditors.Name
 */
public Name getTheNameThis() {
		return getTheName();
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getJTextField1().addPropertyChangeListener(this);
	getJTextField2().addPropertyChangeListener(this);
	getJTextField3().addPropertyChangeListener(this);
	getChoice1().addItemListener(this);
	connPtoP3SetTarget();
	connPtoP4SetTarget();
	connPtoP5SetTarget();
	connPtoP1SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("NameCustomEditor");
		setLayout(null);
		setSize(259, 169);
		add(getJLabel1(), getJLabel1().getName());
		add(getJLabel2(), getJLabel2().getName());
		add(getJLabel3(), getJLabel3().getName());
		add(getJLabel4(), getJLabel4().getName());
		add(getChoice1(), getChoice1().getName());
		add(getJTextField1(), getJTextField1().getName());
		add(getJTextField2(), getJTextField2().getName());
		add(getJTextField3(), getJTextField3().getName());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	if (e.getSource() == getChoice1()) 
		connPtoP1SetTarget();
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame = new java.awt.Frame();
		NameCustomEditor aNameCustomEditor;
		aNameCustomEditor = new NameCustomEditor();
		frame.add("Center", aNameCustomEditor);
		frame.setSize(aNameCustomEditor.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getTheName() && (evt.getPropertyName().equals("first"))) 
		connPtoP3SetTarget();
	if (evt.getSource() == getJTextField1()) 
		connPtoP3SetSource();
	if (evt.getSource() == getTheName() && (evt.getPropertyName().equals("middle"))) 
		connPtoP4SetTarget();
	if (evt.getSource() == getJTextField2()) 
		connPtoP4SetSource();
	if (evt.getSource() == getTheName() && (evt.getPropertyName().equals("last"))) 
		connPtoP5SetTarget();
	if (evt.getSource() == getJTextField3()) 
		connPtoP5SetSource();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * Set the TheName to a new value.
 * @param newValue com.ibm.ivj.examples.vc.propertyeditors.Name
 */
private void setTheName(Name newValue) {
	if (ivjTheName != newValue) {
		try {
			com.ibm.ivj.examples.vc.propertyeditors.Name oldValue = getTheName();
			/* Stop listening for events from the current object */
			if (ivjTheName != null) {
				ivjTheName.removePropertyChangeListener(this);
			}
			ivjTheName = newValue;

			/* Listen for events from the new object */
			if (ivjTheName != null) {
				ivjTheName.addPropertyChangeListener(this);
			}
			connEtoM1(ivjTheName);
			connPtoP3SetTarget();
			connPtoP4SetTarget();
			connPtoP5SetTarget();
			connPtoP1SetTarget();
			firePropertyChange("theNameThis", oldValue, newValue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method generated to support the promotion of the theNameThis attribute.
 * @param arg1 com.ibm.ivj.examples.vc.propertyeditors.Name
 */
public void setTheNameThis(Name arg1) {
		setTheName(arg1);
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
