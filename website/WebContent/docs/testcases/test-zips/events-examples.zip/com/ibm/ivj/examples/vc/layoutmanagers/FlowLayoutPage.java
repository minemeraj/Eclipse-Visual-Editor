package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class FlowLayoutPage extends java.awt.Panel {
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.TextArea ivjTextArea1 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
/**
 * Constructor
 */
public FlowLayoutPage() {
	super();
	initialize();
}
/**
 * FlowLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public FlowLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Name");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("Rank");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("Serial#");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the TextArea1 property value.
 * @return java.awt.TextArea
 */
private java.awt.TextArea getTextArea1() {
	if (ivjTextArea1 == null) {
		try {
			ivjTextArea1 = new java.awt.TextArea();
			ivjTextArea1.setName("TextArea1");
			ivjTextArea1.setRows(5);
			ivjTextArea1.setText("This is a FlowLayout panel.\nComponents are laid out sequentially, horizontally, until there is no more room.\nThen a new row is started.\nTry resizing and see what happens.");
			ivjTextArea1.setBackground(new java.awt.Color(223,255,223));
			ivjTextArea1.setColumns(30);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextArea1;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
			ivjTextField1.setBackground(new java.awt.Color(233,255,223));
			ivjTextField1.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setBackground(new java.awt.Color(233,255,223));
			ivjTextField2.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setBackground(new java.awt.Color(223,255,223));
			ivjTextField3.setColumns(20);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("FlowLayoutPage");
		setLayout(new java.awt.FlowLayout());
		setBackground(java.awt.Color.green);
		setSize(426, 240);
		add(getLabel1());
		add(getTextField1(), getTextField1().getName());
		add(getLabel2(), getLabel2().getName());
		add(getTextField2(), getTextField2().getName());
		add(getLabel3(), getLabel3().getName());
		add(getTextField3(), getTextField3().getName());
		add(getTextArea1(), getTextArea1().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.FlowLayoutPage aFlowLayoutPage;
		aFlowLayoutPage = new com.ibm.ivj.examples.vc.layoutmanagers.FlowLayoutPage();
		frame.add("Center", aFlowLayoutPage);
		frame.setSize(aFlowLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in Visual Age for Java.
 * @return int
 */	
public int showMessageBox() {

	Object[] options = {"Yes", "No","Delete'em All"};
	javax.swing.Icon icon = null;
	Object message = "Do you really want to delete the selected item?";
	Object selectedOption = options[1];
	
	return javax.swing.JOptionPane.showOptionDialog(this,message,"Title",0,3,icon,options, selectedOption);
	}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,16"
