package com.ibm.ivj.examples.vc.swing.bookmarklist;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import java.applet.*;
import java.awt.*;
/**
 * This type was created in VisualAge.
 */
public class BookmarkList extends javax.swing.JApplet implements javax.swing.event.ListSelectionListener {
	private javax.swing.JButton ivjAddButton = null;
	private AppletContext ivjappletContext1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="86,431"
	private javax.swing.DefaultListModel ivjDefaultListModel1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="414,90"
	private javax.swing.JButton ivjDeleteButton = null;
	private javax.swing.JPanel ivjJAppletContentPane = null;
	private BorderLayout ivjJAppletContentPaneBorderLayout = null;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JPanel ivjJPanel1 = null;
	private GridLayout ivjJPanel1GridLayout = null;
	private javax.swing.JPanel ivjJPanel2 = null;
	private GridLayout ivjJPanel2GridLayout = null;
	private javax.swing.JScrollPane ivjJScrollPane1 = null;
	private javax.swing.JButton ivjLinkButton = null;
	private javax.swing.JTextField ivjURLEntry = null;
	private javax.swing.JList ivjURLList = null;

class IvjEventHandler implements java.awt.event.ActionListener, java.awt.event.KeyListener, javax.swing.event.ListDataListener, javax.swing.event.ListSelectionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == BookmarkList.this.getAddButton()) 
				connEtoM1(e);
			if (e.getSource() == BookmarkList.this.getDeleteButton()) 
				connEtoM2(e);
			if (e.getSource() == BookmarkList.this.getLinkButton()) 
				connEtoM3(e);
			if (e.getSource() == BookmarkList.this.getURLEntry()) 
				connEtoM4(e);
		};
		public void contentsChanged(javax.swing.event.ListDataEvent e) {};
		public void intervalAdded(javax.swing.event.ListDataEvent e) {
			if (e.getSource() == BookmarkList.this.getDefaultListModel1()) 
				connEtoC3(e);
		};
		public void intervalRemoved(javax.swing.event.ListDataEvent e) {
			if (e.getSource() == BookmarkList.this.getDefaultListModel1()) 
				connEtoC4(e);
		};
		public void keyPressed(java.awt.event.KeyEvent e) {};
		public void keyReleased(java.awt.event.KeyEvent e) {
			if (e.getSource() == BookmarkList.this.getURLEntry()) 
				connEtoC1(e);
		};
		public void keyTyped(java.awt.event.KeyEvent e) {};
		public void valueChanged(javax.swing.event.ListSelectionEvent e) {
			if (e.getSource() == BookmarkList.this.getURLList()) 
				connEtoC2(e);
		};
	};
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
/**
 * connEtoC1:  (URLEntry.key.keyReleased(java.awt.event.KeyEvent) --> BookmarkList.setAddButtonState()V)
 * @param arg1 java.awt.event.KeyEvent
 */
private void connEtoC1(java.awt.event.KeyEvent arg1) {
	try {
		this.setAddButtonState();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (URLList.listSelection.valueChanged(javax.swing.event.ListSelectionEvent) --> BookmarkList.handleListSelection()V)
 * @param arg1 javax.swing.event.ListSelectionEvent
 */
private void connEtoC2(javax.swing.event.ListSelectionEvent arg1) {
	try {
		this.handleListSelection();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (DefaultListModel1.listData.intervalAdded(javax.swing.event.ListDataEvent) --> BookmarkList.selectAddedElement()V)
 * @param arg1 javax.swing.event.ListDataEvent
 */
private void connEtoC3(javax.swing.event.ListDataEvent arg1) {
	try {
		this.selectAddedElement();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (DefaultListModel1.listData.intervalRemoved(javax.swing.event.ListDataEvent) --> BookmarkList.handleListSelection()V)
 * @param arg1 javax.swing.event.ListDataEvent
 */
private void connEtoC4(javax.swing.event.ListDataEvent arg1) {
	try {
		this.handleListSelection();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (AddButton.action.actionPerformed(java.awt.event.ActionEvent) --> DefaultListModel1.addElement(Ljava.lang.Object;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		getDefaultListModel1().addElement(getURLEntry().getText());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (DeleteButton.action.actionPerformed(java.awt.event.ActionEvent) --> DefaultListModel1.removeElementAt(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		getDefaultListModel1().removeElementAt(getURLList().getSelectedIndex());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (LinkButton.action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1.showDocument(Ljava.net.URL;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		getappletContext1().showDocument(this.getUrlFromString((String)getURLList().getSelectedValue()));
	} catch (java.lang.Throwable ivjExc) {
		connEtoM5(ivjExc);
	}
}
/**
 * connEtoM4:  (URLEntry.action.actionPerformed(java.awt.event.ActionEvent) --> DefaultListModel1.addElement(Ljava.lang.Object;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		getDefaultListModel1().addElement(getURLEntry().getText());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  ( (LinkButton,action.actionPerformed(java.awt.event.ActionEvent) --> appletContext1,showDocument(Ljava.net.URL;)V).exceptionOccurred --> appletContext1.showStatus(Ljava.lang.String;)V)
 * @param exception java.lang.Throwable
 */
private void connEtoM5(java.lang.Throwable exception) {
	try {
		getappletContext1().showStatus(String.valueOf(exception));
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (BookmarkList.appletContext <--> appletContext1.this)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		setappletContext1(this.getAppletContext());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (DefaultListModel1.this <--> URLList.model)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		getURLList().setModel(getDefaultListModel1());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Method to handle events for the ListDataListener interface.
 * @param e javax.swing.event.ListDataEvent
 */
public void contentsChanged(javax.swing.event.ListDataEvent e) {
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getAddButton() {
	if (ivjAddButton == null) {
		try {
			ivjAddButton = new javax.swing.JButton();
			ivjAddButton.setName("AddButton");
			ivjAddButton.setText("Add URL to list");
			ivjAddButton.setEnabled(false);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjAddButton;
}
/**
 * Return the appletContext1 property value.
 * @return java.applet.AppletContext
 */
private java.applet.AppletContext getappletContext1() {
	return ivjappletContext1;
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.swing.bookmarklist.BookmarkList created using VisualAge for Java.";
}
/**
 * Return the DefaultListModel1 property value.
 * @return javax.swing.DefaultListModel
 */
private javax.swing.DefaultListModel getDefaultListModel1() {
	if (ivjDefaultListModel1 == null) {
		try {
			ivjDefaultListModel1 = new javax.swing.DefaultListModel();
			initializeListModel (ivjDefaultListModel1);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjDefaultListModel1;
}
/**
 * Return the JButton2 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getDeleteButton() {
	if (ivjDeleteButton == null) {
		try {
			ivjDeleteButton = new javax.swing.JButton();
			ivjDeleteButton.setName("DeleteButton");
			ivjDeleteButton.setText("Delete URL");
			ivjDeleteButton.setEnabled(false);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjDeleteButton;
}
/**
 * Return the JAppletContentPane property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJAppletContentPane() {
	if (ivjJAppletContentPane == null) {
		try {
			ivjJAppletContentPane = new javax.swing.JPanel();
			ivjJAppletContentPane.setName("JAppletContentPane");
			ivjJAppletContentPane.setLayout(getJAppletContentPaneBorderLayout());
			ivjJAppletContentPane.setBackground(java.awt.Color.lightGray);
			getJAppletContentPane().add(getJPanel1(), "North");
			getJAppletContentPane().add(getJPanel2(), "East");
			getJAppletContentPane().add(getJScrollPane1(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJAppletContentPane;
}
/**
 * Return the JAppletContentPaneBorderLayout property value.
 * @return java.awt.BorderLayout
 */
private java.awt.BorderLayout getJAppletContentPaneBorderLayout() {
	java.awt.BorderLayout ivjJAppletContentPaneBorderLayout = null;
	try {
		/* Create part */
		ivjJAppletContentPaneBorderLayout = new java.awt.BorderLayout();
		ivjJAppletContentPaneBorderLayout.setVgap(15);
		ivjJAppletContentPaneBorderLayout.setHgap(15);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJAppletContentPaneBorderLayout;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("Enter a URL:");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JPanel1 property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJPanel1() {
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new javax.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(getJPanel1GridLayout());
			getJPanel1().add(getJLabel1(), getJLabel1().getName());
			getJPanel1().add(getURLEntry(), getURLEntry().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPanel1;
}
/**
 * Return the JPanel1GridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getJPanel1GridLayout() {
	java.awt.GridLayout ivjJPanel1GridLayout = null;
	try {
		/* Create part */
		ivjJPanel1GridLayout = new java.awt.GridLayout(2, 1);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel1GridLayout;
}
/**
 * Return the JPanel2 property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJPanel2() {
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new javax.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(getJPanel2GridLayout());
			getJPanel2().add(getAddButton(), getAddButton().getName());
			getJPanel2().add(getDeleteButton(), getDeleteButton().getName());
			getJPanel2().add(getLinkButton(), getLinkButton().getName());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJPanel2;
}
/**
 * Return the JPanel2GridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getJPanel2GridLayout() {
	java.awt.GridLayout ivjJPanel2GridLayout = null;
	try {
		/* Create part */
		ivjJPanel2GridLayout = new java.awt.GridLayout(3, 1);
		ivjJPanel2GridLayout.setVgap(10);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel2GridLayout;
}
/**
 * Return the JScrollPane1 property value.
 * @return javax.swing.JScrollPane
 */
private javax.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new javax.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			getJScrollPane1().setViewportView(getURLList());
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJScrollPane1;
}
/**
 * Return the JButton3 property value.
 * @return javax.swing.JButton
 */
private javax.swing.JButton getLinkButton() {
	if (ivjLinkButton == null) {
		try {
			ivjLinkButton = new javax.swing.JButton();
			ivjLinkButton.setName("LinkButton");
			ivjLinkButton.setText("Link to URL");
			ivjLinkButton.setEnabled(false);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLinkButton;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
private javax.swing.JTextField getURLEntry() {
	if (ivjURLEntry == null) {
		try {
			ivjURLEntry = new javax.swing.JTextField();
			ivjURLEntry.setName("URLEntry");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjURLEntry;
}
/**
 * Insert the method's description here.
 * Creation date: (8/18/99 10:07:31 AM)
 * @return java.net.URL
 * @param Str java.lang.String
 */
public java.net.URL getUrlFromString(String Str) {
	java.net.URL url = null;
	try {
		url = new java.net.URL(Str);
	} catch (Throwable e) {
		handleException(e); }
	return url;
}
/**
 * Return the JList1 property value.
 * @return javax.swing.JList
 */
private javax.swing.JList getURLList() {
	if (ivjURLList == null) {
		try {
			ivjURLList = new javax.swing.JList();
			ivjURLList.setName("URLList");
			ivjURLList.setBounds(0, 0, 160, 120);
			ivjURLList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjURLList;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	exception.printStackTrace(System.out);
}
/**
 * When the list selection for URLList changes, this method:
 *    1. appropriately enables/disables DeleteButton and LinkButton
 *    2. primes URLEntry with the selected item, if any
 *    3. clears the status area of the browser
 */
protected void handleListSelection() {
	boolean isSelection = !getURLList().isSelectionEmpty();

	getDeleteButton().setEnabled(isSelection);
	getLinkButton().setEnabled(isSelection);

	if (isSelection) {
		// prime URLEntry with the item that's selected in URLList
		getURLEntry().setText(String.valueOf(getURLList().getSelectedValue()));
		getAddButton().setEnabled(false);
	}	
	else {
		// clear URLEntry and disable AddButton
		getURLEntry().setText("");
		getAddButton().setEnabled(false);	
	}
	
	getAppletContext().showStatus("");
	
	return;
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		setName("BookmarkList");
		setSize(325, 318);
		setContentPane(getJAppletContentPane());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getAddButton().addActionListener(ivjEventHandler);
	getDeleteButton().addActionListener(ivjEventHandler);
	getLinkButton().addActionListener(ivjEventHandler);
	getURLEntry().addActionListener(ivjEventHandler);
	getURLEntry().addKeyListener(ivjEventHandler);
	getURLList().addListSelectionListener(ivjEventHandler);
	getDefaultListModel1().addListDataListener(ivjEventHandler);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
}
/**
 * This method was created in VisualAge.
 * @param listModel javax.swing.DefaultListModel
 */
protected static void initializeListModel(javax.swing.DefaultListModel listModel) {
	listModel.addElement("http://www.software.ibm.com/ad/vajava");
	listModel.addElement("http://www.ibm.com");
}
/**
 * Method to handle events for the ListDataListener interface.
 * @param e javax.swing.event.ListDataEvent
 */
public void intervalAdded(javax.swing.event.ListDataEvent e) {
	if (e.getSource() == getDefaultListModel1()) 
		connEtoC3(e);
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.swing.bookmarklist.BookmarkList aBookmarkList;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.swing.bookmarklist.BookmarkList");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aBookmarkList = (com.ibm.ivj.examples.vc.swing.bookmarklist.BookmarkList)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.swing.bookmarklist.BookmarkList");
		frame.add("Center", aBookmarkList);
		frame.setSize(aBookmarkList.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JApplet");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method selects the element just added to the 
 * list (as the last element).
 */
protected void selectAddedElement() {
	getURLList().setSelectedIndex(getDefaultListModel1().size()-1);
	return;
}
/**
 * This method appropriately enables/disables AddButton
 * and clears the status area of the browser.
 */
protected void setAddButtonState() {
	// appropriately enable/disable AddButton based on
	// whether any text is in URLEntry
	if (getURLEntry().getText().equals(""))
		getAddButton().setEnabled(false);
	else
		getAddButton().setEnabled(true);

	// clear the status area of the browser
	getAppletContext().showStatus("");
	return;
}
/**
 * Set the appletContext1 to a new value.
 * @param newValue java.applet.AppletContext
 */
private void setappletContext1(java.applet.AppletContext newValue) {
	if (ivjappletContext1 != newValue) {
		try {
			ivjappletContext1 = newValue;
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method to handle events for the ListSelectionListener interface.
 * @param e javax.swing.event.ListSelectionEvent
 */
public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	if (e.getSource() == getURLList()) 
		connEtoC2(e);
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
