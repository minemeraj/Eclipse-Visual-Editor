package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class GridBagBean implements java.lang.Cloneable {
	private String fieldGridHeight = "";
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private String fieldGridWidth = "";
	private String fieldGridX = "";
	private String fieldGridY = "";
	private String fieldInsetsBottom = "";
	private String fieldInsetsLeft = "";
	private String fieldInsetsRight = "";
	private String fieldInsetsTop = "";
	private String fieldIpadX = "";
	private String fieldIpadY = "";
	private String fieldWeightX = "";
	private String fieldWeightY = "";
	private int fieldAnchor = 0;
	private int fieldFill = 0;	
	private int fieldAnchorAsChoice = 0;
	private int fieldFillAsChoice = 0;
	private int fieldAnchorFromChoice = 0;
	private int fieldFillFromChoice = 0;
	private java.awt.GridBagConstraints fieldGridBagConstraints = null;
/**
 * GridBagBean constructor comment.
 */
public GridBagBean() {
	super();
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 */
public java.lang.Object clone() {
	return null;
}
/**
 * Compares two objects for equality. Returns a boolean that indicates
 * whether this object is equivalent to the specified object. This method
 * is used when an object is stored in a hashtable.
 * @param obj the Object to compare with
 * @return true if these Objects are equal; false otherwise.
 * @see java.util.Hashtable
 */
public boolean equals(Object obj) {
	// Insert code to compare the receiver and obj here.
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: obj might be an instance of any class
	return super.equals(obj);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the anchor property (int) value.
 * @return The anchor property value.
 * @see #setAnchor
 */
public int getAnchor() {
	return fieldAnchor;
}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public int getAnchorAsChoice() {
	int[] choice = {0,0,0,0,0,0,0,0,0,0,0,2,3,1,6,5,7,8,4};
	return choice[getAnchor()];
}
/**
 * Gets the fill property (int) value.
 * @return The fill property value.
 * @see #setFill
 */
public int getFill() {
	return fieldFill;
}
/**
 * This method was created by a SmartGuide.
 * @return int
 */
public int getFillAsChoice() {
	int[] choice = {2, 0, 1, 3};
	return choice[getFill()];
}
/**
 * Gets the gridBagConstraints property (java.awt.GridBagConstraints) value.
 * @return The gridBagConstraints property value.
 * @see #setGridBagConstraints
 */
public java.awt.GridBagConstraints getGridBagConstraints() {
	/* Returns the gridBagConstraints property value. */
	if (fieldGridBagConstraints == null) {
		try {
			fieldGridBagConstraints = new java.awt.GridBagConstraints();
		} catch (Throwable exception) {
			System.err.println("Exception creating gridBagConstraints property.");
		}
	};
	fieldGridBagConstraints.anchor = getAnchor();
	fieldGridBagConstraints.fill = getFill();
	fieldGridBagConstraints.gridheight = Integer.parseInt(getGridHeight());
	fieldGridBagConstraints.gridwidth = Integer.parseInt(getGridWidth());
	fieldGridBagConstraints.gridx = Integer.parseInt(getGridX());
	fieldGridBagConstraints.gridy = Integer.parseInt(getGridY());
	fieldGridBagConstraints.insets.top = Integer.parseInt(getInsetsTop());
	fieldGridBagConstraints.insets.left = Integer.parseInt(getInsetsLeft());
	fieldGridBagConstraints.insets.right = Integer.parseInt(getInsetsRight());
	fieldGridBagConstraints.insets.bottom = Integer.parseInt(getInsetsBottom());
	fieldGridBagConstraints.ipadx = Integer.parseInt(getIpadX());
	fieldGridBagConstraints.ipady = Integer.parseInt(getIpadY());
	fieldGridBagConstraints.weightx = Double.valueOf(getWeightX()).doubleValue();
	fieldGridBagConstraints.weighty = Double.valueOf(getWeightY()).doubleValue();
	return fieldGridBagConstraints;
}
/**
 * Gets the gridHeight property (java.lang.String) value.
 * @return The gridHeight property value.
 * @see #setGridHeight
 */
public String getGridHeight() {
	return fieldGridHeight;
}
/**
 * Gets the gridWidth property (java.lang.String) value.
 * @return The gridWidth property value.
 * @see #setGridWidth
 */
public String getGridWidth() {
	return fieldGridWidth;
}
/**
 * Gets the gridX property (java.lang.String) value.
 * @return The gridX property value.
 * @see #setGridX
 */
public String getGridX() {
	return fieldGridX;
}
/**
 * Gets the gridY property (java.lang.String) value.
 * @return The gridY property value.
 * @see #setGridY
 */
public String getGridY() {
	return fieldGridY;
}
/**
 * Gets the insetsBottom property (java.lang.String) value.
 * @return The insetsBottom property value.
 * @see #setInsetsBottom
 */
public String getInsetsBottom() {
	return fieldInsetsBottom;
}
/**
 * Gets the insetsLeft property (java.lang.String) value.
 * @return The insetsLeft property value.
 * @see #setInsetsLeft
 */
public String getInsetsLeft() {
	return fieldInsetsLeft;
}
/**
 * Gets the insetsRight property (java.lang.String) value.
 * @return The insetsRight property value.
 * @see #setInsetsRight
 */
public String getInsetsRight() {
	return fieldInsetsRight;
}
/**
 * Gets the insetsTop property (java.lang.String) value.
 * @return The insetsTop property value.
 * @see #setInsetsTop
 */
public String getInsetsTop() {
	return fieldInsetsTop;
}
/**
 * Gets the ipadX property (java.lang.String) value.
 * @return The ipadX property value.
 * @see #setIpadX
 */
public String getIpadX() {
	return fieldIpadX;
}
/**
 * Gets the ipadY property (java.lang.String) value.
 * @return The ipadY property value.
 * @see #setIpadY
 */
public String getIpadY() {
	return fieldIpadY;
}
/**
 * Accessor for the propertyChange field.
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Gets the weightX property (java.lang.String) value.
 * @return The weightX property value.
 * @see #setWeightX
 */
public String getWeightX() {
	return fieldWeightX;
}
/**
 * Gets the weightY property (java.lang.String) value.
 * @return The weightY property value.
 * @see #setWeightY
 */
public String getWeightY() {
	return fieldWeightY;
}
/**
 * Generates a hash code for the receiver.
 * This method is supported primarily for
 * hash tables, such as those provided in java.util.
 * @return an integer hash code for the receiver
 * @see java.util.Hashtable
 */
public int hashCode() {
	// Insert code to generate a hash code for the receiver here.
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: if two objects are equal (equals(Object) returns true) they must have the same hash code
	return super.hashCode();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Sets the anchor property (int) value.
 * @param anchor The new value for the property.
 * @see #getAnchor
 */
public void setAnchor(int anchor) {
	int oldValue = fieldAnchor;
	fieldAnchor = anchor;
	firePropertyChange("anchor", new Integer(oldValue), new Integer(anchor));
}
/**
 * This method was created by a SmartGuide.
 * @param choice int
 */
public void setAnchorFromChoice(int choice) {
	int[] anchor = {10, 13, 11, 12, 18, 15, 14, 16, 17};
	setAnchor(anchor[choice]);	
	return;
}
/**
 * Sets the fill property (int) value.
 * @param fill The new value for the property.
 * @see #getFill
 */
public void setFill(int fill) {
	int oldValue = fieldFill;
	fieldFill = fill;
	firePropertyChange("fill", new Integer(oldValue), new Integer(fill));
}
/**
 * This method was created by a SmartGuide.
 * @param choice int
 */
public void setFillFromChoice(int choice) {
	int[] fill = {1, 2, 0, 3};
	setFill(fill[choice]);
}
/**
 * Sets the gridBagConstraints property (java.awt.GridBagConstraints) value.
 * @param gridBagConstraints The new value for the property.
 * @see #getGridBagConstraints
 */
public void setGridBagConstraints(java.awt.GridBagConstraints gridBagConstraints) {
	/* Get the old property value for fire property change event. */
	java.awt.GridBagConstraints oldValue = fieldGridBagConstraints;
	/* Set the gridBagConstraints property (attribute) to the new value. */
	fieldGridBagConstraints = gridBagConstraints;
	/* Fire (signal/notify) the gridBagConstraints property change event. */
	firePropertyChange("gridBagConstraints", oldValue, gridBagConstraints);

	setAnchor(gridBagConstraints.anchor);
	setFill(gridBagConstraints.fill);
	setGridHeight(String.valueOf(gridBagConstraints.gridheight));
	setGridWidth(String.valueOf(gridBagConstraints.gridwidth));
	setGridX(String.valueOf(gridBagConstraints.gridx));
	setGridY(String.valueOf(gridBagConstraints.gridy));
	setInsetsTop(String.valueOf(gridBagConstraints.insets.top));
	setInsetsLeft(String.valueOf(gridBagConstraints.insets.left));
	setInsetsRight(String.valueOf(gridBagConstraints.insets.right));
	setInsetsBottom(String.valueOf(gridBagConstraints.insets.bottom));
	setIpadX(String.valueOf(gridBagConstraints.ipadx));
	setIpadY(String.valueOf(gridBagConstraints.ipady));
	setWeightX(String.valueOf(gridBagConstraints.weightx));
	setWeightY(String.valueOf(gridBagConstraints.weighty));
	return;
}
/**
 * Sets the gridHeight property (java.lang.String) value.
 * @param gridHeight The new value for the property.
 * @see #getGridHeight
 */
public void setGridHeight(String gridHeight) {
	String oldValue = fieldGridHeight;
	fieldGridHeight = gridHeight;
	firePropertyChange("gridHeight", oldValue, gridHeight);
}
/**
 * Sets the gridWidth property (java.lang.String) value.
 * @param gridWidth The new value for the property.
 * @see #getGridWidth
 */
public void setGridWidth(String gridWidth) {
	String oldValue = fieldGridWidth;
	fieldGridWidth = gridWidth;
	firePropertyChange("gridWidth", oldValue, gridWidth);
}
/**
 * Sets the gridX property (java.lang.String) value.
 * @param gridX The new value for the property.
 * @see #getGridX
 */
public void setGridX(String gridX) {
	String oldValue = fieldGridX;
	fieldGridX = gridX;
	firePropertyChange("gridX", oldValue, gridX);
}
/**
 * Sets the gridY property (java.lang.String) value.
 * @param gridY The new value for the property.
 * @see #getGridY
 */
public void setGridY(String gridY) {
	String oldValue = fieldGridY;
	fieldGridY = gridY;
	firePropertyChange("gridY", oldValue, gridY);
}
/**
 * Sets the insetsBottom property (java.lang.String) value.
 * @param insetsBottom The new value for the property.
 * @see #getInsetsBottom
 */
public void setInsetsBottom(String insetsBottom) {
	String oldValue = fieldInsetsBottom;
	fieldInsetsBottom = insetsBottom;
	firePropertyChange("insetsBottom", oldValue, insetsBottom);
}
/**
 * Sets the insetsLeft property (java.lang.String) value.
 * @param insetsLeft The new value for the property.
 * @see #getInsetsLeft
 */
public void setInsetsLeft(String insetsLeft) {
	String oldValue = fieldInsetsLeft;
	fieldInsetsLeft = insetsLeft;
	firePropertyChange("insetsLeft", oldValue, insetsLeft);
}
/**
 * Sets the insetsRight property (java.lang.String) value.
 * @param insetsRight The new value for the property.
 * @see #getInsetsRight
 */
public void setInsetsRight(String insetsRight) {
	String oldValue = fieldInsetsRight;
	fieldInsetsRight = insetsRight;
	firePropertyChange("insetsRight", oldValue, insetsRight);
}
/**
 * Sets the insetsTop property (java.lang.String) value.
 * @param insetsTop The new value for the property.
 * @see #getInsetsTop
 */
public void setInsetsTop(String insetsTop) {
	String oldValue = fieldInsetsTop;
	fieldInsetsTop = insetsTop;
	firePropertyChange("insetsTop", oldValue, insetsTop);
}
/**
 * Sets the ipadX property (java.lang.String) value.
 * @param ipadX The new value for the property.
 * @see #getIpadX
 */
public void setIpadX(String ipadX) {
	String oldValue = fieldIpadX;
	fieldIpadX = ipadX;
	firePropertyChange("ipadX", oldValue, ipadX);
}
/**
 * Sets the ipadY property (java.lang.String) value.
 * @param ipadY The new value for the property.
 * @see #getIpadY
 */
public void setIpadY(String ipadY) {
	String oldValue = fieldIpadY;
	fieldIpadY = ipadY;
	firePropertyChange("ipadY", oldValue, ipadY);
}
/**
 * Sets the weightX property (java.lang.String) value.
 * @param weightX The new value for the property.
 * @see #getWeightX
 */
public void setWeightX(String weightX) {
	String oldValue = fieldWeightX;
	fieldWeightX = weightX;
	firePropertyChange("weightX", oldValue, weightX);
}
/**
 * Sets the weightY property (java.lang.String) value.
 * @param weightY The new value for the property.
 * @see #getWeightY
 */
public void setWeightY(String weightY) {
	String oldValue = fieldWeightY;
	fieldWeightY = weightY;
	firePropertyChange("weightY", oldValue, weightY);
}
/**
 * Returns a String that represents the value of this object.
 * @return a string representation of the receiver
 */
public String toString() {
	// Insert code to print the receiver here.
	// This implementation forwards the message to super. You may replace or supplement this.
	return super.toString();
}
}
