package com.ibm.ivj.examples.vc.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class GridLayoutPage extends java.awt.Panel implements java.awt.event.ComponentListener {
	private java.awt.GridLayout ivjGridLayoutPageGridLayout = null;
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.Label ivjLabel5 = null;
	private java.awt.TextArea ivjTextArea1 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
/**
 * Constructor
 */
public GridLayoutPage() {
	super();
	initialize();
}
/**
 * GridLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public GridLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentHidden(java.awt.event.ComponentEvent e) {
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentMoved(java.awt.event.ComponentEvent e) {
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentResized(java.awt.event.ComponentEvent e) {
	if (e.getSource() == getLabel1()) 
		connEtoM1(e);
	if (e.getSource() == getLabel2()) 
		connEtoM2(e);
	if (e.getSource() == getLabel3()) 
		connEtoM3(e);
	if (e.getSource() == getLabel4()) 
		connEtoM4(e);
	if (e.getSource() == getLabel5()) 
		connEtoM5(e);
}
/**
 * Method to handle events for the ComponentListener interface.
 * @param e java.awt.event.ComponentEvent
 */
public void componentShown(java.awt.event.ComponentEvent e) {
}
/**
 * connEtoM1:  (Label1.component.componentResized(java.awt.event.ComponentEvent) --> Label1.repaint()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM1(java.awt.event.ComponentEvent arg1) {
	try {
		getLabel1().repaint();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (Label2.component.componentResized(java.awt.event.ComponentEvent) --> Label2.repaint()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM2(java.awt.event.ComponentEvent arg1) {
	try {
		getLabel2().repaint();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (Label3.component.componentResized(java.awt.event.ComponentEvent) --> Label3.repaint()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM3(java.awt.event.ComponentEvent arg1) {
	try {
		getLabel3().repaint();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (Label4.component.componentResized(java.awt.event.ComponentEvent) --> Label4.repaint()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM4(java.awt.event.ComponentEvent arg1) {
	try {
		getLabel4().repaint();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (Label5.component.componentResized(java.awt.event.ComponentEvent) --> Label5.repaint()V)
 * @param arg1 java.awt.event.ComponentEvent
 */
private void connEtoM5(java.awt.event.ComponentEvent arg1) {
	try {
		getLabel5().repaint();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * Return the GridLayoutPageGridLayout property value.
 * @return java.awt.GridLayout
 */
private java.awt.GridLayout getGridLayoutPageGridLayout() {
	java.awt.GridLayout ivjGridLayoutPageGridLayout = null;
	try {
		/* Create part */
		ivjGridLayoutPageGridLayout = new java.awt.GridLayout(5, 2);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjGridLayoutPageGridLayout;
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setAlignment(java.awt.Label.RIGHT);
			ivjLabel1.setText("All nine of these components ");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("will be sized the same.");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setAlignment(java.awt.Label.CENTER);
			ivjLabel3.setText("Name");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setAlignment(java.awt.Label.CENTER);
			ivjLabel4.setText("Rank");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Return the Label5 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel5() {
	if (ivjLabel5 == null) {
		try {
			ivjLabel5 = new java.awt.Label();
			ivjLabel5.setName("Label5");
			ivjLabel5.setAlignment(java.awt.Label.CENTER);
			ivjLabel5.setText("Serial#");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel5;
}
/**
 * Return the TextArea1 property value.
 * @return java.awt.TextArea
 */
private java.awt.TextArea getTextArea1() {
	if (ivjTextArea1 == null) {
		try {
			ivjTextArea1 = new java.awt.TextArea();
			ivjTextArea1.setName("TextArea1");
			ivjTextArea1.setText("This is a GridLayout.\nThis layout manager arranges components in row-column order where all components are sized the same.\n\nTry resizing now.\nThis layout manager is best used to layout components of the same type, like a set of buttons.\n");
			ivjTextArea1.setBackground(java.awt.Color.white);
			ivjTextArea1.setColumns(0);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextArea1;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
			ivjTextField1.setBackground(new java.awt.Color(230,230,230));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
			ivjTextField2.setBackground(new java.awt.Color(230,230,230));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setBackground(new java.awt.Color(230,230,230));
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getLabel1().addComponentListener(this);
	getLabel2().addComponentListener(this);
	getLabel3().addComponentListener(this);
	getLabel4().addComponentListener(this);
	getLabel5().addComponentListener(this);
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("GridLayoutPage");
		setLayout(getGridLayoutPageGridLayout());
		setBackground(java.awt.Color.red);
		setSize(600, 300);
		add(getLabel1());
		add(getLabel2(), getLabel2().getName());
		add(getLabel3(), getLabel3().getName());
		add(getTextField1(), getTextField1().getName());
		add(getLabel4(), getLabel4().getName());
		add(getTextField2(), getTextField2().getName());
		add(getLabel5(), getLabel5().getName());
		add(getTextField3(), getTextField3().getName());
		add(getTextArea1(), getTextArea1().getName());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.layoutmanagers.GridLayoutPage aGridLayoutPage;
		aGridLayoutPage = new com.ibm.ivj.examples.vc.layoutmanagers.GridLayoutPage();
		frame.add("Center", aGridLayoutPage);
		frame.setSize(aGridLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
