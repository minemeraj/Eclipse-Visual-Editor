package com.ibm.ivj.examples.vc.swing.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class LayoutManagers extends javax.swing.JApplet {
	private BorderLayoutPage ivjBorderLayoutPage1 = null;
	private CardLayoutPage ivjCardLayoutPage1 = null;
	private FlowLayoutPage ivjFlowLayoutPage1 = null;
	private GridBagLayoutPage ivjGridBagLayoutPage1 = null;
	private GridLayoutPage ivjGridLayoutPage1 = null;
	private HorizontalBoxLayoutPage ivjHorizontalBoxLayoutPage1 = null;
	private javax.swing.JPanel ivjJAppletContentPane = null;
	private javax.swing.JTabbedPane ivjJTabbedPane1 = null;
	private javax.swing.JTabbedPane ivjJTabbedPane2 = null;
	private NullLayoutPage ivjNullLayoutPage1 = null;
	private VerticalBoxLayoutPage ivjVerticalBoxLayoutPage1 = null;
	private XAlignmentBoxLayoutPage ivjXAlignmentBoxLayoutPage1 = null;
/**
 * LayoutManagers constructor comment.
 */
public LayoutManagers() {
	super();
}
/**
 * Gets the applet information.
 * @return java.lang.String
 */
public String getAppletInfo() {
	return "com.ibm.ivj.examples.vc.swing.layoutmanagers.LayoutManagers created using VisualAge for Java.";
}
/**
 * Return the BorderLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.BorderLayoutPage
 */
private BorderLayoutPage getBorderLayoutPage1() {
	if (ivjBorderLayoutPage1 == null) {
		try {
			ivjBorderLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.BorderLayoutPage();
			ivjBorderLayoutPage1.setName("BorderLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjBorderLayoutPage1;
}
/**
 * Return the CardLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.CardLayoutPage
 */
private CardLayoutPage getCardLayoutPage1() {
	if (ivjCardLayoutPage1 == null) {
		try {
			ivjCardLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.CardLayoutPage();
			ivjCardLayoutPage1.setName("CardLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjCardLayoutPage1;
}
/**
 * Return the FlowLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.FlowLayoutPage
 */
private FlowLayoutPage getFlowLayoutPage1() {
	if (ivjFlowLayoutPage1 == null) {
		try {
			ivjFlowLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.FlowLayoutPage();
			ivjFlowLayoutPage1.setName("FlowLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjFlowLayoutPage1;
}
/**
 * Return the GridBagLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.GridBagLayoutPage
 */
private GridBagLayoutPage getGridBagLayoutPage1() {
	if (ivjGridBagLayoutPage1 == null) {
		try {
			ivjGridBagLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.GridBagLayoutPage();
			ivjGridBagLayoutPage1.setName("GridBagLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGridBagLayoutPage1;
}
/**
 * Return the GridLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.GridLayoutPage
 */
private GridLayoutPage getGridLayoutPage1() {
	if (ivjGridLayoutPage1 == null) {
		try {
			ivjGridLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.GridLayoutPage();
			ivjGridLayoutPage1.setName("GridLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjGridLayoutPage1;
}
/**
 * Return the HorizontalBoxLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.HorizontalBoxLayoutPage
 */
private HorizontalBoxLayoutPage getHorizontalBoxLayoutPage1() {
	if (ivjHorizontalBoxLayoutPage1 == null) {
		try {
			ivjHorizontalBoxLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.HorizontalBoxLayoutPage();
			ivjHorizontalBoxLayoutPage1.setName("HorizontalBoxLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjHorizontalBoxLayoutPage1;
}
/**
 * Return the JAppletContentPane property value.
 * @return javax.swing.JPanel
 */
private javax.swing.JPanel getJAppletContentPane() {
	if (ivjJAppletContentPane == null) {
		try {
			ivjJAppletContentPane = new javax.swing.JPanel();
			ivjJAppletContentPane.setName("JAppletContentPane");
			ivjJAppletContentPane.setLayout(new java.awt.BorderLayout());
			getJAppletContentPane().add(getJTabbedPane1(), "Center");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJAppletContentPane;
}
/**
 * Return the JTabbedPane1 property value.
 * @return javax.swing.JTabbedPane
 */
private javax.swing.JTabbedPane getJTabbedPane1() {
	if (ivjJTabbedPane1 == null) {
		try {
			ivjJTabbedPane1 = new javax.swing.JTabbedPane();
			ivjJTabbedPane1.setName("JTabbedPane1");
			ivjJTabbedPane1.insertTab("LayoutManagers", null, getNullLayoutPage1(), null, 0);
			ivjJTabbedPane1.insertTab("FlowLayout", null, getFlowLayoutPage1(), null, 1);
			ivjJTabbedPane1.insertTab("CardLayout", null, getCardLayoutPage1(), null, 2);
			ivjJTabbedPane1.insertTab("BorderLayout", null, getBorderLayoutPage1(), null, 3);
			ivjJTabbedPane1.insertTab("BoxLayout", null, getJTabbedPane2(), null, 4);
			ivjJTabbedPane1.insertTab("GridLayout", null, getGridLayoutPage1(), null, 5);
			ivjJTabbedPane1.insertTab("GridBagLayout", null, getGridBagLayoutPage1(), null, 6);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTabbedPane1;
}
/**
 * Return the JTabbedPane2 property value.
 * @return javax.swing.JTabbedPane
 */
private javax.swing.JTabbedPane getJTabbedPane2() {
	if (ivjJTabbedPane2 == null) {
		try {
			ivjJTabbedPane2 = new javax.swing.JTabbedPane();
			ivjJTabbedPane2.setName("JTabbedPane2");
			ivjJTabbedPane2.setTabPlacement(javax.swing.JTabbedPane.RIGHT);
			ivjJTabbedPane2.insertTab("HorizontalArrangement", null, getHorizontalBoxLayoutPage1(), null, 0);
			ivjJTabbedPane2.insertTab("VerticalArrangement", null, getVerticalBoxLayoutPage1(), null, 1);
			ivjJTabbedPane2.insertTab("XAlignment", null, getXAlignmentBoxLayoutPage1(), null, 2);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjJTabbedPane2;
}
/**
 * Return the NullLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.NullLayoutPage
 */
private NullLayoutPage getNullLayoutPage1() {
	if (ivjNullLayoutPage1 == null) {
		try {
			ivjNullLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.NullLayoutPage();
			ivjNullLayoutPage1.setName("NullLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjNullLayoutPage1;
}
/**
 * Return the VerticalBoxLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.VerticalBoxLayoutPage
 */
private VerticalBoxLayoutPage getVerticalBoxLayoutPage1() {
	if (ivjVerticalBoxLayoutPage1 == null) {
		try {
			ivjVerticalBoxLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.VerticalBoxLayoutPage();
			ivjVerticalBoxLayoutPage1.setName("VerticalBoxLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjVerticalBoxLayoutPage1;
}
/**
 * Return the XAlignmentBoxLayoutPage1 property value.
 * @return com.ibm.ivj.examples.vc.swing.layoutmanagers.XAlignmentBoxLayoutPage
 */
private XAlignmentBoxLayoutPage getXAlignmentBoxLayoutPage1() {
	if (ivjXAlignmentBoxLayoutPage1 == null) {
		try {
			ivjXAlignmentBoxLayoutPage1 = new com.ibm.ivj.examples.vc.swing.layoutmanagers.XAlignmentBoxLayoutPage();
			ivjXAlignmentBoxLayoutPage1.setName("XAlignmentBoxLayoutPage1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjXAlignmentBoxLayoutPage1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Handle the Applet init method.
 */
public void init() {
	try {
		setName("LayoutManagers");
		setSize(661, 302);
		setContentPane(getJAppletContentPane());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.swing.layoutmanagers.LayoutManagers aLayoutManagers;
		Class iiCls = Class.forName("com.ibm.ivj.examples.vc.swing.layoutmanagers.LayoutManagers");
		ClassLoader iiClsLoader = iiCls.getClassLoader();
		aLayoutManagers = (com.ibm.ivj.examples.vc.swing.layoutmanagers.LayoutManagers)java.beans.Beans.instantiate(iiClsLoader,"com.ibm.ivj.examples.vc.swing.layoutmanagers.LayoutManagers");
		frame.add("Center", aLayoutManagers);
		frame.setSize(aLayoutManagers.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JApplet");
		exception.printStackTrace(System.out);
	}
}
}  // @jve:visual-info  decl-index=0 visual-constraint="20,20"
