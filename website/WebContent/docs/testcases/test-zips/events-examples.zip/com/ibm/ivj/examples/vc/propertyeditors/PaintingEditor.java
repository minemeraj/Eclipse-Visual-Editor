package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class PaintingEditor extends java.beans.PropertyEditorSupport {
/**
 * PaintingEditor constructor comment.
 */
protected PaintingEditor() {
	super();
}
/**
 * PaintingEditor constructor comment.
 * @param source java.lang.Object
 */
protected PaintingEditor(Object source) {
	super(source);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String[]
 */
public String[] getTags() {
	String[] tags = {"male", "female"};
	return tags;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isPaintable() {
	return true;
}
/**
 * This method was created in VisualAge.
 * @param gfx java.awt.Graphics
 * @param box java.awt.Rectangle
 */
public void paintValue(java.awt.Graphics gfx, java.awt.Rectangle box) {
	String tString = (String) getValue();
	
	if (tString.equals("male")) gfx.setColor(java.awt.Color.blue);
	else gfx.setColor(java.awt.Color.magenta);
	
	gfx.drawString(tString, (box.x) + 1, (box.y) + (box.height) - 2);
	return;
}
}
