package com.ibm.ivj.examples.vc.swing.actionexample;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
import javax.swing.Action;
/**
 * This type was created in VisualAge.
 */
public class ActionClass extends javax.swing.AbstractAction {
	private String fieldText = new String();
	private javax.swing.Icon fieldIcon = null;

	protected javax.swing.event.EventListenerList listenerList = new javax.swing.event.EventListenerList();	
/**
 * ActionClass constructor comment.
 */
public ActionClass() {
	super();
}
/**
 * ActionClass constructor comment.
 * @param name java.lang.String
 */
public ActionClass(String name) {
	super(name);
}
/**
 * ActionClass constructor comment.
 * @param name java.lang.String
 * @param icon javax.swing.Icon
 */
public ActionClass(String name, javax.swing.Icon icon) {
	super(name, icon);
}
/**
 * actionPerformed method comment.
 */
public void actionPerformed(java.awt.event.ActionEvent arg1) {
	fireActionPerformed(arg1);
	return;	
}
/**
 * This method was created in VisualAge.
 * @param l java.awt.event.ActionListener
 */
public void addActionListener(java.awt.event.ActionListener l) {
	listenerList.add(java.awt.event.ActionListener.class, l);		
}
/**
 * This method was created in VisualAge.
 * @param e java.awt.event.ActionEvent
 */
public void fireActionPerformed(java.awt.event.ActionEvent e) {
	// Guaranteed to return a non-null array
	Object[] listeners = listenerList.getListenerList();
	// Process the listeners last to first, notifying
	// those that are interested in this event
	for (int i = listeners.length-2; i>=0; i-=2) {
		if (e != null) {
		((java.awt.event.ActionListener)listeners[i+1]).actionPerformed(new java.awt.event.ActionEvent(this, e.getID(), e.getActionCommand()));
	    }	       
	}		
}
/**
 * Gets the icon property (javax.swing.Icon) value.
 * @return The icon property value.
 * @see #setIcon
 */
public javax.swing.Icon getIcon() {
	return (javax.swing.Icon)getValue(Action.SMALL_ICON);
}
/**
 * Gets the text property (java.lang.String) value.
 * @return The text property value.
 * @see #setText
 */
public String getText() {
	return (String)getValue(Action.NAME);
}
/**
 * This method was created in VisualAge.
 * @param l java.awt.event.ActionListener
 */
public void removeActionListener(java.awt.event.ActionListener l) {
	listenerList.remove(java.awt.event.ActionListener.class, l);		
}
/**
 * Sets the icon property (javax.swing.Icon) value.
 * @param icon The new value for the property.
 * @see #getIcon
 */
public void setIcon(javax.swing.Icon icon) {
	javax.swing.Icon oldValue = fieldIcon;
	fieldIcon = icon;
	putValue(Action.SMALL_ICON, fieldIcon);		
	firePropertyChange("icon", oldValue, icon);
}
/**
 * Sets the text property (java.lang.String) value.
 * @param text The new value for the property.
 * @see #getText
 */
public void setText(String text) {
	String oldValue = fieldText;
	fieldText = text;
	putValue(Action.NAME, fieldText);		
	firePropertyChange("text", oldValue, text);
}
}
