package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * IBM Visual Age for Java -  JRadioButtonPanel Class
 * 
 * (see RadioButtonPanel Class for an example of grouping AWT CheckBox beans.)
 * 
 * This sample demonstrates how to easily group JRadioButton beans in a unique way
 * in the Visual Composition Editor.  Java Foundation Classes JRadioButton beans 
 * are designed to be constructed independantly of each other and then be added to a 
 * group (specifically, a JFC ButtonGroup) to give them mutually exclusive selection 
 * behaviour.  In the Visual Composition Editor, you would drop the JRadioButton beans,
 * then drop a non-visual ButtonGroup bean, and finally create connections or, preferably,
 * custom code to do the add of the buttons to the group.
 *
 * This class extends java.awt.JPanel to make using radio buttons easier to use during
 * visual composition.  It does this by automatically adding all of its radio buttons to a 
 * single, private, pre-defined ButtonGroup.  It also provides properties for getting and setting
 * which checkbox is selected by instance and by index.
 *
 * This panel can be used the same as any other panel during visual composition.  You can
 * drop it on other panels and drop components into it.  In fact, you can drop any component
 * into it; not just JRadioButtons.  Even though FlowLayout is typically used for a set of
 * buttons, you can use any java.awt.LayoutManager for the layout. 
 *
 */
import javax.swing.*;
public class JRadioButtonPanel extends JPanel implements java.awt.event.ItemListener {
protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
private ButtonGroup group = new ButtonGroup();
private java.util.Vector radioButtonList = new java.util.Vector();
JRadioButton fieldSelectedRadioButton = null;
int fieldSelectedRadioButtonIndex = 0;
/**
 * RadioButtonPanel constructor comment.
 */
public JRadioButtonPanel() {
	super();
}
/**
 * RadioButtonPanel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public JRadioButtonPanel(java.awt.LayoutManager layout) {
	super(layout);
}
protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	synchronized (this.getTreeLock()) {
	if (comp != null && comp instanceof JRadioButton)
	{
	  JRadioButton radioButton = (JRadioButton)comp;
	  group.add(radioButton);
	  radioButton.addItemListener(this);
	  radioButtonList.addElement(radioButton);
	} 
	super.addImpl(comp, constraints, index);
	}	
}
/**
 * RadioButtonPanel.addPropertyChangeListener method comment.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
/**
 * RadioButtonPanel.firePropertyChange method comment.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	if (propertyChange != null)
		propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
public JRadioButton getSelectedRadioButton() {
	/* Returns the selectedRadioButton property value. */
	return fieldSelectedRadioButton;
}
/**
 * Gets the selectedRadioButtonIndex property (int) value.
 * @return The selectedRadioButtonIndex property value.
 * @see #setSelectedRadioButtonIndex
 */
public int getSelectedRadioButtonIndex() {
	/* Returns the selectedRadioButtonIndex property value. */
	return fieldSelectedRadioButtonIndex;
}
public void itemStateChanged(java.awt.event.ItemEvent itemEvent) {
	JRadioButton radioButton = (JRadioButton)(itemEvent.getSource());
	int index = radioButtonIndex(radioButton);
	if (index > -1)
	{
		setSelectedRadioButtonIndex(index);
		setSelectedRadioButton(radioButton);
	}	
}
protected int radioButtonIndex(JRadioButton radioButton) {
	int index = 0;
	while(index < radioButtonList.size() &&
			radioButtonList.elementAt(index) != radioButton)
		index++;
	if (index >= radioButtonList.size())
		index = -1;
	return index;
}
public void remove(int index) {
	synchronized (this.getTreeLock()) {
	java.awt.Component comp = this.getComponents()[index];
	if (comp != null && comp instanceof JRadioButton)
	{
		JRadioButton radioButton = (JRadioButton)comp;
		group.remove(radioButton);
		radioButton.removeItemListener(this);
		radioButtonList.removeElement(radioButton);
	}
	super.remove(index);
	}	
}
public void removeAll() {
	synchronized (this.getTreeLock()) {
	while (radioButtonList.size() > 0)		
	{
		JRadioButton radioButton = (JRadioButton)radioButtonList.elementAt(0);	
		group.remove(radioButton);
		radioButton.removeItemListener(this);
		radioButtonList.removeElementAt(0);
	}	
	super.removeAll();
	}
}
/**
 * RadioButtonPanel.removePropertyChangeListener method comment.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * Sets the selectedRadioButton property (java.awt.Checkbox) value.
 * @param selectedRadioButton The new value for the property.
 * @see #getSelectedRadioButton
 */
public void setSelectedRadioButton(JRadioButton selectedRadioButton) {
	/* Get the old property value for fire property change event. */
	JRadioButton oldValue = fieldSelectedRadioButton;
	/* Set the selectedRadioButton property (attribute) to the new value. */
	fieldSelectedRadioButton = selectedRadioButton;
	/* Fire (signal/notify) the selectedRadioButton property change event. */
	firePropertyChange("selectedRadioButton", oldValue, selectedRadioButton);

	if (selectedRadioButton != oldValue)
	{
		int index = radioButtonIndex(selectedRadioButton);
		if (index > -1)
			setSelectedRadioButtonIndex(index);
	}	
	return;
}
/**
 * Sets the selectedRadioButtonIndex property (int) value.
 * @param selectedRadioButtonIndex The new value for the property.
 * @see #getSelectedRadioButtonIndex
 */
public void setSelectedRadioButtonIndex(int selectedRadioButtonIndex) {
	/* Get the old property value for fire property change event. */
	int oldValue = fieldSelectedRadioButtonIndex;
	/* Set the selectedRadioButtonIndex property (attribute) to the new value. */
	fieldSelectedRadioButtonIndex = selectedRadioButtonIndex;
	/* Fire (signal/notify) the selectedRadioButtonIndex property change event. */
	firePropertyChange("selectedRadioButtonIndex", new Integer(oldValue), new Integer(selectedRadioButtonIndex));
	JRadioButton radioButton = (JRadioButton)radioButtonList.elementAt(selectedRadioButtonIndex);

	if (selectedRadioButtonIndex != oldValue)
		setSelectedRadioButton(radioButton);
	return;
}
}
