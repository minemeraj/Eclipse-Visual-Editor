package com.ibm.ivj.examples.vc.customerinfo;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class AddressView extends java.awt.Panel implements java.awt.event.TextListener, java.beans.PropertyChangeListener {
	protected transient java.beans.PropertyChangeSupport propertyChange;
	private Address ivjAddress1 = null;  // @jve:visual-info  decl-index=0 visual-constraint="154,217"
	private boolean ivjConnPtoP1Aligning = false;
	private boolean ivjConnPtoP2Aligning = false;
	private boolean ivjConnPtoP3Aligning = false;
	private boolean ivjConnPtoP4Aligning = false;
	private java.awt.Label ivjLabel1 = null;
	private java.awt.Label ivjLabel2 = null;
	private java.awt.Label ivjLabel3 = null;
	private java.awt.Label ivjLabel4 = null;
	private java.awt.TextField ivjTextField1 = null;
	private java.awt.TextField ivjTextField2 = null;
	private java.awt.TextField ivjTextField3 = null;
	private java.awt.TextField ivjTextField4 = null;
/**
 * Constructor
 */
public AddressView() {
	super();
	initialize();
}
/**
 * AddressView constructor comment.
 * @param layout java.awt.LayoutManager
 */
public AddressView(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * connPtoP1SetSource:  (Address1.street <--> TextField1.text)
 */
private void connPtoP1SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getAddress1() != null)) {
				getAddress1().setStreet(getTextField1().getText());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (Address1.street <--> TextField1.text)
 */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP1Aligning == false) {
			ivjConnPtoP1Aligning = true;
			if ((getAddress1() != null)) {
				getTextField1().setText(getAddress1().getStreet());
			}
			ivjConnPtoP1Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP1Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetSource:  (Address1.state <--> TextField3.text)
 */
private void connPtoP2SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			if ((getAddress1() != null)) {
				getAddress1().setState(getTextField3().getText());
			}
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (Address1.state <--> TextField3.text)
 */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP2Aligning == false) {
			ivjConnPtoP2Aligning = true;
			if ((getAddress1() != null)) {
				getTextField3().setText(getAddress1().getState());
			}
			ivjConnPtoP2Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP2Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetSource:  (Address1.city <--> TextField2.text)
 */
private void connPtoP3SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getAddress1() != null)) {
				getAddress1().setCity(getTextField2().getText());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP3SetTarget:  (Address1.city <--> TextField2.text)
 */
private void connPtoP3SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP3Aligning == false) {
			ivjConnPtoP3Aligning = true;
			if ((getAddress1() != null)) {
				getTextField2().setText(getAddress1().getCity());
			}
			ivjConnPtoP3Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP3Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetSource:  (Address1.zipCode <--> TextField4.text)
 */
private void connPtoP4SetSource() {
	/* Set the source from the target */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			if ((getAddress1() != null)) {
				getAddress1().setZipCode(getTextField4().getText());
			}
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * connPtoP4SetTarget:  (Address1.zipCode <--> TextField4.text)
 */
private void connPtoP4SetTarget() {
	/* Set the target from the source */
	try {
		if (ivjConnPtoP4Aligning == false) {
			ivjConnPtoP4Aligning = true;
			if ((getAddress1() != null)) {
				getTextField4().setText(getAddress1().getZipCode());
			}
			ivjConnPtoP4Aligning = false;
		}
	} catch (java.lang.Throwable ivjExc) {
		ivjConnPtoP4Aligning = false;
		handleException(ivjExc);
	}
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 * @param propertyName java.lang.String
 * @param oldValue java.lang.Object
 * @param newValue java.lang.Object
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Return the Address1 property value.
 * @return com.ibm.ivj.examples.vc.customerinfo.Address
 */
private Address getAddress1() {
	return ivjAddress1;
}
/**
 * Method generated to support the promotion of the address1This attribute.
 * @return com.ibm.ivj.examples.vc.customerinfo.Address
 */
public Address getAddress1This() {
		return getAddress1();
}
/**
 * Return the Label1 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel1() {
	if (ivjLabel1 == null) {
		try {
			ivjLabel1 = new java.awt.Label();
			ivjLabel1.setName("Label1");
			ivjLabel1.setText("Street");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel1;
}
/**
 * Return the Label2 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel2() {
	if (ivjLabel2 == null) {
		try {
			ivjLabel2 = new java.awt.Label();
			ivjLabel2.setName("Label2");
			ivjLabel2.setText("City");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel2;
}
/**
 * Return the Label3 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel3() {
	if (ivjLabel3 == null) {
		try {
			ivjLabel3 = new java.awt.Label();
			ivjLabel3.setName("Label3");
			ivjLabel3.setText("State");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel3;
}
/**
 * Return the Label4 property value.
 * @return java.awt.Label
 */
private java.awt.Label getLabel4() {
	if (ivjLabel4 == null) {
		try {
			ivjLabel4 = new java.awt.Label();
			ivjLabel4.setName("Label4");
			ivjLabel4.setText("Zip code");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjLabel4;
}
/**
 * Accessor for the propertyChange field.
 * @return java.beans.PropertyChangeSupport
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Return the TextField1 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField1() {
	if (ivjTextField1 == null) {
		try {
			ivjTextField1 = new java.awt.TextField();
			ivjTextField1.setName("TextField1");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField1;
}
/**
 * Return the TextField2 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField2() {
	if (ivjTextField2 == null) {
		try {
			ivjTextField2 = new java.awt.TextField();
			ivjTextField2.setName("TextField2");
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField2;
}
/**
 * Return the TextField3 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField3() {
	if (ivjTextField3 == null) {
		try {
			ivjTextField3 = new java.awt.TextField();
			ivjTextField3.setName("TextField3");
			ivjTextField3.setColumns(2);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField3;
}
/**
 * Return the TextField4 property value.
 * @return java.awt.TextField
 */
private java.awt.TextField getTextField4() {
	if (ivjTextField4 == null) {
		try {
			ivjTextField4 = new java.awt.TextField();
			ivjTextField4.setName("TextField4");
			ivjTextField4.setColumns(11);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	return ivjTextField4;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
private void initConnections() throws java.lang.Exception {
	getTextField1().addTextListener(this);
	getTextField3().addTextListener(this);
	getTextField2().addTextListener(this);
	getTextField4().addTextListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
	connPtoP3SetTarget();
	connPtoP4SetTarget();
}
/**
 * Initialize the class.
 */
private void initialize() {
	try {
		setName("AddressView");
		setLayout(new java.awt.GridBagLayout());
		setSize(350, 100);

		java.awt.GridBagConstraints constraintsLabel1 = new java.awt.GridBagConstraints();
		constraintsLabel1.gridx = 0; constraintsLabel1.gridy = 0;
		constraintsLabel1.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel1.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel1(), constraintsLabel1);

		java.awt.GridBagConstraints constraintsLabel2 = new java.awt.GridBagConstraints();
		constraintsLabel2.gridx = 0; constraintsLabel2.gridy = 1;
		constraintsLabel2.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel2.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel2(), constraintsLabel2);

		java.awt.GridBagConstraints constraintsLabel3 = new java.awt.GridBagConstraints();
		constraintsLabel3.gridx = 0; constraintsLabel3.gridy = 2;
		constraintsLabel3.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsLabel3.anchor = java.awt.GridBagConstraints.WEST;
		add(getLabel3(), constraintsLabel3);

		java.awt.GridBagConstraints constraintsTextField1 = new java.awt.GridBagConstraints();
		constraintsTextField1.gridx = 1; constraintsTextField1.gridy = 0;
		constraintsTextField1.gridwidth = 3;
		constraintsTextField1.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsTextField1.weightx = 1.0;
		add(getTextField1(), constraintsTextField1);

		java.awt.GridBagConstraints constraintsTextField2 = new java.awt.GridBagConstraints();
		constraintsTextField2.gridx = 1; constraintsTextField2.gridy = 1;
		constraintsTextField2.gridwidth = 3;
		constraintsTextField2.fill = java.awt.GridBagConstraints.HORIZONTAL;
		constraintsTextField2.weightx = 1.0;
		add(getTextField2(), constraintsTextField2);

		java.awt.GridBagConstraints constraintsTextField3 = new java.awt.GridBagConstraints();
		constraintsTextField3.gridx = 1; constraintsTextField3.gridy = 2;
		constraintsTextField3.insets = new java.awt.Insets(0, 0, 0, 20);
		add(getTextField3(), constraintsTextField3);

		java.awt.GridBagConstraints constraintsLabel4 = new java.awt.GridBagConstraints();
		constraintsLabel4.gridx = 2; constraintsLabel4.gridy = 2;
		add(getLabel4(), constraintsLabel4);

		java.awt.GridBagConstraints constraintsTextField4 = new java.awt.GridBagConstraints();
		constraintsTextField4.gridx = 3; constraintsTextField4.gridy = 2;
		constraintsTextField4.anchor = java.awt.GridBagConstraints.WEST;
		add(getTextField4(), constraintsTextField4);
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		java.awt.Frame frame;
		try {
			Class aFrameClass = Class.forName("com.ibm.uvm.abt.edit.TestFrame");
			frame = (java.awt.Frame)aFrameClass.newInstance();
		} catch (java.lang.Throwable ivjExc) {
			frame = new java.awt.Frame();
		}
		com.ibm.ivj.examples.vc.customerinfo.AddressView aAddressView;
		aAddressView = new com.ibm.ivj.examples.vc.customerinfo.AddressView();
		frame.add("Center", aAddressView);
		frame.setSize(aAddressView.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.awt.Panel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	if (evt.getSource() == getAddress1() && (evt.getPropertyName().equals("street"))) 
		connPtoP1SetTarget();
	if (evt.getSource() == getAddress1() && (evt.getPropertyName().equals("state"))) 
		connPtoP2SetTarget();
	if (evt.getSource() == getAddress1() && (evt.getPropertyName().equals("city"))) 
		connPtoP3SetTarget();
	if (evt.getSource() == getAddress1() && (evt.getPropertyName().equals("zipCode"))) 
		connPtoP4SetTarget();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Set the Address1 to a new value.
 * @param newValue com.ibm.ivj.examples.vc.customerinfo.Address
 */
private void setAddress1(Address newValue) {
	if (ivjAddress1 != newValue) {
		try {
			com.ibm.ivj.examples.vc.customerinfo.Address oldValue = getAddress1();
			/* Stop listening for events from the current object */
			if (ivjAddress1 != null) {
				ivjAddress1.removePropertyChangeListener(this);
			}
			ivjAddress1 = newValue;

			/* Listen for events from the new object */
			if (ivjAddress1 != null) {
				ivjAddress1.addPropertyChangeListener(this);
			}
			connPtoP1SetTarget();
			connPtoP2SetTarget();
			connPtoP3SetTarget();
			connPtoP4SetTarget();
			firePropertyChange("address1This", oldValue, newValue);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	};
}
/**
 * Method generated to support the promotion of the address1This attribute.
 * @param arg1 com.ibm.ivj.examples.vc.customerinfo.Address
 */
public void setAddress1This(Address arg1) {
		setAddress1(arg1);
}
/**
 * Method to handle events for the TextListener interface.
 * @param e java.awt.event.TextEvent
 */
public void textValueChanged(java.awt.event.TextEvent e) {
	if (e.getSource() == getTextField1()) 
		connPtoP1SetSource();
	if (e.getSource() == getTextField3()) 
		connPtoP2SetSource();
	if (e.getSource() == getTextField2()) 
		connPtoP3SetSource();
	if (e.getSource() == getTextField4()) 
		connPtoP4SetSource();
}
}  // @jve:visual-info  decl-index=0 visual-constraint="62,64"
