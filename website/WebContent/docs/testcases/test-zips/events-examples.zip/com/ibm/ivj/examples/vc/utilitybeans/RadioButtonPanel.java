package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * IBM Visual Age for Java -  RadioButtonPanel Class
 * 
 * This sample demonstrates how to use grouped checkboxes, often referred to as 
 * radio buttons, in a unique way in the Visual Composition Editor.  Normally,
 * you drop checkboxes into your bean and then drop a checkboxGroup and then you
 * connect each checkbox's checkboxGroup property to the checkboxGroup. 
 *
 * This class extends java.awt.Panel to make using grouped checkboxes easier to use during
 * visual composition.  It does this by setting the checkboxGroup of all the checkboxes 
 * dropped into it to a single instance.  It also provides properties for getting and setting
 * which checkbox is selected by instance and by index.
 *
 * This panel can be used the same as any other panel during visual composition.  You can
 * drop it on other panels and drop components into it.  In fact, you can drop any component
 * into it; not just checkboxes.  Even though FlowLayout is typically used for a set of
 * checkboxes, you can you any java.awt.LayoutManager for the layout. 
 *
 */
public class RadioButtonPanel extends java.awt.Panel implements java.awt.event.ItemListener {
private java.awt.CheckboxGroup checkboxGroup = new java.awt.CheckboxGroup();
private java.util.Vector radioButtonList = new java.util.Vector();
java.awt.Checkbox fieldSelectedRadioButton = null;
protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
int fieldSelectedRadioButtonIndex = 0;
/**
 * RadioButtonPanel constructor comment.
 */
public RadioButtonPanel() {
	super();
}
/**
 * RadioButtonPanel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public RadioButtonPanel(java.awt.LayoutManager layout) {
	super(layout);
}
protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	synchronized (this.getTreeLock()) {
	if (comp != null && comp instanceof java.awt.Checkbox)
	{
	  java.awt.Checkbox radioButton = (java.awt.Checkbox)comp;
	  radioButton.setCheckboxGroup(checkboxGroup);
	  radioButton.addItemListener(this);
	  radioButtonList.addElement(radioButton);
	} 
	super.addImpl(comp, constraints, index);
	}	
}
/**
 * RadioButtonPanel.addPropertyChangeListener method comment.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
/**
 * RadioButtonPanel.firePropertyChange method comment.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the selectedRadioButton property (java.awt.Checkbox) value.
 * @return The selectedRadioButton property value.
 * @see #setSelectedRadioButton
 */
public java.awt.Checkbox getSelectedRadioButton() {
	/* Returns the selectedRadioButton property value. */
	if (fieldSelectedRadioButton == null) {
		try {
			fieldSelectedRadioButton = new java.awt.Checkbox();
		} catch (Throwable exception) {
			System.err.println("Exception creating selectedRadioButton property.");
		}
	};
	return fieldSelectedRadioButton;
}
/**
 * Gets the selectedRadioButtonIndex property (int) value.
 * @return The selectedRadioButtonIndex property value.
 * @see #setSelectedRadioButtonIndex
 */
public int getSelectedRadioButtonIndex() {
	/* Returns the selectedRadioButtonIndex property value. */
	return fieldSelectedRadioButtonIndex;
}
public void itemStateChanged(java.awt.event.ItemEvent itemEvent) {
	java.awt.Checkbox radioButton = (java.awt.Checkbox)(itemEvent.getSource());
	int index = radioButtonIndex(radioButton);
	if (index > -1)
	{
		setSelectedRadioButtonIndex(index);
		setSelectedRadioButton(radioButton);
	}	
}
/**
 * This method was created by a SmartGuide.
 * @return int
 * @param radioButton java.awt.Checkbox
 */
protected int radioButtonIndex(java.awt.Checkbox radioButton) {
	int index = 0;
	while(index < radioButtonList.size() &&
			radioButtonList.elementAt(index) != radioButton)
		index++;
	if (index >= radioButtonList.size())
		index = -1;
	return index;
}
public void remove(int index) {
	synchronized (this.getTreeLock()) {
	java.awt.Component comp = this.getComponents()[index];
	if (comp != null && comp instanceof java.awt.Checkbox)
	{
		java.awt.Checkbox radioButton = (java.awt.Checkbox)comp;
		radioButton.setCheckboxGroup(null);
		radioButton.removeItemListener(this);
		radioButtonList.removeElement(radioButton);
	}
	super.remove(index);
	}	
}
public void removeAll() {
	synchronized (this.getTreeLock()) {
	while (radioButtonList.size() > 0)		
	{
		java.awt.Checkbox radioButton = (java.awt.Checkbox)radioButtonList.elementAt(0);	
		radioButton.setCheckboxGroup(null);
		radioButton.removeItemListener(this);
		radioButtonList.removeElementAt(0);
	}	
	super.removeAll();
	}
}
/**
 * RadioButtonPanel.removePropertyChangeListener method comment.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * Sets the selectedRadioButton property (java.awt.Checkbox) value.
 * @param selectedRadioButton The new value for the property.
 * @see #getSelectedRadioButton
 */
public void setSelectedRadioButton(java.awt.Checkbox selectedRadioButton) {
	/* Get the old property value for fire property change event. */
	java.awt.Checkbox oldValue = fieldSelectedRadioButton;
	/* Set the selectedRadioButton property (attribute) to the new value. */
	fieldSelectedRadioButton = selectedRadioButton;
	/* Fire (signal/notify) the selectedRadioButton property change event. */
	firePropertyChange("selectedRadioButton", oldValue, selectedRadioButton);
	checkboxGroup.setSelectedCheckbox(selectedRadioButton);
	if (selectedRadioButton != oldValue)
	{
		int index = radioButtonIndex(selectedRadioButton);
		if (index > -1)
			setSelectedRadioButtonIndex(index);
	}	
	return;
}
/**
 * Sets the selectedRadioButtonIndex property (int) value.
 * @param selectedRadioButtonIndex The new value for the property.
 * @see #getSelectedRadioButtonIndex
 */
public void setSelectedRadioButtonIndex(int selectedRadioButtonIndex) {
	/* Get the old property value for fire property change event. */
	int oldValue = fieldSelectedRadioButtonIndex;
	/* Set the selectedRadioButtonIndex property (attribute) to the new value. */
	fieldSelectedRadioButtonIndex = selectedRadioButtonIndex;
	/* Fire (signal/notify) the selectedRadioButtonIndex property change event. */
	firePropertyChange("selectedRadioButtonIndex", new Integer(oldValue), new Integer(selectedRadioButtonIndex));
	java.awt.Checkbox radioButton = (java.awt.Checkbox)radioButtonList.elementAt(selectedRadioButtonIndex);
	checkboxGroup.setSelectedCheckbox(radioButton);
	if (selectedRadioButtonIndex != oldValue)
		setSelectedRadioButton(radioButton);
	return;
}
}
