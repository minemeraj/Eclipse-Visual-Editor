package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class IncomeRangeEditor extends java.beans.PropertyEditorSupport {
	String[] stringValues = {
		"0 - 20,000",
		"20,001 - 50,000",
		"50,001 - 100,000",
		"100,001+" };
	int[] intValues = {1, 2, 3, 4};
	String[] codeGenStrings = {
		"com.ibm.ivj.examples.vc.propertyeditors.Person.belowTwenty",
		"com.ibm.ivj.examples.vc.propertyeditors.Person.twentyToFifty",
		"com.ibm.ivj.examples.vc.propertyeditors.Person.fiftyToOneHundred",
		"com.ibm.ivj.examples.vc.propertyeditors.Person.aboveOneHundred" };		
/**
 * IncomeRangeEditor constructor comment.
 */
protected IncomeRangeEditor() {
	super();
}
/**
 * IncomeRangeEditor constructor comment.
 * @param source java.lang.Object
 */
protected IncomeRangeEditor(Object source) {
	super(source);
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getAsText() {
	for (int i = 0; i < intValues.length; i++) {
		if (intValues[i] == ((Integer) getValue()).intValue()) 
			return stringValues[i];
	}
	return "";
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getJavaInitializationString() {
	for (int i = 0; i < intValues.length; i++) {
		if (intValues[i] == ((Integer) getValue()).intValue()) 
			return codeGenStrings[i];
	}
	return "0";
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String[]
 */
public String[] getTags() {
	return stringValues;
}
/**
 * This method was created in VisualAge.
 * @param text java.lang.String
 * @exception java.lang.IllegalArgumentException The exception description.
 */
public void setAsText(String text) throws IllegalArgumentException {
	for (int i = 0; i < stringValues.length; i++) {
		if (stringValues[i].equals(text)) {
			setValue(new Integer(intValues[i]));
			return;
		}
	}
	throw new java.lang.IllegalArgumentException(text);
}
}
