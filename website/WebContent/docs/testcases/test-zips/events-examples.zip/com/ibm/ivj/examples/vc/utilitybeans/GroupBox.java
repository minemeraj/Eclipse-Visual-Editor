package com.ibm.ivj.examples.vc.utilitybeans;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in Visual Age for Java.
 */
public class GroupBox extends javax.swing.border.TitledBorder {
	protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
	private java.awt.Color fieldLineColor = null;
	private int fieldLineWidth = 0;
	private int fieldTitleJustification = 0;
	private int fieldTitlePosition = 0;
/**
 * This method was created in Visual Age for Java.
 */
public GroupBox() {
	super(new javax.swing.border.LineBorder(java.awt.Color.black),"Title");
	fieldLineColor = java.awt.Color.black;
	fieldLineWidth = 1;
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	if (propertyChange != null) 
		propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Gets the lineColorproperty (java.awt.Color) value.
 * @return The lineColor property value.
 * @see #setLineColor
 */
public java.awt.Color getLineColor() {
	/* Returns the lineColorproperty value. */
	if (fieldLineColor == null) {
		try {
			fieldLineColor = new java.awt.Color(0);
		} catch (Throwable exception) {
			System.err.println("Exception creating lineColorproperty.");
		}
	};
	return fieldLineColor;
}
/**
 * Gets the lineWidthproperty (int) value.
 * @return The lineWidth property value.
 * @see #setLineWidth
 */
public int getLineWidth() {
	/* Returns the lineWidthproperty value. */
	return fieldLineWidth;
}
/**
 * Gets the titleJustificationproperty (int) value.
 * @return The titleJustification property value.
 * @see #setTitleJustification
 */
public int getTitleJustification() {
	/* Returns the titleJustificationproperty value. */
	return fieldTitleJustification;
}
/**
 * Gets the titlePositionproperty (int) value.
 * @return The titlePosition property value.
 * @see #setTitlePosition
 */
public int getTitlePosition() {
	/* Returns the titlePositionproperty value. */
	return fieldTitlePosition;
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * Sets the lineColor property (java.awt.Color) value.
 * @param lineColor The new value for the property.
 * @see #getLineColor
 */
public void setLineColor(java.awt.Color lineColor) {
	/* Get the old property value for fire property change event. */
	java.awt.Color oldValue = fieldLineColor;
	/* Set the lineColorproperty to the new value. */
	fieldLineColor = lineColor;
	setBorder(new javax.swing.border.LineBorder(lineColor, getLineWidth()));
	/* Fire (signal/notify) the lineColorproperty change event. */
	firePropertyChange("lineColor", oldValue, lineColor);
	return;
}
/**
 * Sets the lineWidth property (int) value.
 * @param lineWidth The new value for the property.
 * @see #getLineWidth
 */
public void setLineWidth(int lineWidth) {
	/* Get the old property value for fire property change event. */
	int oldValue = fieldLineWidth;
	/* Set the lineWidthproperty to the new value. */
	fieldLineWidth = lineWidth;
	setBorder(new javax.swing.border.LineBorder(getLineColor(), lineWidth));
	/* Fire (signal/notify) the lineWidthproperty change event. */
	firePropertyChange("lineWidth", new Integer(oldValue), new Integer(lineWidth));
	return;
}
/**
 * Sets the titleJustification property (int) value.
 * @param titleJustification The new value for the property.
 * @see #getTitleJustification
 */
public void setTitleJustification(int titleJustification) {
	/* Get the old property value for fire property change event. */
	int oldValue = fieldTitleJustification;
	/* Set the titleJustificationproperty to the new value. */
	fieldTitleJustification = titleJustification;
	/* Fire (signal/notify) the titleJustificationproperty change event. */
	firePropertyChange("titleJustification", new Integer(oldValue), new Integer(titleJustification));
	return;
}
/**
 * Sets the titlePosition property (int) value.
 * @param titlePosition The new value for the property.
 * @see #getTitlePosition
 */
public void setTitlePosition(int titlePosition) {
	/* Get the old property value for fire property change event. */
	int oldValue = fieldTitlePosition;
	/* Set the titlePositionproperty to the new value. */
	fieldTitlePosition = titlePosition;
	/* Fire (signal/notify) the titlePositionproperty change event. */
	firePropertyChange("titlePosition", new Integer(oldValue), new Integer(titlePosition));
	return;
}
}
