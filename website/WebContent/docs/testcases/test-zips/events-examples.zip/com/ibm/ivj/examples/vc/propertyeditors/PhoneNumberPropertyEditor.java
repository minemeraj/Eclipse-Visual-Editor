package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class PhoneNumberPropertyEditor extends java.beans.PropertyEditorSupport {
/**
 * PhoneNumberPropertyEditor constructor comment.
 */
protected PhoneNumberPropertyEditor() {
	super();
}
/**
 * PhoneNumberPropertyEditor constructor comment.
 * @param source java.lang.Object
 */
protected PhoneNumberPropertyEditor(Object source) {
	super(source);
}
/**
 * This method was created in VisualAge.
 * @param text java.lang.String
 * @exception java.lang.IllegalArgumentException The exception description.
 */
public void setAsText(String text) throws IllegalArgumentException {
	if ((text.length() == 8) && (text.charAt(3) == '-')) {
		setValue(text);
		return;
	}
	if (text.length() == 7) {
		setValue(text.substring(0, 3) + "-" + text.substring(3, 7));
		return;
	}
	throw new java.lang.IllegalArgumentException(
		"The entry " + text + " is not valid. The previous entry will be kept.");
}
}
