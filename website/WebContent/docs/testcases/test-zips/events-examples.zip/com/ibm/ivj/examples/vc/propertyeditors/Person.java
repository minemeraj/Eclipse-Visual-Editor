package com.ibm.ivj.examples.vc.propertyeditors;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class Person {
	private Name fieldName = new Name();
	protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
	transient Address fieldAddress = null;
	private String fieldSex = "";
	private int fieldIncomeRange = 0;
	private String fieldPhoneNumber = "";
	public final static int belowTwenty = 1;
	public final static int twentyToFifty = 2;
	public final static int fiftyToOneHundred = 3;
	public final static int aboveOneHundred = 4;
	public final static java.lang.String[] incomeStrings = {
		"[Not set]", 
		"Below $20000", 
		"From $20001 to $50000", 
		"From $50001 to $100000", 
		"Over $100000"};
/**
 * Person constructor comment.
 */
public Person() {
	super();
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	propertyChange.addPropertyChangeListener(arg1);
}
/**
 * Compares two objects for equality. Returns a boolean that indicates
 * whether this object is equivalent to the specified object. This method
 * is used when an object is stored in a hashtable.
 * @param obj the Object to compare with
 * @return true if these Objects are equal; false otherwise.
 * @see java.util.Hashtable
 */
public boolean equals(Object obj) {
	// insert code to compare the receiver and #obj here
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: #obj might be an instance of any class
	
	return ( getName().toString() == ((Person)obj).getName().toString() );
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String arg1, Object arg2, Object arg3) {
	propertyChange.firePropertyChange(arg1, arg2, arg3);
}
/**
 * Gets the address property (com.ibm.ivj.examples.vc.propertyeditors.Address) value.
 * @return The address property value.
 */
public Address getAddress() {
	return fieldAddress;
}
/**
 * Insert the method's description here.
 * Creation date: (8/18/99 1:14:24 PM)
 * @return java.lang.String
 */
public String getIncomeAsString() {
	try {
		return incomeStrings[getIncomeRange()];
	} catch (Throwable e) {
		return "Out of range";
	}
}
/**
 * Gets the incomeRange property (int) value.
 * @return The incomeRange property value.
 * @see #setIncomeRange
 */
public int getIncomeRange() {
	return fieldIncomeRange;
}
/**
 * Gets the name property (com.ibm.ivj.examples.vc.propertyeditors.Name) value.
 * @return The name property value.
 * @see #setName
 */
public com.ibm.ivj.examples.vc.propertyeditors.Name getName() {
	return fieldName;
}
/**
 * Gets the phoneNumber property (java.lang.String) value.
 * @return The phoneNumber property value.
 * @see #setPhoneNumber
 */
public String getPhoneNumber() {
	return fieldPhoneNumber;
}
/**
 * Gets the sex property (java.lang.String) value.
 * @return The sex property value.
 * @see #setSex
 */
public String getSex() {
	return fieldSex;
}
/**
 * Insert the method's description here.
 * Creation date: (8/18/99 1:17:41 PM)
 * @return java.lang.String[]
 */
public final static java.lang.String[] getStrings() {
	return incomeStrings;
}
/**
 * Generates a hash code for the receiver.
 * This method is supported primarily for
 * hash tables, such as those provided in java.util.
 * @return an integer hash code for the receiver
 * @see java.util.Hashtable
 */
public int hashCode() {
	// insert code to generate a hash code for the receiver here
	// This implementation forwards the message to super.  You may replace or supplement this.
	// NOTE: if two objects are equal (equals(Object) returns true) they must have the same hash code
	return super.hashCode();
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener arg1) {
	propertyChange.removePropertyChangeListener(arg1);
}
/**
 * Sets the incomeRange property (int) value.
 * @param incomeRange The new value for the property.
 * @see #getIncomeRange
 */
public void setIncomeRange(int incomeRange) {
	int oldValue = fieldIncomeRange;
	fieldIncomeRange = incomeRange;
	firePropertyChange("incomeRange", new Integer(oldValue), new Integer(incomeRange));
}
/**
 * Sets the name property (com.ibm.ivj.examples.vc.propertyeditors.Name) value.
 * @param name The new value for the property.
 * @see #getName
 */
public void setName(com.ibm.ivj.examples.vc.propertyeditors.Name name) {
	com.ibm.ivj.examples.vc.propertyeditors.Name oldValue = fieldName;
	fieldName = name;
	firePropertyChange("name", oldValue, name);
}
/**
 * Sets the phoneNumber property (java.lang.String) value.
 * @param phoneNumber The new value for the property.
 * @see #getPhoneNumber
 */
public void setPhoneNumber(String phoneNumber) {
	String oldValue = fieldPhoneNumber;
	fieldPhoneNumber = phoneNumber;
	firePropertyChange("phoneNumber", oldValue, phoneNumber);
}
/**
 * Sets the sex property (java.lang.String) value.
 * @param sex The new value for the property.
 * @see #getSex
 */
public void setSex(String sex) {
	String oldValue = fieldSex;
	fieldSex = sex;
	firePropertyChange("sex", oldValue, sex);
}
/**
 * Returns a String that represents the value of this object.
 */
public String toString() {
	// insert code to print the receiver here
	// This implementation forwards the message to super. You may replace or supplement this.
	return getName().toString();
}
}
