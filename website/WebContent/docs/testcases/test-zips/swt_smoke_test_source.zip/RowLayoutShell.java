
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Color;

public class RowLayoutShell {

	private org.eclipse.swt.widgets.Shell sShell = null; // @jve:decl-index=0:visual-constraint="10,10"

	private Button button = null;

	private Label label = null;

	private Text text = null;

	private Label label1 = null;

	private Button button1 = null;

	private Text text1 = null;

	private Label label2 = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new org.eclipse.swt.widgets.Shell();
		sShell.setText("Row Layout Shell");
		sShell.setLayout(new RowLayout());
		sShell.setSize(new org.eclipse.swt.graphics.Point(185, 207));
		label = new Label(sShell, SWT.NONE);
		label.setText("This");
		label.setBackground(Display.getDefault()
				.getSystemColor(SWT.COLOR_GREEN));
		label.setFont(new Font(Display.getDefault(), "Tahoma", 14, SWT.BOLD));
		label.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_YELLOW));
		button = new Button(sShell, SWT.NONE);
		button.setText("Shell");
		button.setFont(new Font(Display.getDefault(), "Times New Roman", 18,
				SWT.BOLD | SWT.ITALIC));
		text = new Text(sShell, SWT.BORDER);
		text.setText("has");
		text.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		text.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_RED));
		label1 = new Label(sShell, SWT.NONE);
		label1.setText("a");
		label1.setFont(new Font(Display.getDefault(), "Rockwell Condensed", 24,
				SWT.ITALIC));
		label1.setForeground(new Color(Display.getDefault(), 0, 153, 0));
		button1 = new Button(sShell, SWT.NONE);
		button1.setText("Row");
		text1 = new Text(sShell, SWT.BORDER);
		text1.setText("Layout");
		text1.setFont(new Font(Display.getDefault(), "Arial", 18, SWT.BOLD));
		text1.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_DARK_MAGENTA));
		text1.setForeground(Display.getDefault().getSystemColor(
				SWT.COLOR_MAGENTA));
		label2 = new Label(sShell, SWT.NONE);
		label2.setText("manager!");
		label2.setFont(new Font(Display.getDefault(), "Binner Gothic", 36,
				SWT.BOLD));
		label2.setBackground(Display.getDefault().getSystemColor(
				SWT.COLOR_BLACK));
		label2.setForeground(Display.getDefault()
				.getSystemColor(SWT.COLOR_GRAY));
	}

}
