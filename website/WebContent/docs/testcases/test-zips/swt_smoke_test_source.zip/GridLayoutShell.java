import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

public class GridLayoutShell {

	private org.eclipse.swt.widgets.Shell sShell = null; // @jve:decl-index=0:visual-constraint="10,10"

	private Composite composite = null;

	private Composite composite1 = null;

	private Composite composite2 = null;

	private Button button2 = null;

	private Button button3 = null;

	private Button button4 = null;

	private Button button5 = null;

	private Button button6 = null;

	private Button button7 = null;

	private Button button8 = null;

	private Button button = null;

	private Button button1 = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		GridLayout gridLayout1 = new GridLayout();
		gridLayout1.numColumns = 3;
		sShell = new org.eclipse.swt.widgets.Shell();
		sShell.setText("Grid Layout Shell");
		sShell.setLayout(gridLayout1);
		createComposite();
		createComposite1();
		createComposite2();
		sShell.setSize(new org.eclipse.swt.graphics.Point(336, 271));
	}

	/**
	 * This method initializes composite
	 */
	private void createComposite() {
		GridData gridData6 = new GridData();
		gridData6.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData6.grabExcessHorizontalSpace = true;
		GridLayout gridLayout5 = new GridLayout();
		gridLayout5.numColumns = 2;
		gridLayout5.makeColumnsEqualWidth = true;
		GridData gridData2 = new GridData();
		gridData2.horizontalSpan = 3;
		gridData2.grabExcessHorizontalSpace = true;
		gridData2.grabExcessVerticalSpace = true;
		gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData2.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		composite = new Composite(sShell, SWT.NONE);
		composite.setLayoutData(gridData2);
		composite.setLayout(gridLayout5);
		button2 = new Button(composite, SWT.NONE);
		button2.setText("One North");
		button3 = new Button(composite, SWT.NONE);
		button3.setText("Two North");
		button3.setLayoutData(gridData6);
	}

	/**
	 * This method initializes composite1
	 */
	private void createComposite1() {
		GridData gridData9 = new GridData();
		gridData9.grabExcessHorizontalSpace = true;
		gridData9.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData9.grabExcessVerticalSpace = true;
		gridData9.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		GridData gridData8 = new GridData();
		gridData8.grabExcessHorizontalSpace = true;
		gridData8.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		GridData gridData7 = new GridData();
		gridData7.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData7.grabExcessHorizontalSpace = true;
		gridData7.grabExcessVerticalSpace = true;
		gridData7.verticalAlignment = org.eclipse.swt.layout.GridData.END;
		GridLayout gridLayout4 = new GridLayout();
		gridLayout4.numColumns = 3;
		GridData gridData31 = new GridData();
		gridData31.grabExcessVerticalSpace = true;
		gridData31.grabExcessHorizontalSpace = true;
		gridData31.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData31.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData31.verticalSpan = 3;
		GridData gridData21 = new GridData();
		gridData21.grabExcessVerticalSpace = true;
		gridData21.grabExcessHorizontalSpace = true;
		gridData21.verticalSpan = 3;
		gridData21.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData21.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		GridData gridData4 = new GridData();
		gridData4.grabExcessHorizontalSpace = true;
		gridData4.grabExcessVerticalSpace = true;
		gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		composite1 = new Composite(sShell, SWT.NONE);
		composite1.setLayoutData(gridData4);
		composite1.setLayout(gridLayout4);
		button = new Button(composite1, SWT.NONE);
		button.setText("West");
		button.setLayoutData(gridData21);
		button6 = new Button(composite1, SWT.NONE);
		button6.setLayoutData(gridData7);
		button6.setText("One Center");
		button1 = new Button(composite1, SWT.NONE);
		button7 = new Button(composite1, SWT.NONE);
		button7.setLayoutData(gridData8);
		button7.setText("Two Center");
		button8 = new Button(composite1, SWT.NONE);
		button8.setLayoutData(gridData9);
		button8.setText("Three Center");
		button1.setText("East");
		button1.setLayoutData(gridData31);
	}

	/**
	 * This method initializes composite2
	 */
	private void createComposite2() {
		GridData gridData81 = new GridData();
		gridData81.grabExcessHorizontalSpace = true;
		gridData81.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		GridLayout gridLayout7 = new GridLayout();
		gridLayout7.makeColumnsEqualWidth = true;
		gridLayout7.numColumns = 2;
		GridData gridData3 = new GridData();
		gridData3.horizontalSpan = 3;
		gridData3.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData3.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData3.grabExcessVerticalSpace = true;
		gridData3.grabExcessHorizontalSpace = true;
		composite2 = new Composite(sShell, SWT.NONE);
		composite2.setLayoutData(gridData3);
		composite2.setLayout(gridLayout7);
		button4 = new Button(composite2, SWT.NONE);
		button4.setText("One South");
		button5 = new Button(composite2, SWT.NONE);
		button5.setText("Two South");
		button5.setLayoutData(gridData81);
	}

}
