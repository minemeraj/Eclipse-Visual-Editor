
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.Text;

public class FillLayoutShell {

	private org.eclipse.swt.widgets.Shell sShell = null; // @jve:decl-index=0:visual-constraint="10,10"

	private Text text = null;

	private Button button = null;

	private Label label = null;

	private Link link = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new org.eclipse.swt.widgets.Shell();
		sShell.setText("Fill Layout Shell");
		sShell.setLayout(new FillLayout());
		sShell.setSize(new org.eclipse.swt.graphics.Point(368, 251));
		text = new Text(sShell, SWT.BORDER);
		button = new Button(sShell, SWT.NONE);
		button.setText("is");
		text.setText("Everything");
		label = new Label(sShell, SWT.NONE);
		label.setText("The Same");
		link = new Link(sShell, SWT.NONE);
		link.setText("<a>   Size   </a>  Here");
	}

}
