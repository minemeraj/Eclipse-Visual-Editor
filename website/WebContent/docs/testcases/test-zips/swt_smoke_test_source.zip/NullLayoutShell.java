
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;

public class NullLayoutShell {

	private org.eclipse.swt.widgets.Shell sShell = null; // @jve:decl-index=0:visual-constraint="10,10"

	private Button button = null;

	private Button button1 = null;

	private Button button2 = null;

	private List list = null;

	private Label label = null;

	private Text text = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new org.eclipse.swt.widgets.Shell();
		sShell.setText("Null Layout Shell");
		sShell.setSize(new org.eclipse.swt.graphics.Point(400, 269));
		button = new Button(sShell, SWT.NONE);
		button.setBounds(new org.eclipse.swt.graphics.Rectangle(276, 10, 100,
				40));
		button.setText("Add Item");
		button1 = new Button(sShell, SWT.NONE);
		button1.setBounds(new org.eclipse.swt.graphics.Rectangle(276, 70, 100,
				40));
		button1.setText("Remove Item");
		button1.setEnabled(false);
		button2 = new Button(sShell, SWT.NONE);
		button2.setBounds(new org.eclipse.swt.graphics.Rectangle(276, 130, 100,
				40));
		button2.setText("Save List");
		list = new List(sShell, SWT.NONE);
		list
				.setBounds(new org.eclipse.swt.graphics.Rectangle(56, 70, 183,
						141));
		label = new Label(sShell, SWT.NONE);
		label.setBounds(new org.eclipse.swt.graphics.Rectangle(56, 10, 73, 23));
		label.setText("To Do Item:");
		label.setFont(new Font(Display.getDefault(), "Tahoma", 8, SWT.BOLD));
		text = new Text(sShell, SWT.BORDER);
		text.setBounds(new org.eclipse.swt.graphics.Rectangle(156, 10, 82, 23));
	}

}
