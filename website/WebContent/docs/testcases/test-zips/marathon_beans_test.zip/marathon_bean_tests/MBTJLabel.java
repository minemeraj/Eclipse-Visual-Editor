package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 2:27:54 PM)
 * @author: Administrator
 */
public class MBTJLabel extends javax.swing.JPanel {
	private javax.swing.JLabel ivjDave_the_JLabel = null;
/**
 * MBTJLabel constructor comment.
 */
public MBTJLabel() {
	super();
	initialize();
}
/**
 * MBTJLabel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJLabel(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJLabel constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJLabel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJLabel constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJLabel(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JLabel property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getDave_the_JLabel() {
	if (ivjDave_the_JLabel == null) {
		try {
			ivjDave_the_JLabel = new javax.swing.JLabel();
			ivjDave_the_JLabel.setName("Dave_the_JLabel");
			ivjDave_the_JLabel.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JLabel.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
			ivjDave_the_JLabel.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JLabel.setRequestFocusEnabled(false);
			ivjDave_the_JLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
			ivjDave_the_JLabel.setOpaque(false);
			ivjDave_the_JLabel.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JLabel.setDisplayedMnemonic('L');
			ivjDave_the_JLabel.setText("Read Me");
			ivjDave_the_JLabel.setForeground(java.awt.Color.red);
			ivjDave_the_JLabel.setFont(new java.awt.Font("dialog", 3, 14));
			ivjDave_the_JLabel.setEnabled(false);
			ivjDave_the_JLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			ivjDave_the_JLabel.setToolTipText("Do you need to know how to use this label?");
			ivjDave_the_JLabel.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JLabel.setIconTextGap(5);
			ivjDave_the_JLabel.setDoubleBuffered(true);
			ivjDave_the_JLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
			ivjDave_the_JLabel.setAutoscrolls(true);
			ivjDave_the_JLabel.setBackground(new java.awt.Color(64,204,130));
			ivjDave_the_JLabel.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JLabel.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
			ivjDave_the_JLabel.setPreferredSize(new java.awt.Dimension(100, 20));
			ivjDave_the_JLabel.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JLabel;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJLabel");
		setLayout(new java.awt.BorderLayout());
		setSize(160, 120);
		add(getDave_the_JLabel(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJLabel aMBTJLabel;
		aMBTJLabel = new MBTJLabel();
		frame.setContentPane(aMBTJLabel);
		frame.setSize(aMBTJLabel.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
