package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 11:20:13 AM)
 * @author: Administrator
 */
public class MBTJCheckBox extends javax.swing.JPanel {
	private javax.swing.JCheckBox ivjDave_the_JCheckBox = null;
/**
 * MBTJCheckBox constructor comment.
 */
public MBTJCheckBox() {
	super();
	initialize();
}
/**
 * MBTJCheckBox constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJCheckBox(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJCheckBox constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJCheckBox(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJCheckBox constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJCheckBox(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JCheckBox property value.
 * @return javax.swing.JCheckBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JCheckBox getDave_the_JCheckBox() {
	if (ivjDave_the_JCheckBox == null) {
		try {
			ivjDave_the_JCheckBox = new javax.swing.JCheckBox();
			ivjDave_the_JCheckBox.setName("Dave_the_JCheckBox");
			ivjDave_the_JCheckBox.setMnemonic(java.awt.event.KeyEvent.VK_C);
			ivjDave_the_JCheckBox.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JCheckBox.setFocusPainted(false);
			ivjDave_the_JCheckBox.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
			ivjDave_the_JCheckBox.setSelected(true);
			ivjDave_the_JCheckBox.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JCheckBox.setRequestFocusEnabled(false);
			ivjDave_the_JCheckBox.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
			ivjDave_the_JCheckBox.setOpaque(false);
			ivjDave_the_JCheckBox.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JCheckBox.setText("Check Me Out");
			ivjDave_the_JCheckBox.setVisible(true);
			ivjDave_the_JCheckBox.setForeground(java.awt.Color.blue);
			ivjDave_the_JCheckBox.setFont(new java.awt.Font("monospaced", 2, 18));
			ivjDave_the_JCheckBox.setRolloverEnabled(true);
			ivjDave_the_JCheckBox.setEnabled(false);
			ivjDave_the_JCheckBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			ivjDave_the_JCheckBox.setToolTipText("Are these called JChequeBoxes in Canada?");
			ivjDave_the_JCheckBox.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JCheckBox.setDoubleBuffered(true);
			ivjDave_the_JCheckBox.setActionCommand("myActionCommand");
			ivjDave_the_JCheckBox.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
			ivjDave_the_JCheckBox.setMargin(new java.awt.Insets(2, 2, 2, 20));
			ivjDave_the_JCheckBox.setAutoscrolls(true);
			ivjDave_the_JCheckBox.setBackground(new java.awt.Color(204,101,125));
			ivjDave_the_JCheckBox.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JCheckBox.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
			ivjDave_the_JCheckBox.setBorderPainted(true);
			ivjDave_the_JCheckBox.setPreferredSize(new java.awt.Dimension(100, 100));
			ivjDave_the_JCheckBox.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
			ivjDave_the_JCheckBox.setContentAreaFilled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JCheckBox;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJCheckBox");
		setLayout(new java.awt.BorderLayout());
		setSize(160, 120);
		add(getDave_the_JCheckBox(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJCheckBox aMBTJCheckBox;
		aMBTJCheckBox = new MBTJCheckBox();
		frame.setContentPane(aMBTJCheckBox);
		frame.setSize(aMBTJCheckBox.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
