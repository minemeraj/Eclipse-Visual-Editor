package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 12:03:05 PM)
 * @author: Administrator
 */
public class MBTJToggleButton extends javax.swing.JPanel {
	private javax.swing.JToggleButton ivjDave_the_JToggleButton = null;
/**
 * MBTJToggleButton constructor comment.
 */
public MBTJToggleButton() {
	super();
	initialize();
}
/**
 * MBTJToggleButton constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJToggleButton(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJToggleButton constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJToggleButton(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJToggleButton constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJToggleButton(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JToggleButton property value.
 * @return javax.swing.JToggleButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JToggleButton getDave_the_JToggleButton() {
	if (ivjDave_the_JToggleButton == null) {
		try {
			ivjDave_the_JToggleButton = new javax.swing.JToggleButton();
			ivjDave_the_JToggleButton.setName("Dave_the_JToggleButton");
			ivjDave_the_JToggleButton.setMnemonic(java.awt.event.KeyEvent.VK_E);
			ivjDave_the_JToggleButton.setFocusPainted(false);
			ivjDave_the_JToggleButton.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
			ivjDave_the_JToggleButton.setSelected(true);
			ivjDave_the_JToggleButton.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JToggleButton.setRequestFocusEnabled(false);
			ivjDave_the_JToggleButton.setCursor(new java.awt.Cursor(java.awt.Cursor.N_RESIZE_CURSOR));
			ivjDave_the_JToggleButton.setOpaque(true);
			ivjDave_the_JToggleButton.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JToggleButton.setText("Toggle Me");
			ivjDave_the_JToggleButton.setForeground(java.awt.Color.blue);
			ivjDave_the_JToggleButton.setFont(new java.awt.Font("sansserif", 0, 18));
			ivjDave_the_JToggleButton.setRolloverEnabled(true);
			ivjDave_the_JToggleButton.setEnabled(false);
			ivjDave_the_JToggleButton.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
			ivjDave_the_JToggleButton.setToolTipText("My favorite two states are Ohio and Pennsylvania.");
			ivjDave_the_JToggleButton.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JToggleButton.setDoubleBuffered(true);
			ivjDave_the_JToggleButton.setActionCommand("toggleButtonToggled");
			ivjDave_the_JToggleButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
			ivjDave_the_JToggleButton.setMargin(new java.awt.Insets(2, 14, 2, 30));
			ivjDave_the_JToggleButton.setAutoscrolls(true);
			ivjDave_the_JToggleButton.setBackground(new java.awt.Color(0,147,30));
			ivjDave_the_JToggleButton.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JToggleButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
			ivjDave_the_JToggleButton.setBorderPainted(false);
			ivjDave_the_JToggleButton.setPreferredSize(new java.awt.Dimension(100, 100));
			ivjDave_the_JToggleButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
			ivjDave_the_JToggleButton.setContentAreaFilled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JToggleButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJToggleButton");
		setLayout(new java.awt.BorderLayout());
		setSize(160, 120);
		add(getDave_the_JToggleButton(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJToggleButton aMBTJToggleButton;
		aMBTJToggleButton = new MBTJToggleButton();
		frame.setContentPane(aMBTJToggleButton);
		frame.setSize(aMBTJToggleButton.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
