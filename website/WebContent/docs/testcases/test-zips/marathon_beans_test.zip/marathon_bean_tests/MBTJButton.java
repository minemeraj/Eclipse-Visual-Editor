package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 9:40:44 AM)
 * @author: Administrator
 */
public class MBTJButton extends javax.swing.JPanel {
	private javax.swing.JButton ivjDave_the_JButton = null;
/**
 * MBTJButton constructor comment.
 */
public MBTJButton() {
	super();
	initialize();
}
/**
 * MBTJButton constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJButton(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJButton constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJButton(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJButton constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJButton(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the myName property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getDave_the_JButton() {
	if (ivjDave_the_JButton == null) {
		try {
			ivjDave_the_JButton = new javax.swing.JButton();
			ivjDave_the_JButton.setName("Dave_the_JButton");
			ivjDave_the_JButton.setMnemonic(java.awt.event.KeyEvent.VK_M);
			ivjDave_the_JButton.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JButton.setFocusPainted(false);
			ivjDave_the_JButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
			ivjDave_the_JButton.setSelected(true);
			ivjDave_the_JButton.setMinimumSize(new java.awt.Dimension(80, 80));
			ivjDave_the_JButton.setRequestFocusEnabled(false);
			ivjDave_the_JButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
			ivjDave_the_JButton.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JButton.setText("Press Me");
			ivjDave_the_JButton.setVisible(true);
			ivjDave_the_JButton.setForeground(java.awt.Color.red);
			ivjDave_the_JButton.setFont(new java.awt.Font("serif", 3, 14));
			ivjDave_the_JButton.setRolloverEnabled(true);
			ivjDave_the_JButton.setEnabled(false);
			ivjDave_the_JButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
			ivjDave_the_JButton.setToolTipText("Yeah, I sure am a button.");
			ivjDave_the_JButton.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JButton.setDoubleBuffered(true);
			ivjDave_the_JButton.setActionCommand("myActionCommand");
			ivjDave_the_JButton.setVerticalAlignment(javax.swing.SwingConstants.TOP);
			ivjDave_the_JButton.setMargin(new java.awt.Insets(2, 30, 2, 14));
			ivjDave_the_JButton.setAutoscrolls(true);
			ivjDave_the_JButton.setBackground(new java.awt.Color(113,204,99));
			ivjDave_the_JButton.setMaximumSize(new java.awt.Dimension(80, 80));
			ivjDave_the_JButton.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
			ivjDave_the_JButton.setBorderPainted(false);
			ivjDave_the_JButton.setPreferredSize(new java.awt.Dimension(100, 100));
			ivjDave_the_JButton.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
			ivjDave_the_JButton.setContentAreaFilled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJButton");
		setLayout(new java.awt.BorderLayout());
		this.add(getDave_the_JButton(), java.awt.BorderLayout.WEST);
		setSize(160, 120);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJButton aMBTJButton;
		aMBTJButton = new MBTJButton();
		frame.setContentPane(aMBTJButton);
		frame.setSize(aMBTJButton.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
