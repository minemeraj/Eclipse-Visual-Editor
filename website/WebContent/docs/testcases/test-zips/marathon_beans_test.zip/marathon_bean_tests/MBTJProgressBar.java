package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (4/1/2002 3:06:40 PM)
 * @author: Administrator
 */
public class MBTJProgressBar extends javax.swing.JPanel {
	private javax.swing.JProgressBar ivjDave_the_JProgressBar = null;
/**
 * MBTProgressBar constructor comment.
 */
public MBTJProgressBar() {
	super();
	initialize();
}
/**
 * MBTProgressBar constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJProgressBar(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTProgressBar constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJProgressBar(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTProgressBar constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJProgressBar(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JProgressBar property value.
 * @return javax.swing.JProgressBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JProgressBar getDave_the_JProgressBar() {
	if (ivjDave_the_JProgressBar == null) {
		try {
			ivjDave_the_JProgressBar = new javax.swing.JProgressBar();
			ivjDave_the_JProgressBar.setName("Dave_the_JProgressBar");
			ivjDave_the_JProgressBar.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JProgressBar.setDoubleBuffered(true);			
			ivjDave_the_JProgressBar.setString("71%");			
			ivjDave_the_JProgressBar.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JProgressBar.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
			ivjDave_the_JProgressBar.setAutoscrolls(true);
			ivjDave_the_JProgressBar.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JProgressBar.setBackground(new java.awt.Color(159,204,204));
			ivjDave_the_JProgressBar.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JProgressBar.setForeground(java.awt.Color.red);
			ivjDave_the_JProgressBar.setBorderPainted(false);
			ivjDave_the_JProgressBar.setPreferredSize(new java.awt.Dimension(36, 100));
			ivjDave_the_JProgressBar.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
			ivjDave_the_JProgressBar.setFont(new java.awt.Font("dialog", 1, 14));			
			ivjDave_the_JProgressBar.setStringPainted(true);
			ivjDave_the_JProgressBar.setOrientation(javax.swing.JProgressBar.VERTICAL);
			ivjDave_the_JProgressBar.setMinimum(50);
			ivjDave_the_JProgressBar.setMaximum(200);
			ivjDave_the_JProgressBar.setValue(156);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JProgressBar;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTProgressBar");
		setAutoscrolls(false);
		setAlignmentY(java.awt.Component.CENTER_ALIGNMENT);
		setLayout(new java.awt.FlowLayout());
		setBackground(new java.awt.Color(204,204,204));
		setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
		setSize(160, 120);
		add(getDave_the_JProgressBar(), getDave_the_JProgressBar().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJProgressBar aMBTProgressBar;
		aMBTProgressBar = new MBTJProgressBar();
		frame.setContentPane(aMBTProgressBar);
		frame.setSize(aMBTProgressBar.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
