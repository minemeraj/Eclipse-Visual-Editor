package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (4/1/2002 2:53:50 PM)
 * @author: Administrator
 */
public class MBTJComboBox extends javax.swing.JPanel {
	private javax.swing.JComboBox ivjDave_the_JComboBox = null;
/**
 * MBTJComboBox constructor comment.
 */
public MBTJComboBox() {
	super();
	initialize();
}
/**
 * MBTJComboBox constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJComboBox(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJComboBox constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJComboBox(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJComboBox constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJComboBox(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JComboBox property value.
 * @return javax.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JComboBox getDave_the_JComboBox() {
	if (ivjDave_the_JComboBox == null) {
		try {
			ivjDave_the_JComboBox = new javax.swing.JComboBox();
			ivjDave_the_JComboBox.setName("Dave_the_JComboBox");
			ivjDave_the_JComboBox.setToolTipText("Chose Something");
			ivjDave_the_JComboBox.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JComboBox.setEditor(new javax.swing.plaf.basic.BasicComboBoxEditor());
			ivjDave_the_JComboBox.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JComboBox.setDoubleBuffered(true);
			ivjDave_the_JComboBox.setMaximumRowCount(10);
			ivjDave_the_JComboBox.setActionCommand("somethingHappened");
			ivjDave_the_JComboBox.setPopupVisible(false);
			ivjDave_the_JComboBox.setEditable(true);
			ivjDave_the_JComboBox.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JComboBox.setRequestFocusEnabled(false);
			ivjDave_the_JComboBox.setCursor(new java.awt.Cursor(java.awt.Cursor.N_RESIZE_CURSOR));
			ivjDave_the_JComboBox.setAutoscrolls(true);
			ivjDave_the_JComboBox.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JComboBox.setBackground(new java.awt.Color(204,152,204));
			ivjDave_the_JComboBox.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JComboBox.setForeground(java.awt.Color.red);
			ivjDave_the_JComboBox.setPreferredSize(new java.awt.Dimension(100, 20));
			ivjDave_the_JComboBox.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
			ivjDave_the_JComboBox.setFont(new java.awt.Font("dialog", 3, 12));
			ivjDave_the_JComboBox.setEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JComboBox;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJComboBox");
		setLayout(new java.awt.FlowLayout());
		setSize(160, 120);
		add(getDave_the_JComboBox(), getDave_the_JComboBox().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJComboBox aMBTJComboBox;
		aMBTJComboBox = new MBTJComboBox();
		frame.setContentPane(aMBTJComboBox);
		frame.setSize(aMBTJComboBox.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
