package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 3:32:54 PM)
 * @author: Administrator
 */
public class MBTJPasswordField extends javax.swing.JPanel {
	private javax.swing.JPasswordField ivjDave_the_JPasswordField = null;
/**
 * MBTJPasswordField constructor comment.
 */
public MBTJPasswordField() {
	super();
	initialize();
}
/**
 * MBTJPasswordField constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJPasswordField(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJPasswordField constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJPasswordField(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJPasswordField constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJPasswordField(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JPasswordField property value.
 * @return javax.swing.JPasswordField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JPasswordField getDave_the_JPasswordField() {
	if (ivjDave_the_JPasswordField == null) {
		try {
			javax.swing.text.DefaultCaret ivjLocalCaret;
			ivjLocalCaret = new javax.swing.text.DefaultCaret();
			ivjLocalCaret.setBlinkRate(20);
			ivjLocalCaret.setVisible(true);
			ivjLocalCaret.setSelectionVisible(false);
			ivjDave_the_JPasswordField = new javax.swing.JPasswordField();
			ivjDave_the_JPasswordField.setName("Dave_the_JPasswordField");
			ivjDave_the_JPasswordField.setCaret(ivjLocalCaret);
			ivjDave_the_JPasswordField.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JPasswordField.setColumns(10);
			ivjDave_the_JPasswordField.setEditable(true);
			ivjDave_the_JPasswordField.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JPasswordField.setRequestFocusEnabled(false);
			ivjDave_the_JPasswordField.setCursor(new java.awt.Cursor(java.awt.Cursor.MOVE_CURSOR));
			ivjDave_the_JPasswordField.setOpaque(true);
			ivjDave_the_JPasswordField.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JPasswordField.setForeground(java.awt.Color.red);
			ivjDave_the_JPasswordField.setDocument(new javax.swing.text.PlainDocument());
			ivjDave_the_JPasswordField.setFont(new java.awt.Font("serif", 1, 12));
			ivjDave_the_JPasswordField.setEnabled(true);
			ivjDave_the_JPasswordField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
			ivjDave_the_JPasswordField.setToolTipText("Rosebud");
			ivjDave_the_JPasswordField.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JPasswordField.setDoubleBuffered(true);
			ivjDave_the_JPasswordField.setCaretColor(java.awt.Color.orange);
			ivjDave_the_JPasswordField.setSelectionEnd(0);
			ivjDave_the_JPasswordField.setMargin(new java.awt.Insets(0, 0, 0, 5));
			ivjDave_the_JPasswordField.setSelectedTextColor(java.awt.Color.yellow);
			ivjDave_the_JPasswordField.setSelectionColor(java.awt.Color.cyan);
			ivjDave_the_JPasswordField.setSelectionStart(0);
			ivjDave_the_JPasswordField.setAutoscrolls(false);
			ivjDave_the_JPasswordField.setEchoChar('X');
			ivjDave_the_JPasswordField.setBackground(java.awt.Color.green);
			ivjDave_the_JPasswordField.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JPasswordField.setCaretPosition(0);
			ivjDave_the_JPasswordField.setDisabledTextColor(java.awt.Color.blue);
			ivjDave_the_JPasswordField.setPreferredSize(new java.awt.Dimension(100, 30));
			ivjDave_the_JPasswordField.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JPasswordField;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJPasswordField");
		setOpaque(true);
		setLayout(new java.awt.FlowLayout());
		setSize(160, 120);
		add(getDave_the_JPasswordField(), getDave_the_JPasswordField().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJPasswordField aMBTJPasswordField;
		aMBTJPasswordField = new MBTJPasswordField();
		frame.setContentPane(aMBTJPasswordField);
		frame.setSize(aMBTJPasswordField.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
