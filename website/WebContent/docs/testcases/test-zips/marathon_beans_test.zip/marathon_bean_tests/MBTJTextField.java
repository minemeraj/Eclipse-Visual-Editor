package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (3/28/2002 2:42:48 PM)
 * @author: Administrator
 */
public class MBTJTextField extends javax.swing.JPanel {
	private javax.swing.JTextField ivjDave_the_JTextField = null;
/**
 * MBTJTextField constructor comment.
 */
public MBTJTextField() {
	super();
	initialize();
}
/**
 * MBTJTextField constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJTextField(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJTextField constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJTextField(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJTextField constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJTextField(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getDave_the_JTextField() {
	if (ivjDave_the_JTextField == null) {
		try {
			javax.swing.text.DefaultCaret ivjLocalCaret;
			ivjLocalCaret = new javax.swing.text.DefaultCaret();
			ivjLocalCaret.setBlinkRate(10);
			ivjLocalCaret.setVisible(true);
			ivjDave_the_JTextField = new javax.swing.JTextField();
			ivjDave_the_JTextField.setName("Dave_the_JTextField");
			ivjDave_the_JTextField.setCaret(ivjLocalCaret);
			ivjDave_the_JTextField.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JTextField.setColumns(10);
			ivjDave_the_JTextField.setEditable(false);
			ivjDave_the_JTextField.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JTextField.setRequestFocusEnabled(false);
			ivjDave_the_JTextField.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
			ivjDave_the_JTextField.setOpaque(false);
			ivjDave_the_JTextField.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JTextField.setText("This is a JTextField");
			ivjDave_the_JTextField.setForeground(java.awt.Color.white);
			ivjDave_the_JTextField.setDocument(new javax.swing.text.PlainDocument());
			ivjDave_the_JTextField.setFont(new java.awt.Font("dialog", 2, 12));
			ivjDave_the_JTextField.setEnabled(false);
			ivjDave_the_JTextField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
			ivjDave_the_JTextField.setToolTipText("Write here.");
			ivjDave_the_JTextField.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JTextField.setHighlighter(new javax.swing.text.DefaultHighlighter());
			ivjDave_the_JTextField.setDoubleBuffered(true);
			ivjDave_the_JTextField.setCaretColor(java.awt.Color.green);
			ivjDave_the_JTextField.setMargin(new java.awt.Insets(0, 0, 0, 1));
			ivjDave_the_JTextField.setSelectedTextColor(java.awt.Color.red);
			ivjDave_the_JTextField.setSelectionColor(java.awt.Color.magenta);
			ivjDave_the_JTextField.setAutoscrolls(false);
			ivjDave_the_JTextField.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JTextField.setDisabledTextColor(java.awt.Color.blue);
			ivjDave_the_JTextField.setPreferredSize(new java.awt.Dimension(110, 20));
			ivjDave_the_JTextField.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JTextField;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJTextField");
		setLayout(new java.awt.FlowLayout());
		setSize(160, 120);
		add(getDave_the_JTextField(), getDave_the_JTextField().getName());
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJTextField aMBTJTextField;
		aMBTJTextField = new MBTJTextField();
		frame.setContentPane(aMBTJTextField);
		frame.setSize(aMBTJTextField.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
