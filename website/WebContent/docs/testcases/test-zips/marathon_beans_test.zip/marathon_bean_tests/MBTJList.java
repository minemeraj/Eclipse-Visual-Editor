package marathon_bean_tests;

/**
 * Insert the type's description here.
 * Creation date: (4/1/2002 11:37:32 AM)
 * @author: Administrator
 */
public class MBTJList extends javax.swing.JPanel {
	private javax.swing.JList ivjDave_the_JList = null;
/**
 * MBTJList constructor comment.
 */
public MBTJList() {
	super();
	initialize();
}
/**
 * MBTJList constructor comment.
 * @param layout java.awt.LayoutManager
 */
public MBTJList(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * MBTJList constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public MBTJList(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * MBTJList constructor comment.
 * @param isDoubleBuffered boolean
 */
public MBTJList(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Return the Dave_the_JList property value.
 * @return javax.swing.JList
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JList getDave_the_JList() {
	if (ivjDave_the_JList == null) {
		try {
			javax.swing.DefaultListCellRenderer ivjLocalCellRenderer;
			ivjLocalCellRenderer = new javax.swing.DefaultListCellRenderer();
			ivjLocalCellRenderer.setName("LocalCellRenderer");
			ivjLocalCellRenderer.setAutoscrolls(true);
			ivjLocalCellRenderer.setCursor(new java.awt.Cursor(java.awt.Cursor.WAIT_CURSOR));
			ivjDave_the_JList = new javax.swing.JList();
			ivjDave_the_JList.setName("Dave_the_JList");
			ivjDave_the_JList.setModel(new javax.swing.DefaultListModel());
			ivjDave_the_JList.setComponentOrientation(java.awt.ComponentOrientation.LEFT_TO_RIGHT);
			ivjDave_the_JList.setSelectedIndex(1);
			int ivjLocal44selectedIndices [] = {
				1,
				2};
			ivjDave_the_JList.setSelectedIndices(ivjLocal44selectedIndices);
			ivjDave_the_JList.setMinimumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JList.setSelectionBackground(new java.awt.Color(204,101,255));
			ivjDave_the_JList.setRequestFocusEnabled(false);
			ivjDave_the_JList.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
			ivjDave_the_JList.setBorder(new javax.swing.border.EtchedBorder());
			ivjDave_the_JList.setForeground(java.awt.Color.red);
			ivjDave_the_JList.setFont(new java.awt.Font("sansserif", 2, 12));
			ivjDave_the_JList.setToolTipText("Pick a value.");
			ivjDave_the_JList.setFixedCellWidth(-1);
			ivjDave_the_JList.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
			ivjDave_the_JList.setCellRenderer(ivjLocalCellRenderer);
			ivjDave_the_JList.setDoubleBuffered(true);
			ivjDave_the_JList.setFixedCellHeight(-1);
			ivjDave_the_JList.setVisibleRowCount(5);
			ivjDave_the_JList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
			ivjDave_the_JList.setAutoscrolls(false);
			ivjDave_the_JList.setSelectionForeground(java.awt.Color.green);
			ivjDave_the_JList.setBackground(new java.awt.Color(0,173,208));
			ivjDave_the_JList.setMaximumSize(new java.awt.Dimension(200, 200));
			ivjDave_the_JList.setPreferredSize(new java.awt.Dimension(50, 50));
			ivjDave_the_JList.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
			// user code begin {1}
			javax.swing.DefaultListModel model = new javax.swing.DefaultListModel();
			model.addElement( "First item." );
			model.addElement( "Second item." );
			ivjDave_the_JList.setModel( model );
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjDave_the_JList;
}

/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("MBTJList");
		setLayout(new java.awt.BorderLayout());
		setSize(160, 120);
		add(getDave_the_JList(), "Center");
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		MBTJList aMBTJList;
		aMBTJList = new MBTJList();
		frame.setContentPane(aMBTJList);
		frame.setSize(aMBTJList.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}
