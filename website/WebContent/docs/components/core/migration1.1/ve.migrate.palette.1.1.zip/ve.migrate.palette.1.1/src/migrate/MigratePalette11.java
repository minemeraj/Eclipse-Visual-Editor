/*******************************************************************************
 * Copyright (c) 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
/*
 *  $RCSfile: $
 *  $Revision: $  $Date: $ 
 */
package migrate;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import org.eclipse.ve.internal.cdm.CDMPackage;

import org.eclipse.ve.internal.cde.decorators.DecoratorsPackage;
import org.eclipse.ve.internal.cde.palette.*;
import org.eclipse.ve.internal.cde.utility.UtilityPackage;
 

/**
 * This is used to migrate the ve palette from 1.0 to 1.1 format.
 * <p>
 * This assumes that no new container classes have been used, only the 
 * old container classes. This is because we are looking only for old format containers.
 * New format containers, if found, will be presumed to have valid new format content and 
 * no old format content and they will simply be copied as is.
 *  
 * @since 1.1.0
 */
public class MigratePalette11 {

	private static class MigrateData {
		Root root;
		AbstractToolEntry defaultEntry, oldDefaultEntry;
	}
	
	/**
	 * Main for migrate. 
	 * @param args each arg is a filename (local filesystem) that needs to be converted. They will be converted and
	 * the old file will be renamed to extension ".old" for backup.
	 * 
	 * @since 1.1.0
	 */
	public static void main(String[] args) {
		init();
		ResourceSet rset = new ResourceSetImpl();
		
		for (int i = 0; i < args.length; i++) {
			System.out.println("Converting \""+args[i]+"\".");
			if (!args[i].endsWith(".xmi")) {
				System.err.println("** File \""+args[i]+"\" is not an xmi file (doesn't have extension xmi).");
				continue;
			}
			File f = new File(args[i]);
			if (f.exists()) {
				try {
					String fPath = f.getCanonicalPath();
					URI fileURI = URI.createFileURI(fPath);
					XMIResource inRes = (XMIResource) rset.getResource(fileURI, true);
				
					// Now start the conversion.
					String newFileName = fPath+".new";
					URI newFile = URI.createFileURI(newFileName);
					XMIResource newRes = (XMIResource) rset.createResource(newFile);
					MigrateData migData = new MigrateData();
					PaletteFactory fact = PaletteFactory.eINSTANCE;
					EList newContents = newRes.getContents();
					List nonEntries = new ArrayList();
					for (Iterator resContents = inRes.getContents().iterator(); resContents.hasNext();) {
						Object resContent = resContents.next();
						if (resContent instanceof Entry) {
							Entry oldEntry = (Entry) resContent;
							newContents.add(migrateEntry(oldEntry, migData, fact));
						} else
							nonEntries.add(resContent);	// We can't move it yet because it would mess up the iterator.
					}
					// Copy the non entries across, copying their ids too.
					for (Iterator iter = nonEntries.iterator(); iter.hasNext();) {
						EObject nonEntry = (EObject) iter.next();
						String oldID = inRes.getID(nonEntry);
						newContents.add(nonEntry);
						if (oldID != null)
							newRes.setID(nonEntry, oldID);
					}
					
					newContents.addAll(nonEntries);
					if (migData.defaultEntry != null && migData.root != null) {
						migData.root.setDefEntry(migData.defaultEntry);
						String oldEntryID = inRes.getID(migData.oldDefaultEntry);
						if (oldEntryID != null)
							newRes.setID(migData.defaultEntry, oldEntryID);
						else
							newRes.setID(migData.defaultEntry, "default");
					}
					Map options = new HashMap();
					options.put(XMLResource.OPTION_ENCODING, "UTF-8");
					options.put(XMLResource.OPTION_USE_ENCODED_ATTRIBUTE_STYLE, Boolean.TRUE);
					options.put(XMLResource.OPTION_LINE_WIDTH, new Integer(100));
					
					// We rename old to backup name, and save this as old name.
					File backupFile = new File(fPath+".bak");
					if (backupFile.exists())
						backupFile.delete();
					f.renameTo(backupFile);
					rset.getResources().remove(inRes);	// This is so we can rename new to old.
					newRes.setURI(fileURI);
					newRes.save(options);
					System.out.println("Done converting \""+args[i]+"\".");
				} catch (IOException e) {
					e.printStackTrace();
				}				
			} else {
				System.err.println("** File \""+args[i]+"\" doesn't exist.");
			}
		}
		
		System.out.println("*** All files processed.");

	}
	
	private static Entry migrateEntry(Entry oldEntry, MigrateData migData, PaletteFactory fact) {
		Entry newEntry = null;
		switch (oldEntry.eClass().getClassifierID()) {
			case PalettePackage.PALETTE_CMP:
				newEntry = migData.root = fact.createRoot();
				copyEntryStuff(oldEntry, migData.root, migData);
				migrateChildren((Container) oldEntry, (Container) newEntry, migData, fact);
				break;
			case PalettePackage.GROUP_CMP:
				newEntry = fact.createGroup();
				copyEntryStuff(oldEntry, newEntry, migData);
				migrateChildren((Container) oldEntry, (Container) newEntry, migData, fact);
				break;
			case PalettePackage.CATEGORY_CMP:
				newEntry = fact.createDrawer();
				copyEntryStuff(oldEntry, newEntry, migData);
				// CategoryCmp is different because its children are groupCmps, but this is invalid in new structure, so we need
				// to migrate each group's children and treat as direct children of the drawer.
				EList groups = ((CategoryCmp) oldEntry).getCmpGroups();
				for (Iterator groupsItr = groups.iterator(); groupsItr.hasNext();) {
					Group group = (Group) groupsItr.next();
					migrateChildren(group, (Container) newEntry, migData, fact);
				}
				break;
			case PalettePackage.ANNOTATED_CREATION_ENTRY:
				// The object creation entry can't be another annotated creation entry, and all of the
				// other creation entries are valid as is.
				newEntry = (Entry) EcoreUtil.copy(((AnnotatedCreationEntry) oldEntry).getObjectCreationEntry());
				copyEntryStuff(oldEntry, newEntry, migData);
				((CreationToolEntry) newEntry).getKeyedValues().addAll(EcoreUtil.copyAll(((AnnotatedCreationEntry) oldEntry).getValues()));
				break;
			default:
				// Everything else is either a new type class, or is an old type that is still valid.
				// So just copy it.
				// However, need a test for toolentry to see if default and handle that.
				newEntry = (Entry) EcoreUtil.copy(oldEntry);
				if (oldEntry instanceof AbstractToolEntry && ((AbstractToolEntry) oldEntry).isDefaultEntry()) {
					migData.defaultEntry = (AbstractToolEntry) newEntry;
					migData.oldDefaultEntry = (AbstractToolEntry) oldEntry;
				}

				break;
		}
		return newEntry;
	}
	
	private static void migrateChildren(Container oldContainer, Container newContainer, MigrateData migData, PaletteFactory fact) {
		EList newChildren = newContainer.getChildren();
		for (Iterator children = oldContainer.getChildren().iterator(); children.hasNext();) {
			Entry child = (Entry) children.next();
			newChildren.add(migrateEntry(child, migData, fact));
		}
	}
	
	private static void copyEntryStuff(Entry oldEntry, Entry newEntry, MigrateData migData) {
		newEntry.setEntryLabel(oldEntry.getEntryLabel());
		newEntry.setEntryShortDescription(oldEntry.getEntryShortDescription());
		newEntry.setIcon16Name(oldEntry.getIcon16Name());
		newEntry.setIcon32Name(oldEntry.getIcon32Name());
		newEntry.setId(oldEntry.getId());
		newEntry.setModification(oldEntry.getModification());
		newEntry.setVisible(oldEntry.isVisible());
		if (oldEntry instanceof AbstractToolEntry && ((AbstractToolEntry) oldEntry).isDefaultEntry()) {
			migData.defaultEntry = (AbstractToolEntry) newEntry;
			migData.oldDefaultEntry = (AbstractToolEntry) oldEntry;
		}
	}
	
	private static void init() {
		EcorePackage e = EcorePackage.eINSTANCE;
		PalettePackage p = PalettePackage.eINSTANCE;
		UtilityPackage u = UtilityPackage.eINSTANCE;
		DecoratorsPackage d = DecoratorsPackage.eINSTANCE;
		CDMPackage c= CDMPackage.eINSTANCE;
		
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xmi", new XMIResourceFactoryImpl());
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("new", new XMIResourceFactoryImpl());
	}

}
