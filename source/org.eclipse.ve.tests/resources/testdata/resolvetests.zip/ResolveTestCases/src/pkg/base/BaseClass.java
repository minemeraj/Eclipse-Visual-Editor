/*******************************************************************************
 * Copyright (c) 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
/*
 *  $RCSfile: $
 *  $Revision: $  $Date: $ 
 */
package pkg.base;

import pkg1.sub1.FullImport0;
import pkg2.SuperClass;
import pkg1.sub1.sub2.*;
import pkg2.StarType0.*;
 

/**
 * Test class.
 * @since 1.0.0
 */
public class BaseClass extends SuperClass {
	
	public static class Inner0 {
		
	}
	public Class[] refs() {
		// This is just to get rid of unused imports warnings. This method isn't used for the tests.
		return new Class[] {FullImport0.class, StarSub2.class, InnerStarType0.class};
	}
}
