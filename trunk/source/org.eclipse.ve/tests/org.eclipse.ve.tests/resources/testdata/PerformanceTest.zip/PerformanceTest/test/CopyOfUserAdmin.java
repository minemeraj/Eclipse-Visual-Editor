package test;


import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.UIManager;
import javax.swing.table.TableModel;
/**
 * 
 *  This class represent a simple CRUD Registration application. 
 *
 */
public class CopyOfUserAdmin extends JFrame {


	private javax.swing.JPanel jContentPane = null;

	private javax.swing.JMenuBar jJMenuBar = null;
	private javax.swing.JMenu jMenu = null;
	private javax.swing.JMenu jMenu1 = null;
	private javax.swing.JScrollPane jScrollPane = null;
	private javax.swing.JTable quickPickTable = null;
	private javax.swing.JPanel centerPanel = null;
	private javax.swing.JPanel jButtonPane = null;
	private javax.swing.JTextField jTextField = null;
	private javax.swing.JTabbedPane jTabbedPane = null;
	private javax.swing.JScrollPane jScrollPane1 = null;
	private javax.swing.JPanel jPanel1 = null;
	private javax.swing.JPanel jPanel3 = null;
	private javax.swing.JLabel jLabel = null;
	private javax.swing.JTextField nameTextField = null;
	private javax.swing.JLabel jLabel1 = null;
	private javax.swing.JLabel jLabel2 = null;
	private javax.swing.JTextField emailTextField = null;
	private javax.swing.JLabel jLabel3 = null;
	private javax.swing.JTextField creditCardTextField = null;
	private javax.swing.JLabel jLabel4 = null;
	private javax.swing.JMenuItem jMenuItem = null;
	private javax.swing.JMenuItem jMenuItem1 = null;
	private javax.swing.JButton applyButton;
	private javax.swing.JButton revertButton;
	private TableModel tableModel;
	private javax.swing.JTextField jTypeTextField = null;
	private javax.swing.JMenuBar jJMenuBar1 = null;
	private javax.swing.JMenuItem jMenuItem2 = null;
	private javax.swing.JScrollPane jScrollPane2 = null;
	private javax.swing.JTable acctTable = null;
	private javax.swing.JToolBar jToolBar = null;
	private javax.swing.JButton jButton2 = null;
	private javax.swing.JButton jButton3 = null;
	private javax.swing.JPanel jPanel4 = null;
	private javax.swing.JLabel jLabel6 = null;
	private javax.swing.JTextField ShipAddr = null;
	private javax.swing.JTextField ShipCity = null;
	private javax.swing.JTextField ShipZip = null;
	private javax.swing.JPanel jContentPane1 = null;
	private javax.swing.JDialog addDialog = null;  //  @jve:decl-index=0:visual-constraint="357,583"
	private javax.swing.JPanel jPanel2 = null;
	private javax.swing.JButton addOKButton = null;
	private javax.swing.JButton addCancelButton = null;
	private javax.swing.JPanel jPanel5 = null;
	private javax.swing.JTextField addUserName = null;
	private javax.swing.JTextField addUserEmail = null;
	private javax.swing.JLabel jLabel8 = null;
	private javax.swing.JLabel jLabel9 = null;
	private javax.swing.JLabel jLabel10 = null;
	private JPasswordField passwordTextField = null;
	private JComboBox jComboBox = null;
	private JPanel jPanel = null;
	private JComboBox jComboBox2 = null;
	private JPanel jPanel6 = null;
	private JLabel connectedStatusLabel = null;
	private JLabel securityStatusLabel = null;
	private JLabel statusLabel = null;
	/**
	 * This is the default constructor
	 */
	public CopyOfUserAdmin() {
		super();
		initialize();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/test/group.gif")));
		this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
		this.setSize(445, 475);
		this.setContentPane(getJContentPane());
		this.setJMenuBar(getJJMenuBar());
		this.setTitle("User Administration");		
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new javax.swing.JPanel();
			jContentPane.setLayout(new java.awt.BorderLayout());
			jContentPane.add(getCenterPanel(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getJToolBar(), java.awt.BorderLayout.NORTH);
		}
		return jContentPane;
	}
	/**
	 * This method initializes jJMenuBar
	 * 
	 * @return javax.swing.JMenuBar
	 */
	private javax.swing.JMenuBar getJJMenuBar() {
		if(jJMenuBar == null) {
			jJMenuBar = new javax.swing.JMenuBar();
			jJMenuBar.add(getJMenu());
			jJMenuBar.add(getJMenu1());
		}
		return jJMenuBar;
	}
	/**
	 * This method initializes jMenu
	 * 
	 * @return javax.swing.JMenu
	 */
	private javax.swing.JMenu getJMenu() {
		if(jMenu == null) {
			jMenu = new javax.swing.JMenu();			
			jMenu.add(getJMenuItem2());
			jMenu.setText("File");
			jMenu.add(getJMenuItem());
		}
		return jMenu;
	}


	/**
	 * This method initializes jMenu1
	 * 
	 * @return javax.swing.JMenu
	 */
	private javax.swing.JMenu getJMenu1() {
		if(jMenu1 == null) {
			jMenu1 = new javax.swing.JMenu();
			jMenu1.add(getJMenuItem1());
			jMenu1.setText("Help");
		}
		return jMenu1;
	}
	/**
	 * This method initializes quickPickTable
	 * 
	 * @return javax.swing.JTable
	 */
	private javax.swing.JTable getQuickPickTable() {
		if(quickPickTable == null) {
			quickPickTable = new javax.swing.JTable();
			quickPickTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		}
		return quickPickTable;
	}

	/**
	 * This method initializes jScrollPane
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private javax.swing.JScrollPane getJScrollPane() {
		if(jScrollPane == null) {
			jScrollPane = new javax.swing.JScrollPane();
			jScrollPane.setViewportView(getQuickPickTable());
			jScrollPane.setMinimumSize(new java.awt.Dimension(100,100));
		}
		return jScrollPane;
	}
	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getCenterPanel() {
		if(centerPanel == null) {
			GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints22 = new GridBagConstraints();
			centerPanel = new javax.swing.JPanel();
			java.awt.GridBagConstraints consGridBagConstraints3 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints2 = new java.awt.GridBagConstraints();
			consGridBagConstraints3.insets = new java.awt.Insets(0,5,0,5);
			consGridBagConstraints3.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints3.weightx = 0.5D;
			consGridBagConstraints3.gridy = 0;
			consGridBagConstraints3.gridx = 1;
			consGridBagConstraints3.anchor = java.awt.GridBagConstraints.SOUTHWEST;
			consGridBagConstraints2.insets = new java.awt.Insets(7,5,0,5);
			consGridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
			consGridBagConstraints2.weighty = 2.0D;
			consGridBagConstraints2.weightx = 1.0;
			consGridBagConstraints2.gridwidth = 2;
			consGridBagConstraints2.gridy = 1;
			consGridBagConstraints2.gridx = 0;
			centerPanel.setLayout(new java.awt.GridBagLayout());
			centerPanel.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));
			consGridBagConstraints3.ipadx = 192;
			gridBagConstraints22.gridx = 0;
			gridBagConstraints22.gridy = 2;
			gridBagConstraints22.gridwidth = 2;
			gridBagConstraints22.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints22.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints7.gridx = 0;
			gridBagConstraints7.gridy = 0;
			gridBagConstraints7.weightx = 1.0;
			gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints7.insets = new java.awt.Insets(5,5,0,0);
			gridBagConstraints8.gridx = 0;
			gridBagConstraints8.gridy = 3;
			gridBagConstraints8.gridwidth = 2;
			gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
			centerPanel.add(getJScrollPane(), consGridBagConstraints2);
			centerPanel.add(getJTextField(), consGridBagConstraints3);
			centerPanel.add(getJPanel(), gridBagConstraints22);
			centerPanel.add(getJComboBox2(), gridBagConstraints7);
			centerPanel.add(getJPanel6(), gridBagConstraints8);
		}
		return centerPanel;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField() {
		if(jTextField == null) {
			jTextField = new javax.swing.JTextField();
			jTextField.setMinimumSize(new java.awt.Dimension(100,20));
		}
		return jTextField;
	}
	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private javax.swing.JTabbedPane getJTabbedPane() {
		if(jTabbedPane == null) {
			jTabbedPane = new javax.swing.JTabbedPane();
			jTabbedPane.setMinimumSize(new java.awt.Dimension(103,200));
			jTabbedPane.addTab("User", new ImageIcon(getClass().getResource("/test/online_overlay.gif")), getJScrollPane1(), null);
			jTabbedPane.addTab("Address", new ImageIcon(getClass().getResource("/test/directory.gif")), getJPanel4(), null);
			jTabbedPane.addTab("Accounts Payable", new ImageIcon(getClass().getResource("/test/alert_overlay.gif")), getJPanel1(), null);
		}
		return jTabbedPane;
	}
	private javax.swing.JPanel getButtonPane(){
		if(jButtonPane == null){
			jButtonPane = new javax.swing.JPanel();
			java.awt.FlowLayout layFlowLayout4 = new java.awt.FlowLayout();
			layFlowLayout4.setAlignment(java.awt.FlowLayout.RIGHT);
			jButtonPane.setLayout(layFlowLayout4);
			jButtonPane.add(getApplyButton());
			jButtonPane.add(getRevertButton());
		}
		return jButtonPane;
	}
	private javax.swing.JButton getApplyButton(){
		if(applyButton == null){
			applyButton = new javax.swing.JButton();
			applyButton.setText("Apply");
			applyButton.setIcon(new ImageIcon(getClass().getResource("/test/dynamicgroup.gif")));
			applyButton.setEnabled(false);
		}
		return applyButton;
	}
	//	 Store changes in this HashMap to allow undo of the changes
	private HashMap  undoMap = new HashMap();
	private JLabel numUsersStatusLabel = null;
	private JPanel jContentPane2 = null;
	private JDialog aboutDialog1 = null;  //  @jve:decl-index=0:visual-constraint="49,583"
	private JPanel jPanel7 = null;
	private JButton jButton = null;
	private JPanel jPanel8 = null;
	private JLabel jLabel5 = null;
	private JLabel jLabel7 = null;
	private JLabel jLabel11 = null;
	private javax.swing.JButton getRevertButton(){
		if(revertButton == null){
			revertButton = new javax.swing.JButton();
			revertButton.setText("Revert");
			revertButton.setIcon(new ImageIcon(getClass().getResource("/test/dnd_overlay.gif")));
		}
		return revertButton;
	}
	
	/**
	 * This method initializes jScrollPane1
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private javax.swing.JScrollPane getJScrollPane1() {
		if(jScrollPane1 == null) {
			jScrollPane1 = new javax.swing.JScrollPane();
			jScrollPane1.setViewportView(getJPanel3());
		}
		return jScrollPane1;
	}
	/**
	 * This method initializes jPanel1
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel1() {
		if(jPanel1 == null) {
			jPanel1 = new javax.swing.JPanel();
			jPanel1.setLayout(new java.awt.BorderLayout());
			jPanel1.add(getJScrollPane2(), java.awt.BorderLayout.CENTER);
		}
		return jPanel1;
	}
	/**
	 * This method initializes jPanel3
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJPanel3() {
		if(jPanel3 == null) {
			GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints20 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints19 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints18 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints17 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints16 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints15 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints13 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints12 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			jPanel3 = new javax.swing.JPanel();
			jPanel3.setLayout(new GridBagLayout());
			gridBagConstraints11.gridx = 0;
			gridBagConstraints11.gridy = 0;
			gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints11.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints12.gridx = 1;
			gridBagConstraints12.gridy = 0;
			gridBagConstraints12.weightx = 1.0;
			gridBagConstraints12.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints12.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints13.gridx = 0;
			gridBagConstraints13.gridy = 1;
			gridBagConstraints13.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints13.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints15.gridx = 1;
			gridBagConstraints15.gridy = 1;
			gridBagConstraints15.weightx = 1.0;
			gridBagConstraints15.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints15.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints16.gridx = 0;
			gridBagConstraints16.gridy = 2;
			gridBagConstraints16.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints16.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints17.gridx = 1;
			gridBagConstraints17.gridy = 2;
			gridBagConstraints17.weightx = 1.0;
			gridBagConstraints17.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints17.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints18.gridx = 0;
			gridBagConstraints18.gridy = 3;
			gridBagConstraints18.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints18.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints19.gridx = 1;
			gridBagConstraints19.gridy = 3;
			gridBagConstraints19.weightx = 1.0;
			gridBagConstraints19.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints19.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints20.gridx = 0;
			gridBagConstraints20.gridy = 4;
			gridBagConstraints20.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints20.insets = new java.awt.Insets(0,5,0,5);
			gridBagConstraints21.gridx = 1;
			gridBagConstraints21.gridy = 4;
			gridBagConstraints21.weightx = 1.0;
			gridBagConstraints21.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints21.insets = new java.awt.Insets(0,0,0,5);
			jPanel3.add(getJLabel(), gridBagConstraints11);
			jPanel3.add(getNameTextField(), gridBagConstraints12);
			jPanel3.add(getJLabel1(), gridBagConstraints13);
			jPanel3.add(getPasswordTextField(), gridBagConstraints15);
			jPanel3.add(getJLabel2(), gridBagConstraints16);
			jPanel3.add(getEMailTextField(), gridBagConstraints17);
			jPanel3.add(getJLabel3(), gridBagConstraints18);
			jPanel3.add(getCardNumberTextField(), gridBagConstraints19);
			jPanel3.add(getJLabel4(), gridBagConstraints20);
			jPanel3.add(getJTypeTextField(), gridBagConstraints21);
		}
		return jPanel3;
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setText(Long.toString(System.currentTimeMillis()));
		}
		return jLabel;
	}
	/**
	 * This method initializes jTypeTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getNameTextField() {
		if(nameTextField == null) {
			nameTextField = new javax.swing.JTextField();
		}
		return nameTextField;
	}
	/**
	 * This method initializes jLabel1
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel1() {
		if(jLabel1 == null) {
			jLabel1 = new javax.swing.JLabel();
			jLabel1.setText("Password");
		}
		return jLabel1;
	}
	/**
	 * This method initializes jLabel2
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel2() {
		if(jLabel2 == null) {
			jLabel2 = new javax.swing.JLabel();
			jLabel2.setText("Email");
		}
		return jLabel2;
	}
	/**
	 * This method initializes ShipState
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getEMailTextField() {
		if(emailTextField == null) {
			emailTextField = new javax.swing.JTextField();
		}
		return emailTextField;
	}
	/**
	 * This method initializes jLabel3
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel3() {
		if(jLabel3 == null) {
			jLabel3 = new javax.swing.JLabel();
			jLabel3.setText("Credit Card Number");
		}
		return jLabel3;
	}
	/**
	 * This method initializes ShipZip
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getCardNumberTextField() {
		if(creditCardTextField == null) {
			creditCardTextField = new javax.swing.JTextField();
		}
		return creditCardTextField;
	}
	/**
	 * This method initializes jLabel4
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel4() {
		if(jLabel4 == null) {
			jLabel4 = new javax.swing.JLabel();
			jLabel4.setText("Credit Card Type");
		}
		return jLabel4;
	}
	/**
	 * This method initializes jMenuItem
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private javax.swing.JMenuItem getJMenuItem() {
		if(jMenuItem == null) {
			jMenuItem = new javax.swing.JMenuItem();
			jMenuItem.setText("Exit");
			jMenuItem.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					System.exit(0);
				}
			});
		}
		return jMenuItem;
	}
	/**
	 * This method initializes jMenuItem1
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private javax.swing.JMenuItem getJMenuItem1() {
		if(jMenuItem1 == null) {
			jMenuItem1 = new javax.swing.JMenuItem();
			jMenuItem1.setText("About");
			jMenuItem1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					getAboutDialog1().show();
				}
			});
		}
		return jMenuItem1;
	}
	/**
	 * This method initializes jTypeTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTypeTextField() {
		if(jTypeTextField == null) {
			jTypeTextField = new javax.swing.JTextField();
		}
		return jTypeTextField;
	}
	/**
	 * This method initializes jMenuItem2
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private javax.swing.JMenuItem getJMenuItem2() {
		if(jMenuItem2 == null) {
			jMenuItem2 = new javax.swing.JMenuItem();
			jMenuItem2.setText("Save Changes Locally");
		}
		return jMenuItem2;
	}
	/**
	 * This method initializes acctTable
	 * 
	 * @return javax.swing.JTable
	 */
	private javax.swing.JTable getAcctTable() {
		if(acctTable == null) {
			acctTable = new javax.swing.JTable();			
			acctTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		}
		return acctTable;
	}
	/**
	 * This method initializes jScrollPane2
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private javax.swing.JScrollPane getJScrollPane2() {
		if(jScrollPane2 == null) {
			jScrollPane2 = new javax.swing.JScrollPane();
			jScrollPane2.setViewportView(getAcctTable());
		}
		return jScrollPane2;
	}
	/**
	 * This method initializes jToolBar
	 * 
	 * @return javax.swing.JToolBar
	 */
	private javax.swing.JToolBar getJToolBar() {
		if(jToolBar == null) {
			jToolBar = new javax.swing.JToolBar();
			jToolBar.add(getJButton2());
			jToolBar.addSeparator();
			jToolBar.add(getJButton3());
			jToolBar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.SoftBevelBorder.RAISED));
		}
		return jToolBar;
	}
	/**
	 * This method initializes jButton2
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton2() {
		if(jButton2 == null) {
			jButton2 = new javax.swing.JButton();
			jButton2.setText("Add user");
			jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));
			jButton2.setIcon(new ImageIcon(getClass().getResource("/test/add_user.gif")));
		}
		return jButton2;
	}
	/**
	 * This method initializes jButton3
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton3() {
		if(jButton3 == null) {
			jButton3 = new javax.swing.JButton();
			jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.gray,1));
			jButton3.setText("Delete user");
			jButton3.setIcon(new ImageIcon(getClass().getResource("/test/delete_user.gif")));
		}
		return jButton3;
	}
	/**
	 * This method initializes jPanel4	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private javax.swing.JPanel getJPanel4() {
		if (jPanel4 == null) {
			try {
				GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
				GridBagConstraints gridBagConstraints28 = new GridBagConstraints();
				GridBagConstraints gridBagConstraints26 = new GridBagConstraints();
				GridBagConstraints gridBagConstraints25 = new GridBagConstraints();
				GridBagConstraints gridBagConstraints24 = new GridBagConstraints();
				jPanel4 = new javax.swing.JPanel();
				jPanel4.setLayout(new GridBagLayout());
				gridBagConstraints24.gridx = 0;
				gridBagConstraints24.gridy = 0;
				gridBagConstraints24.anchor = java.awt.GridBagConstraints.WEST;
				gridBagConstraints24.insets = new java.awt.Insets(0,0,0,5);
				gridBagConstraints25.gridx = 1;
				gridBagConstraints25.gridy = 1;
				gridBagConstraints25.weightx = 1.0;
				gridBagConstraints25.fill = java.awt.GridBagConstraints.HORIZONTAL;
				gridBagConstraints25.gridwidth = 2;
				gridBagConstraints26.gridx = 1;
				gridBagConstraints26.gridy = 2;
				gridBagConstraints26.weightx = 1.0;
				gridBagConstraints26.fill = java.awt.GridBagConstraints.HORIZONTAL;
				gridBagConstraints28.gridx = 1;
				gridBagConstraints28.gridy = 3;
				gridBagConstraints28.weightx = 1.0;
				gridBagConstraints28.fill = java.awt.GridBagConstraints.HORIZONTAL;
				gridBagConstraints1.gridx = 2;
				gridBagConstraints1.gridy = 2;
				gridBagConstraints1.weightx = 1.0;
				gridBagConstraints1.fill = java.awt.GridBagConstraints.NONE;
				gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
				jPanel4.add(getJLabel6(), gridBagConstraints24);
				jPanel4.add(getShipAddr(), gridBagConstraints25);
				jPanel4.add(getShipCity(), gridBagConstraints26);
				jPanel4.add(getShipZip(), gridBagConstraints28);
				jPanel4.add(getJComboBox(), gridBagConstraints1);
			}
			catch (java.lang.Throwable e) {
				// TODO: Something
			}
		}
		return jPanel4;
	}
	/**
	 * This method initializes jLabel6	
	 * 	
	 * @return javax.swing.JLabel	
	 */    
	private javax.swing.JLabel getJLabel6() {
		if (jLabel6 == null) {
			try {
				jLabel6 = new javax.swing.JLabel();
				jLabel6.setText("Shipping Address:");
				jLabel6.setFont(new java.awt.Font("MS Sans Serif", java.awt.Font.BOLD, 11));
			}
			catch (java.lang.Throwable e) {
				// TODO: Something
			}
		}
		return jLabel6;
	}
	/**
	 * This method initializes ShipAddr	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private javax.swing.JTextField getShipAddr() {
		if (ShipAddr == null) {
			try {
				ShipAddr = new javax.swing.JTextField();
			}
			catch (java.lang.Throwable e) {
				// TODO: Something
			}
		}
		return ShipAddr;
	}
	/**
	 * This method initializes ShipCity	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private javax.swing.JTextField getShipCity() {
		if (ShipCity == null) {
			try {
				ShipCity = new javax.swing.JTextField();
			}
			catch (java.lang.Throwable e) {
				// TODO: Something
			}
		}
		return ShipCity;
	}
	/**
	 * This method initializes ShipZip	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private javax.swing.JTextField getShipZip() {
		if (ShipZip == null) {
			try {
				ShipZip = new javax.swing.JTextField();
			}
			catch (java.lang.Throwable e) {
				// TODO: Something
			}
		}
		return ShipZip;
	}
	/**
	 * This method initializes jContentPane1	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private javax.swing.JPanel getJContentPane1() {
		if (jContentPane1 == null) {
			jContentPane1 = new javax.swing.JPanel();
			jContentPane1.setLayout(new java.awt.BorderLayout());
			jContentPane1.add(getJPanel2(), java.awt.BorderLayout.SOUTH);
			jContentPane1.add(getJPanel5(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane1;
	}
	/**
	 * This method initializes jDialog	
	 * 	
	 * @return javax.swing.JDialog	
	 */    
	private javax.swing.JDialog getAddDialog() {
		if (addDialog == null) {
			addDialog = new javax.swing.JDialog();
			addDialog.setContentPane(getJContentPane1());
			addDialog.setSize(272, 178);
			addDialog.setModal(true);
			addDialog.setTitle("Add User");
			addDialog.setResizable(false);
		}
		return addDialog;
	}
	/**
	 * This method initializes jPanel2	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private javax.swing.JPanel getJPanel2() {
		if (jPanel2 == null) {
			jPanel2 = new javax.swing.JPanel();
			jPanel2.add(getAddOKButton(), null);
			jPanel2.add(getAddCancelButton(), null);
			jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
		}
		return jPanel2;
	}
	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */    
	private javax.swing.JButton getAddOKButton() {
		if (addOKButton == null) {
			addOKButton = new javax.swing.JButton();
			
			addOKButton.setText("OK");
			addOKButton.setEnabled(true);
			addOKButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					getAddDialog().setVisible(false);
				}
			});
		}
		return addOKButton;
	}
	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */    
	private javax.swing.JButton getAddCancelButton() {
		if (addCancelButton == null) {
			addCancelButton = new javax.swing.JButton();
			addCancelButton.setText("Cancel");
		}
		return addCancelButton;
	}
	/**
	 * This method initializes jPanel5	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private javax.swing.JPanel getJPanel5() {
		if (jPanel5 == null) {
			GridBagConstraints gridBagConstraints131 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints121 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints111 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
			jPanel5 = new javax.swing.JPanel();
			jPanel5.setLayout(new GridBagLayout());
			jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
			gridBagConstraints9.gridx = 0;
			gridBagConstraints9.gridy = 1;
			gridBagConstraints9.insets = new java.awt.Insets(0,10,0,10);
			gridBagConstraints10.gridx = 1;
			gridBagConstraints10.gridy = 1;
			gridBagConstraints10.weightx = 1.0;
			gridBagConstraints10.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints10.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints111.gridx = 0;
			gridBagConstraints111.gridy = 2;
			gridBagConstraints121.gridx = 1;
			gridBagConstraints121.gridy = 2;
			gridBagConstraints121.weightx = 1.0;
			gridBagConstraints121.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints121.insets = new java.awt.Insets(0,0,0,5);
			gridBagConstraints131.gridx = 0;
			gridBagConstraints131.gridy = 0;
			gridBagConstraints131.gridwidth = 2;
			gridBagConstraints131.anchor = java.awt.GridBagConstraints.WEST;
			gridBagConstraints131.fill = java.awt.GridBagConstraints.VERTICAL;
			gridBagConstraints131.insets = new java.awt.Insets(0,0,5,0);
			jPanel5.add(getJLabel8(), gridBagConstraints9);
			jPanel5.add(getAddUserName(), gridBagConstraints10);
			jPanel5.add(getJLabel9(), gridBagConstraints111);
			jPanel5.add(getAddUserEmail(), gridBagConstraints121);
			jPanel5.add(getJLabel10(), gridBagConstraints131);
		}
		return jPanel5;
	}
	/**
	 * This method initializes jTextField1	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private javax.swing.JTextField getAddUserName() {
		if (addUserName == null) {
			addUserName = new javax.swing.JTextField();
		}
		return addUserName;
	}
	/**
	 * This method initializes jTextField2	
	 * 	
	 * @return javax.swing.JTextField	
	 */    
	private javax.swing.JTextField getAddUserEmail() {
		if (addUserEmail == null) {
			addUserEmail = new javax.swing.JTextField();
		}
		return addUserEmail;
	}
	/**
	rn javax.swing.JLabel	
	 */    
	private javax.swing.JLabel getJLabel8() {
		if (jLabel8 == null) {
			jLabel8 = new javax.swing.JLabel();
			jLabel8.setText("Name");
		}
		return jLabel8;
	}
	/**
	 * This method initializes jLabel9	
	 * 	
	 * @return javax.swing.JLabel	
	 */    
	private javax.swing.JLabel getJLabel9() {
		if (jLabel9 == null) {
			jLabel9 = new javax.swing.JLabel();
			jLabel9.setText("Email");
		}
		return jLabel9;
	}
	/**
	 * This method initializes jLabel10	
	 * 	
	 * @return javax.swing.JLabel	
	 */    
	private javax.swing.JLabel getJLabel10() {
		if (jLabel10 == null) {
			jLabel10 = new javax.swing.JLabel();
			jLabel10.setText("Enter Minimal Information");
			jLabel10.setFont(new java.awt.Font("MS Sans Serif", java.awt.Font.BOLD, 11));
		}
		return jLabel10;
	}
	/**
	 * This method initializes passwordTextField	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */    
	private JPasswordField getPasswordTextField() {
		if (passwordTextField == null) {
			passwordTextField = new JPasswordField();
		}
		return passwordTextField;
	}
	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */    
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox();
		}
		return jComboBox;
	}
	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private JPanel getJPanel() {
		if (jPanel == null) {
			GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
			jPanel = new JPanel();
			jPanel.setLayout(new GridBagLayout());
			gridBagConstraints3.gridx = -1;
			gridBagConstraints3.gridy = -1;
			gridBagConstraints3.gridwidth = 1;
			gridBagConstraints3.weightx = 1.0;
			gridBagConstraints3.weighty = 1.0;
			gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints3.insets = new java.awt.Insets(0,0,0,0);
			gridBagConstraints5.gridx = 0;
			gridBagConstraints5.gridy = 1;
			gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints5.insets = new java.awt.Insets(0,0,0,0);
			jPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Modify user", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, null));
			jPanel.add(getJTabbedPane(), gridBagConstraints3);
			jPanel.add(getButtonPane(), gridBagConstraints5);
		}
		return jPanel;
	}
	/**
	 * This method initializes jComboBox2	
	 * 	
	 * @return javax.swing.JComboBox	
	 */    
	private JComboBox getJComboBox2() {
		if (jComboBox2 == null) {
			jComboBox2 = new JComboBox();
		}
		return jComboBox2;
	}
	/**
	 * This method initializes jPanel6	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private JPanel getJPanel6() {
		if (jPanel6 == null) {
			numUsersStatusLabel = new JLabel();
			numUsersStatusLabel.setText("No. users:");
			GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
			jPanel6 = new JPanel();
			statusLabel = new JLabel();
			GridBagConstraints gridBagConstraints221 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints23 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints241 = new GridBagConstraints();
			connectedStatusLabel = new JLabel();
			securityStatusLabel = new JLabel();
			connectedStatusLabel.setIcon(new ImageIcon(getClass().getResource("/test/connected.gif")));
			securityStatusLabel.setIcon(new ImageIcon(getClass().getResource("/test/secure.gif")));
			jPanel6.setLayout(new GridBagLayout());
			gridBagConstraints221.gridx = 1;
			gridBagConstraints221.gridy = 0;
			gridBagConstraints221.fill = java.awt.GridBagConstraints.HORIZONTAL;
			gridBagConstraints221.weightx = 1.0D;
			gridBagConstraints23.gridx = 2;
			gridBagConstraints23.gridy = 0;
			gridBagConstraints241.gridx = 3;
			gridBagConstraints241.gridy = 0;
			jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.black,1));
			gridBagConstraints2.gridx = 0;
			gridBagConstraints2.gridy = 0;
			jPanel6.add(statusLabel, gridBagConstraints221);
			jPanel6.add(connectedStatusLabel, gridBagConstraints23);
			jPanel6.add(securityStatusLabel, gridBagConstraints241);
			jPanel6.add(numUsersStatusLabel, gridBagConstraints2);
		}
		return jPanel6;
	}
	/**
	 * This method initializes jContentPane2	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private JPanel getJContentPane2() {
		if (jContentPane2 == null) {
			jContentPane2 = new JPanel();
			GridBagConstraints gridBagConstraints31 = new GridBagConstraints();
			GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
			jContentPane2.setLayout(new GridBagLayout());
			gridBagConstraints31.gridx = 0;
			gridBagConstraints31.gridy = 0;
			gridBagConstraints31.fill = java.awt.GridBagConstraints.BOTH;
			gridBagConstraints31.anchor = java.awt.GridBagConstraints.CENTER;
			gridBagConstraints31.weightx = 1.0D;
			gridBagConstraints31.weighty = 1.0D;
			gridBagConstraints4.gridx = 0;
			gridBagConstraints4.gridy = 1;
			gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
			jContentPane2.add(getJPanel7(), gridBagConstraints31);
			jContentPane2.add(getJPanel8(), gridBagConstraints4);
		}
		return jContentPane2;
	}
	/**
	 * This method initializes aboutDialog1	
	 * 	
	 * @return javax.swing.JDialog	
	 */    
	private JDialog getAboutDialog1() {
		if (aboutDialog1 == null) {
			aboutDialog1 = new JDialog();
			aboutDialog1.setContentPane(getJContentPane2());
			aboutDialog1.setSize(270, 170);
			aboutDialog1.setTitle("About User Admin");
			aboutDialog1.setModal(true);
		}
		return aboutDialog1;
	}
	/**
	 * This method initializes jPanel7	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private JPanel getJPanel7() {
		if (jPanel7 == null) {
			jLabel11 = new JLabel();
			GridBagConstraints gridBagConstraints81 = new GridBagConstraints();
			jLabel7 = new JLabel();
			GridBagConstraints gridBagConstraints71 = new GridBagConstraints();
			jLabel5 = new JLabel();
			GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
			jPanel7 = new JPanel();
			jPanel7.setLayout(new GridBagLayout());
			gridBagConstraints6.gridx = 0;
			gridBagConstraints6.gridy = 0;
			jLabel5.setText("Auction User Admin");
			jLabel5.setIcon(new ImageIcon(getClass().getResource("/test/publicgroup.gif")));
			jLabel5.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 18));
			gridBagConstraints71.gridx = 0;
			gridBagConstraints71.gridy = 1;
			jLabel7.setText("ACME Corp., Version 6.0");
			jLabel11.setText("<html><a href=\""+System.getProperty("auction.home")+"\">Auction Website</a><br>"+System.getProperty("auction.home")+"</html>");
			gridBagConstraints81.gridx = 0;
			gridBagConstraints81.gridy = 2;
			jPanel7.add(jLabel5, gridBagConstraints6);
			jPanel7.add(jLabel7, gridBagConstraints71);
			jPanel7.add(jLabel11, gridBagConstraints81);
		}
		return jPanel7;
	}
	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */    
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setText("OK");
			jButton.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					getAboutDialog1().hide();
				}
			});
		}
		return jButton;
	}
	/**
	 * This method initializes jPanel8	
	 * 	
	 * @return javax.swing.JPanel	
	 */    
	private JPanel getJPanel8() {
		if (jPanel8 == null) {
			FlowLayout flowLayout5 = new FlowLayout();
			jPanel8 = new JPanel();
			jPanel8.setLayout(flowLayout5);
			flowLayout5.setAlignment(java.awt.FlowLayout.RIGHT);
			jPanel8.add(getJButton(), null);
		}
		return jPanel8;
	}
        	public static void main(String[] argas) {		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		CopyOfUserAdmin ra = new CopyOfUserAdmin();
		ra.show();
	}
}  //  @jve:decl-index=0:visual-constraint="191,39"
