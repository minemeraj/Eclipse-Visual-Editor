/*
 * Created on Feb 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package test;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
/**
 * @author sgunturi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SWTUserAdmin {

	private org.eclipse.swt.widgets.Shell sShell = null;  //  @jve:decl-index=0:visual-constraint="88,13"
	private ToolBar toolBar = null;
	private Composite composite = null;
	private Combo combo = null;
	private Text text = null;
	private Table table = null;
	private TabFolder tabFolder = null;
	private Composite composite1 = null;
	private Composite composite2 = null;
	private Composite composite3 = null;
	private Label label = null;
	private Text text1 = null;
	private Label label1 = null;
	private Text text2 = null;
	private Label label2 = null;
	private Text text3 = null;
	private Label label3 = null;
	private Text text4 = null;
	private Label label4 = null;
	private Text text5 = null;
	private Label label5 = null;
	private Text text6 = null;
	private Text text7 = null;
	private Combo combo1 = null;
	private Text text8 = null;
	private Table table1 = null;
	private Composite composite4 = null;
	private Button button = null;
	private Button button1 = null;
	private Composite composite5 = null;
	private Label label6 = null;
	private Label label7 = null;
	private Label label8 = null;
	private Shell sShell1 = null;  //  @jve:decl-index=0:visual-constraint="83,490"
	private Button button2 = null;
	private Composite composite6 = null;
	private Label label9 = null;
	private Label label10 = null;
	private Label label11 = null;
	private Label label12 = null;
	private Shell sShell2 = null;  //  @jve:decl-index=0:visual-constraint="395,491"
	private Composite composite7 = null;
	private Button button3 = null;
	private Button button4 = null;
	private Label label13 = null;
	private Label label14 = null;
	private Text text9 = null;
	private Text text10 = null;
	private Label label15 = null;
	private Label label16 = null;
	private Label label17 = null;
	private Label label18 = null;
	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new org.eclipse.swt.widgets.Shell();		   
		GridLayout gridLayout3 = new GridLayout();
		createComposite();
		sShell.setText("User Administration");
		sShell.setLayout(gridLayout3);
		gridLayout3.numColumns = 1;
		sShell.setSize(new org.eclipse.swt.graphics.Point(531,458));
	}
	/**
	 * This method initializes toolBar	
	 *
	 */    
	private void createToolBar() {
		GridData gridData1 = new org.eclipse.swt.layout.GridData();
		toolBar = new ToolBar(composite, SWT.NONE);		   
		ToolItem toolItem = new ToolItem(toolBar, SWT.PUSH);
		ToolItem toolItem1 = new ToolItem(toolBar, SWT.PUSH);
		gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData1.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData1.grabExcessHorizontalSpace = true;
		gridData1.horizontalSpan = 2;
		toolBar.setLayoutData(gridData1);
		toolItem.setText("Add user");
		toolItem.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/add_user.gif")));
		toolItem1.setText("Delete user");
		toolItem1.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/delete_user.gif")));
	}
	/**
	 * This method initializes composite	
	 *
	 */    
	private void createComposite() {
		GridData gridData5 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout4 = new GridLayout();
		GridData gridData2 = new org.eclipse.swt.layout.GridData();
		composite = new Composite(sShell, SWT.NONE);		   
		createToolBar();
		createCombo();
		text = new Text(composite, SWT.BORDER);
		createTable();
		createTabFolder();
		createComposite4();
		createComposite5();
		gridData2.grabExcessHorizontalSpace = true;
		gridData2.grabExcessVerticalSpace = true;
		gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData2.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		composite.setLayoutData(gridData2);
		composite.setLayout(gridLayout4);
		gridLayout4.numColumns = 2;
		gridLayout4.verticalSpacing = 5;
		gridData5.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData5.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData5.grabExcessHorizontalSpace = true;
		text.setLayoutData(gridData5);
	}
	/**
	 * This method initializes combo	
	 *
	 */    
	private void createCombo() {
		combo = new Combo(composite, SWT.NONE);		   
	}
	/**
	 * This method initializes table	
	 *
	 */    
	private void createTable() {
		GridData gridData6 = new org.eclipse.swt.layout.GridData();
		table = new Table(composite, SWT.NONE);		   
		TableColumn tableColumn8 = new TableColumn(table, SWT.NONE);
		gridData6.grabExcessHorizontalSpace = true;
		gridData6.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData6.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData6.horizontalSpan = 2;
		gridData6.grabExcessVerticalSpace = true;
		table.setLayoutData(gridData6);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		tableColumn8.setText("Column A");
	}
	/**
	 * This method initializes tabFolder	
	 *
	 */    
	private void createTabFolder() {
		GridData gridData7 = new org.eclipse.swt.layout.GridData();
		tabFolder = new TabFolder(composite, SWT.NONE);		   
		createComposite1();
		createComposite2();
		TabItem tabItem10 = new TabItem(tabFolder, SWT.NONE);
		createComposite3();
		TabItem tabItem11 = new TabItem(tabFolder, SWT.NONE);
		TabItem tabItem12 = new TabItem(tabFolder, SWT.NONE);
		gridData7.horizontalSpan = 2;
		gridData7.grabExcessHorizontalSpace = true;
		gridData7.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData7.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData7.grabExcessVerticalSpace = true;
		tabFolder.setLayoutData(gridData7);
		tabItem10.setControl(composite1);
		tabItem10.setText("User");
		tabItem10.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/online_overlay.gif")));
		tabItem11.setControl(composite2);
		tabItem11.setText("Address");
		tabItem11.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/directory.gif")));
		tabItem12.setControl(composite3);
		tabItem12.setText("Accounts Payable");
		tabItem12.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/alert_overlay.gif")));
	}
	/**
	 * This method initializes composite1	
	 *
	 */    
	private void createComposite1() {
		GridData gridData8 = new org.eclipse.swt.layout.GridData();
		GridData gridData71 = new org.eclipse.swt.layout.GridData();
		GridData gridData61 = new org.eclipse.swt.layout.GridData();
		GridData gridData51 = new org.eclipse.swt.layout.GridData();
		GridData gridData4 = new org.eclipse.swt.layout.GridData();
		GridData gridData3 = new org.eclipse.swt.layout.GridData();
		GridData gridData21 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout1 = new GridLayout();
		composite1 = new Composite(tabFolder, SWT.NONE);		   
		label = new Label(composite1, SWT.NONE);
		text1 = new Text(composite1, SWT.BORDER);
		label1 = new Label(composite1, SWT.NONE);
		text2 = new Text(composite1, SWT.BORDER);
		label2 = new Label(composite1, SWT.NONE);
		text3 = new Text(composite1, SWT.BORDER);
		label3 = new Label(composite1, SWT.NONE);
		text4 = new Text(composite1, SWT.BORDER);
		label4 = new Label(composite1, SWT.NONE);
		text5 = new Text(composite1, SWT.BORDER);
		label.setText("Name");
		label.setLayoutData(gridData8);
		composite1.setLayout(gridLayout1);
		gridLayout1.numColumns = 2;
		label1.setText("Password");
		label2.setText("Email");
		label3.setText("Credit Card Number");
		label4.setText("Credit Card Type");
		label4.setLayoutData(gridData71);
		gridData21.grabExcessHorizontalSpace = true;
		gridData21.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData21.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData21.grabExcessVerticalSpace = true;
		text5.setLayoutData(gridData21);
		gridData3.grabExcessHorizontalSpace = true;
		gridData3.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData3.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		text4.setLayoutData(gridData3);
		gridData4.grabExcessHorizontalSpace = true;
		gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		text3.setLayoutData(gridData4);
		gridData51.grabExcessHorizontalSpace = true;
		gridData51.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData51.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		text2.setLayoutData(gridData51);
		gridData61.grabExcessHorizontalSpace = true;
		gridData61.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData61.verticalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData61.grabExcessVerticalSpace = true;
		text1.setLayoutData(gridData61);
		gridData71.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData71.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData8.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData8.verticalAlignment = org.eclipse.swt.layout.GridData.END;
	}
	/**
	 * This method initializes composite2	
	 *
	 */    
	private void createComposite2() {
		GridData gridData13 = new org.eclipse.swt.layout.GridData();
		GridData gridData12 = new org.eclipse.swt.layout.GridData();
		GridData gridData11 = new org.eclipse.swt.layout.GridData();
		GridData gridData10 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout9 = new GridLayout();
		composite2 = new Composite(tabFolder, SWT.NONE);		   
		label5 = new Label(composite2, SWT.NONE);
		text6 = new Text(composite2, SWT.BORDER);
		text7 = new Text(composite2, SWT.BORDER);
		createCombo1();
		text8 = new Text(composite2, SWT.BORDER);
		label5.setText("Shipping Address:");
		label5.setLayoutData(gridData10);
		composite2.setLayout(gridLayout9);
		gridLayout9.numColumns = 3;
		gridData10.horizontalSpan = 3;
		gridData10.grabExcessVerticalSpace = true;
		gridData10.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData10.verticalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData11.horizontalSpan = 3;
		gridData11.grabExcessVerticalSpace = false;
		gridData11.grabExcessHorizontalSpace = true;
		gridData11.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData11.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		text6.setLayoutData(gridData11);
		gridData12.horizontalSpan = 2;
		gridData12.grabExcessHorizontalSpace = true;
		gridData12.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData12.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		text7.setLayoutData(gridData12);
		gridData13.horizontalSpan = 2;
		gridData13.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData13.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData13.grabExcessHorizontalSpace = true;
		gridData13.grabExcessVerticalSpace = true;
		text8.setLayoutData(gridData13);
	}
	/**
	 * This method initializes composite3	
	 *
	 */    
	private void createComposite3() {
		composite3 = new Composite(tabFolder, SWT.NONE);		   
		createTable1();
		composite3.setLayout(new FillLayout());
	}
	/**
	 * This method initializes combo1	
	 *
	 */    
	private void createCombo1() {
		combo1 = new Combo(composite2, SWT.NONE);		   
	}
	/**
	 * This method initializes table1	
	 *
	 */    
	private void createTable1() {
		table1 = new Table(composite3, SWT.NONE);		   
		table1.setLinesVisible(true);
		table1.setHeaderVisible(true);
	}
	/**
	 * This method initializes composite4	
	 *
	 */    
	private void createComposite4() {
		GridData gridData16 = new org.eclipse.swt.layout.GridData();
		GridData gridData17 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout16 = new GridLayout();
		GridData gridData14 = new org.eclipse.swt.layout.GridData();
		composite4 = new Composite(composite, SWT.NONE);		   
		label17 = new Label(composite4, SWT.NONE);
		button = new Button(composite4, SWT.NONE);
		label18 = new Label(composite4, SWT.NONE);
		button1 = new Button(composite4, SWT.NONE);
		gridData14.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData14.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData14.grabExcessHorizontalSpace = true;
		gridData14.horizontalSpan = 2;
		composite4.setLayoutData(gridData14);
		composite4.setLayout(gridLayout16);
		button.setText("Apply");
		button.setLayoutData(gridData17);
		button1.setText("Revert");
		gridLayout16.numColumns = 4;
		gridLayout16.horizontalSpacing = 5;
		gridLayout16.verticalSpacing = 0;
		gridLayout16.marginWidth = 0;
		gridLayout16.marginHeight = 0;
		gridData17.grabExcessHorizontalSpace = false;
		gridData17.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData17.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		label17.setText("Label");
		label17.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/dynamicgroup.gif")));
		label17.setLayoutData(gridData16);
		label18.setText("Label");
		label18.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/dnd_overlay.gif")));
		gridData16.grabExcessHorizontalSpace = true;
		gridData16.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData16.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
	}
	/**
	 * This method initializes composite5	
	 *
	 */    
	private void createComposite5() {
		GridData gridData121 = new org.eclipse.swt.layout.GridData();
		GridData gridData20 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout19 = new GridLayout();
		GridData gridData18 = new org.eclipse.swt.layout.GridData();
		composite5 = new Composite(composite, SWT.NONE);		   
		label6 = new Label(composite5, SWT.NONE);
		label15 = new Label(composite5, SWT.NONE);
		label7 = new Label(composite5, SWT.NONE);
		label8 = new Label(composite5, SWT.NONE);
		composite5.setLayoutData(gridData18);
		composite5.setLayout(gridLayout19);
		label6.setText("No. users: ");
		label6.setLayoutData(gridData20);
		gridData18.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData18.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData18.grabExcessHorizontalSpace = true;
		gridData18.horizontalSpan = 2;
		label7.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/connected.gif")));
		label8.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/secure.gif")));
		gridLayout19.numColumns = 4;
		gridLayout19.horizontalSpacing = 0;
		gridLayout19.verticalSpacing = 0;
		gridLayout19.marginWidth = 0;
		gridLayout19.marginHeight = 0;
		gridData20.grabExcessHorizontalSpace = true;
		label15.setText("Status:");
		label15.setLayoutData(gridData121);
		gridData121.grabExcessHorizontalSpace = true;
	}
	/**
	 * This method initializes sShell1	
	 *
	 */    
	private void createSShell1() {
		sShell1 = new Shell(SWT.DIALOG_TRIM);	
		GridData gridData22 = new org.eclipse.swt.layout.GridData();
		createComposite6();
		button2 = new Button(sShell1, SWT.NONE);
		sShell1.setText("About User Admin");
		sShell1.setLayout(new GridLayout());
		gridData22.grabExcessHorizontalSpace = true;
		gridData22.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData22.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		button2.setLayoutData(gridData22);
		button2.setText("OK");
		sShell1.setSize(new org.eclipse.swt.graphics.Point(294,163));
		button2.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
			public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
				sShell1.setVisible(false);
			}
		});
	}
	/**
	 * This method initializes composite6	
	 *
	 */    
	private void createComposite6() {
		GridData gridData141 = new org.eclipse.swt.layout.GridData();
		GridData gridData72 = new org.eclipse.swt.layout.GridData();
		GridData gridData62 = new org.eclipse.swt.layout.GridData();
		GridData gridData52 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout41 = new GridLayout();
		GridData gridData15 = new org.eclipse.swt.layout.GridData();
		composite6 = new Composite(sShell1, SWT.NONE);		   
		label9 = new Label(composite6, SWT.NONE);
		label12 = new Label(composite6, SWT.NONE);
		label10 = new Label(composite6, SWT.NONE);
		label11 = new Label(composite6, SWT.NONE);
		gridData15.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData15.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData15.grabExcessHorizontalSpace = true;
		gridData15.grabExcessVerticalSpace = true;
		composite6.setLayoutData(gridData15);
		composite6.setLayout(gridLayout41);
		label9.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/test/publicgroup.gif")));
		label9.setLayoutData(gridData141);
		label10.setText("ACME Copr., Version 6.0");
		label10.setLayoutData(gridData52);
		label11.setText("Auction Website");
		label11.setLayoutData(gridData72);
		label12.setText("Auction User Admin");
		label12.setLayoutData(gridData62);
		gridLayout41.numColumns = 2;
		gridData52.horizontalSpan = 2;
		gridData52.grabExcessHorizontalSpace = false;
		gridData52.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData52.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData62.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData62.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData62.grabExcessHorizontalSpace = true;
		gridData62.horizontalSpan = 1;
		gridData72.horizontalSpan = 2;
		gridData72.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData72.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData72.grabExcessHorizontalSpace = false;
		gridData141.grabExcessHorizontalSpace = true;
		gridData141.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData141.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
	}
	/**
	 * This method initializes sShell2	
	 *
	 */    
	private void createSShell2() {
		sShell2 = new Shell(SWT.DIALOG_TRIM);		   
		GridLayout gridLayout11 = new GridLayout();
		GridData gridData63 = new org.eclipse.swt.layout.GridData();
		createComposite7();
		button4 = new Button(sShell2, SWT.NONE);
		button3 = new Button(sShell2, SWT.NONE);
		sShell2.setText("Add User");
		sShell2.setLayout(gridLayout11);
		gridLayout11.numColumns = 2;
		gridLayout11.makeColumnsEqualWidth = false;
		gridData63.grabExcessHorizontalSpace = true;
		gridData63.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData63.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		button4.setLayoutData(gridData63);
		button4.setText("OK");
		button3.setText("Cancel");
		sShell2.setSize(new org.eclipse.swt.graphics.Point(274,169));
		button3.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
			public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
				sShell2.setVisible(false);
			}
		});
		button4.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
			public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
				sShell2.setVisible(false);
			}
		});
	}
	/**
	 * This method initializes composite7	
	 *
	 */    
	private void createComposite7() {
		GridData gridData151 = new org.eclipse.swt.layout.GridData();
		GridData gridData111 = new org.eclipse.swt.layout.GridData();
		GridData gridData101 = new org.eclipse.swt.layout.GridData();
		GridData gridData9 = new org.eclipse.swt.layout.GridData();
		GridData gridData81 = new org.eclipse.swt.layout.GridData();
		GridLayout gridLayout7 = new GridLayout();
		GridData gridData23 = new org.eclipse.swt.layout.GridData();
		composite7 = new Composite(sShell2, SWT.NONE);		   
		label16 = new Label(composite7, SWT.NONE);
		label13 = new Label(composite7, SWT.NONE);
		text9 = new Text(composite7, SWT.BORDER);
		label14 = new Label(composite7, SWT.NONE);
		text10 = new Text(composite7, SWT.BORDER);
		gridData23.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData23.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData23.grabExcessHorizontalSpace = true;
		gridData23.horizontalSpan = 2;
		gridData23.grabExcessVerticalSpace = true;
		composite7.setLayoutData(gridData23);
		composite7.setLayout(gridLayout7);
		label13.setText("Name");
		label13.setLayoutData(gridData101);
		label14.setText("Email");
		label14.setLayoutData(gridData111);
		gridLayout7.numColumns = 2;
		gridData81.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData81.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData81.grabExcessHorizontalSpace = true;
		gridData81.grabExcessVerticalSpace = true;
		text10.setLayoutData(gridData81);
		gridData9.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData9.verticalAlignment = org.eclipse.swt.layout.GridData.END;
		gridData9.grabExcessHorizontalSpace = true;
		gridData9.grabExcessVerticalSpace = false;
		text9.setLayoutData(gridData9);
		gridData101.grabExcessVerticalSpace = false;
		gridData101.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData101.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		gridData111.grabExcessVerticalSpace = true;
		gridData111.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
		gridData111.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
		label16.setText("Enter Minimal information :");
		label16.setLayoutData(gridData151);
		gridData151.horizontalSpan = 2;
	}
   	/*
	 * Temporary main generation 
	 */    
	public static void main(String[] args) {
		// before you run this, make sure to set up the following in
		// the launch configuration (Arguments->VM Arguments) for the correct SWT lib. path
		// the following is a windows example,
		// -Djava.library.path="installation_directory\plugins\org.eclipse.swt.win32_3.0.1\os\win32\x86"
		org.eclipse.swt.widgets.Display display = org.eclipse.swt.widgets.Display.getDefault();		
		SWTUserAdmin test = new SWTUserAdmin();
		test.createSShell1() ;
		test.sShell1.open();
		test.createSShell() ;
		test.sShell.open();
		test.createSShell2() ;
		test.sShell2.open();
		
		while (!test.sShell1.isDisposed() && !test.sShell.isDisposed() && !test.sShell2.isDisposed()) {
			if (!display.readAndDispatch()) display.sleep ();
		}
		display.dispose();		
	}
         }
