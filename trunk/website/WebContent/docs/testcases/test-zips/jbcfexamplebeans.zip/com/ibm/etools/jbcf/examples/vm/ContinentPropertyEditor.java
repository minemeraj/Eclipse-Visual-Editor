package com.ibm.etools.jbcf.examples.vm;

import java.beans.*;

public class ContinentPropertyEditor extends PropertyEditorSupport {
	
	protected Continent fContinent;
	protected int fContinentIndex;
	
public String[] getTags(){
	return Continent.NAMES;
}

public void setValue(Object aContinent){
	fContinent = (Continent)aContinent;
}

public Object getValue(){
	return fContinent;
}

public String getAsText(){
	if ( fContinent == null ) {
		return null;
	} else {
		return fContinent.getName();
	}
}

public void setAsText(String aContinentName){
	for ( int i=0 ; i < Continent.CONTINENTS.length ; i++ ){
		if ( Continent.CONTINENTS[i].getName().equals(aContinentName) ){
			fContinent = Continent.CONTINENTS[i];
			return;
		}
	}
	throw new IllegalArgumentException(aContinentName + " is invalid");
}
public String getJavaInitializationString(){
	
	// For getting each continent back there is a static public field
	// on the Continent class that corresponds to each instance
	StringBuffer sb = new StringBuffer();
	sb.append("com.ibm.etools.ocjava.test.Continent.");
	sb.append(fContinent.getName().toUpperCase());
	return sb.toString();
}
}