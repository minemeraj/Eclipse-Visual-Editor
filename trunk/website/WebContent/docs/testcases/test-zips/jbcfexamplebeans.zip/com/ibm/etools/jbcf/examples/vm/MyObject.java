package com.ibm.etools.jbcf.examples.vm;

/**
 * Insert the type's description here.
 * Creation date: (2/2/00 11:08:41 AM)
 * @author: Joe Winchester
 */
public class MyObject {
/**
 * MyObject constructor comment.
 */
public MyObject() {
	super();
}
}
