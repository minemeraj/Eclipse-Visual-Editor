package com.ibm.etools.jbcf.examples.vm;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class DayCustomEditor extends Panel {
	
	protected int fDay;
	protected List fList;
	
public DayCustomEditor(int aDay){

	fDay = aDay;
	// Show the user a list of the available shapes with the current shape
	// selected	
	fList = new List();
	fList.setSize(100,40);
	for ( int i=0; i<DayHelper.DAY_NAMES.length ; i++){
		fList.add(DayHelper.DAY_NAMES[i]);
	}
	fList.select(fDay);
	add(fList);
	fList.addItemListener(new ItemListener(){
		public void itemStateChanged(ItemEvent event){
			fDay = fList.getSelectedIndex();
		}		
	});
	
}
/**
 * The shape is the selection index in the list
 */
public int getDay(){
	return fList.getSelectedIndex();
}
}