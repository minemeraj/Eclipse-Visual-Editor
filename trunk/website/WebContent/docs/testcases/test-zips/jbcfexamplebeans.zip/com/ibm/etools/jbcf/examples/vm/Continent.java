package com.ibm.etools.jbcf.examples.vm;


public class Continent {
	
	public static String[] NAMES = new String[] {"Europe","Asia","Africa","America","Australasia"};
	public static Continent[] CONTINENTS = new Continent[NAMES.length];
	static {
		for ( int i=0 ; i< NAMES.length ; i++ ) {
			CONTINENTS[i] = new Continent(NAMES[i]);
		}
	}
	public static Continent EUROPE = CONTINENTS[0];
	public static Continent ASIA = CONTINENTS[1];
	public static Continent AFRICA = CONTINENTS[2];
	public static Continent AMERICA = CONTINENTS[3];
	public static Continent AUSTRALASIA = CONTINENTS[4];
	
	protected String fName;
	
public Continent(String name){
	fName = name;
}
public String getName(){
	return fName;
}
public void setName(String aName){
	fName = aName;
}
}