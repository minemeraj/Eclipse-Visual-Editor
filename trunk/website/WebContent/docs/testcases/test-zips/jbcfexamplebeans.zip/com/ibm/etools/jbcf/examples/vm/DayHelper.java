package com.ibm.etools.jbcf.examples.vm;

public class DayHelper {

	public final static int SUNDAY = 0;
	public final static int MONDAY = 1;
	public final static int TUESDAY= 2;
	public final static int WEDNESDAY = 3;
	public final static int THURSDAY = 4;
	public final static int FRIDAY = 5;
	public final static int SATURDAY = 6;	
	
	public final static String[] DAY_NAMES = new String[] { 
		"Sunday",		
		"Monday" , 
		"Tuesday" ,
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday",
		};
	public final static String[] INIT_STRINGS = new String[] { 
		"com.ibm.etools.jbcf.examples.vm.DayHelper.SUNDAY" ,		
		"com.ibm.etools.jbcf.examples.vm.DayHelper.MONDAY" ,
		"com.ibm.etools.jbcf.examples.vm.DayHelper.TUESDAY" ,
		"com.ibm.etools.jbcf.examples.vm.DayHelper.WEDNESDAY" ,
		"com.ibm.etools.jbcf.examples.vm.DayHelper.THURSDAY" ,
		"com.ibm.etools.jbcf.examples.vm.DayHelper.FRIDAY" ,
		"com.ibm.etools.jbcf.examples.vm.DayHelper.SATURDAY" ,
		};	

public static int getDayIndex(String text){
	loop1: for (int i = 0; i < DAY_NAMES.length ; i++){
		if ( DAY_NAMES[i].equals(text)) {
			return i;
		}
	}
	throw new IllegalArgumentException("Value must be a day of the week");	
}
}