package com.ibm.etools.jbcf.examples.vm;


public class ShapeHelper {
	
	public final static String[] fShapeNames = new String[] { "None" , "Oval" , "Diamond" };
	public final static Integer[] fShapeValues = new Integer[] { new Integer(0) , new Integer(1) , new Integer(2) };
	public final static String[] fInitStrings = new String[] { 
		"com.ibm.etools.jbcf.examples.vm.Area.NO_SHAPE" ,
		"com.ibm.etools.jbcf.examples.vm.Area.OVAL" , 
		"com.ibm.etools.jbcf.examples.vm.Area.DIAMOND" };
	

public static int getShapeIndex(String text){
	loop1: for (int i = 0; i < fShapeNames.length ; i++){
		if ( fShapeNames[i].equals(text)) {
			return i;
		}
	}
	throw new IllegalArgumentException("Value must be None, Oval or Diamond");	
}
}