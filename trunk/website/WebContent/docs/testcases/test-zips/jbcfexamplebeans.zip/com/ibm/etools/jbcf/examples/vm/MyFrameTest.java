package com.ibm.etools.jbcf.examples.vm;

/**
 * Test class for Frame compostion.
 * Creation date: (11/23/99 11:45:57 AM)
 * @author: Joe Winchester
 */
public class MyFrameTest {
/**
 * MyFrameTest constructor comment.
 */
public MyFrameTest() {
	super();
}
}
