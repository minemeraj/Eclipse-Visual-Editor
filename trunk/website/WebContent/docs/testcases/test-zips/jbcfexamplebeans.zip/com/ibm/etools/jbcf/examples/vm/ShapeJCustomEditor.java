package com.ibm.etools.jbcf.examples.vm;

import javax.swing.*;
import java.beans.*;

public class ShapeJCustomEditor extends JPanel {
	
	protected int fShape;
	protected JList fList;
	
public ShapeJCustomEditor(int aShape){

	fShape = aShape;
	// Show the user a list of the available shapes with the current shape
	// selected	
	DefaultListModel model = new DefaultListModel();	
	fList = new JList(model);
	fList.setSize(100,40);
	for ( int i=0; i<ShapeHelper.fShapeNames.length ; i++){
		model.add(i,ShapeHelper.fShapeNames[i]);
	}
	fList.setSelectedIndex(fShape);
	JScrollPane scrollPane = new JScrollPane(fList);
	add(scrollPane);		
}
/**
 * The shape is the selection index in the list
 */
public int getShape(){
	return fList.getSelectedIndex();
}
}