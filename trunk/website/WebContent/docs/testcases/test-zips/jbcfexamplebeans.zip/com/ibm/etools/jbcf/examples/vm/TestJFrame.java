package com.ibm.etools.jbcf.examples.vm;

/**
 * Insert the type's description here.
 * Creation date: (8/28/2000 3:48:09 PM)
 * @author: Administrator
 */
public class TestJFrame extends javax.swing.JFrame {
/**
 * TestJFrame constructor comment.
 */
public TestJFrame() {
	super();
}
/**
 * TestJFrame constructor comment.
 * @param arg1 java.lang.String
 */
public TestJFrame(String arg1) {
	super(arg1);
}
}
