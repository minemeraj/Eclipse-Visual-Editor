package com.ibm.etools.jbcf.examples.vm;

import java.beans.PropertyEditorManager;
/**
 * Initialize a test environment with some property editors
 * NOTE - This will be done through a plugin extension point at some time in the future
 */
public class Environment {
	
public static void initialize(){

	PropertyEditorManager.registerEditor(Continent.class,ContinentPropertyEditor.class);
	
}

}