package com.ibm.etools.jbcf.examples.vm;

import java.awt.*;

/**
 * Insert the type's description here.
 * Creation date: (11/15/99 6:27:21 PM)
 * @author: Joe Winchester
 */
public class MyFrame extends Frame {
/**
 * MyFrame constructor comment.
 */
public MyFrame() {
	super();
}
/**
 * MyFrame constructor comment.
 * @param title java.lang.String
 */
public MyFrame(String title) {
	super(title);
}
}
