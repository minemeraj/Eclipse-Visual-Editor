package com.ibm.etools.jbcf.examples.vm;

import java.beans.*;
/**
 * Insert the type's description here.
 * Creation date: (07/11/00 10:16:39 AM)
 * @author: Joe Winchester
 */
public class ButtonBarBeanInfo extends SimpleBeanInfo {
/**
 * Get the bean descriptor with the customizer
 */
public BeanDescriptor getBeanDescriptor(){
	return new BeanDescriptor(ButtonBar.class,ButtonBarCustomizer.class);
}
}
