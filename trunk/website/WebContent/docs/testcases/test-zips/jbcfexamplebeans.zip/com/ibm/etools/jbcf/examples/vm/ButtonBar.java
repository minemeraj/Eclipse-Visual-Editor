package com.ibm.etools.jbcf.examples.vm;

import java.awt.FlowLayout;
/**
 * Insert the type's description here.
 * Creation date: (12/01/00 11:13:24 PM)
 * @author: Administrator
 */
public class ButtonBar extends java.awt.Panel {
/**
 * ButtonBarOne constructor comment.
 */
public ButtonBar() {
	super();
	setLayout(new FlowLayout(FlowLayout.LEFT,5,5));
}
}
