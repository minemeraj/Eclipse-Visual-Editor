package com.ibm.etools.jbcf.examples.vm;

import java.awt.*;
import java.beans.*;
/**
 * Property Editor that lets you edit days from 0-6 through
 * their strings
 */
public class MonthPropertyEditor extends PropertyEditorSupport {
	protected int fMonth;
	protected static String[] MONTHS = new String[] {
		"January","February","March","April","May","June","July","August","September","October","November","December"};
public void setAsText(String text) throws IllegalArgumentException {

	if(text != null) {
		for(int i=0;i<MONTHS.length;i++){
			if(MONTHS[i].toLowerCase().equals(text.toLowerCase())){
				fMonth = i;
				return;
			}
		}
	}
	// The month is not a valid one
	throw new IllegalArgumentException(text + " is not a valid month, e.g. January, Febryary, etc...");
}
public Object getValue(){
	return new Integer(fMonth);
}
public void setValue(Object aValue){
	fMonth = ((Integer)aValue).intValue();
}
public String getAsText(){
	return MONTHS[fMonth];
}
public String getJavaInitializationString(){
	return String.valueOf(fMonth);
}
}
