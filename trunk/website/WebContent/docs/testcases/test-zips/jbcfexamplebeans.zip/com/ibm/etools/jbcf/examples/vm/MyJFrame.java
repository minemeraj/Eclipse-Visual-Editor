package com.ibm.etools.jbcf.examples.vm;

/**
 * Insert the type's description here.
 * Creation date: (11/15/99 6:27:21 PM)
 * @author: Joe Winchester
 */
public class MyJFrame extends javax.swing.JFrame {
/**
 * MyFrame constructor comment.
 */
public MyJFrame() {
	super();
}
/**
 * MyFrame constructor comment.
 * @param title java.lang.String
 */
public MyJFrame(String title) {
	super(title);
}
}
