package com.ibm.etools.jbcf.examples.vm;

import java.awt.*;
import java.beans.*;
/**
 * Property Editor that lets you edit days from 0-6 through
 * their strings
 */
public class DayPropertyEditor extends PropertyEditorSupport {
	protected int fDay;
	protected DayCustomEditor fEditor;
public void setAsText(String text) throws IllegalArgumentException {

	for(int i=0;i<=6;i++){
		if(DayHelper.DAY_NAMES[i].equals(text)){
			fDay = i;
			return;
		}
	}
	// The day is not a valid one
	throw new IllegalArgumentException(text + " is not a valid weekday, e.g. Monday, Tuesday, etc...");
}
public Object getValue(){
	return new Integer(fDay);
}
public void setValue(Object aValue){
	fDay = ((Integer)aValue).intValue();
}
public String getAsText(){
	if ( fDay >= 0 || fDay <= 6 ) {
		return DayHelper.DAY_NAMES[fDay];
	} else {
		return "UNKNOWN";
	}
}
public String getJavaInitializationString(){
	return DayHelper.INIT_STRINGS[fDay];
}
public boolean supportsCustomEditor(){
	return true;
}
public Component getCustomEditor(){
	if (fEditor == null){
		fEditor = new DayCustomEditor(fDay);
	}
	return fEditor;
}
}
