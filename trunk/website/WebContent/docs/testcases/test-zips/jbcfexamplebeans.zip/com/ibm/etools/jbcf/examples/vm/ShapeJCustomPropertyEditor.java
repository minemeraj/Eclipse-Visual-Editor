package com.ibm.etools.jbcf.examples.vm;

import java.awt.*;

public class ShapeJCustomPropertyEditor extends AbstractShapeCustomPropertyEditor {

	protected ShapeJCustomEditor fCustomEditor;

public Component getCustomEditor(){
	fCustomEditor = new ShapeJCustomEditor(fShapeIndex);
	return fCustomEditor;
}
/**
 * Ask the custom editor for the value
 */
public Object getValue(){
	return fCustomEditor != null ? new Integer(fCustomEditor.getShape()) : null;
}

}