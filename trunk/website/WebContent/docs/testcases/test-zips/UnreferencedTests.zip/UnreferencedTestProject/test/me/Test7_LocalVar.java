package test.me;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;

public class Test7_LocalVar {

	private BookButton bookButton = null;  //  @jve:decl-index=0:visual-constraint="13,56"
	private CustomBook unusedVisualBookField; //  @jve:decl-index=0:visual-constraint=""
	private BookButton bookButton1 = null;  //  @jve:decl-index=0:visual-constraint="20,109"
	private CustomBook usedFieldBook = null;  //  @jve:decl-index=0:visual-constraint=""

	/**
	 * This method initializes bookButton	
	 * 	
	 * @return test.me.BookButton	
	 */
	private BookButton getBookButton() {
		if (bookButton == null) {
			bookButton = new BookButton();
			CustomBook unusedVisualBookLocalVar = new CustomBook();  //  @jve:decl-index=0:visual-constraint=""
			unusedVisualBookField = new CustomBook(); 
			bookButton.setSize(new java.awt.Dimension(256,41));
			bookButton.setBook(getUsedFieldBook());
		}
		return bookButton;
	}

	/**
	 * This method initializes bookButton1	
	 * 	
	 * @return test.me.BookButton	
	 */
	private BookButton getBookButton1() {
		if (bookButton1 == null) {
			bookButton1 = new BookButton();
			CustomBook usedLocalVarBook = new CustomBook(); 
			bookButton1.setSize(new java.awt.Dimension(253,37));
			bookButton1.setBook(usedLocalVarBook);
		}
		return bookButton1;
	}

	/**
	 * This method initializes customBook	
	 * 	
	 * @return test.me.CustomBook	
	 */
	private CustomBook getUsedFieldBook() {
		if (usedFieldBook == null) {
			usedFieldBook = new CustomBook();
		}
		return usedFieldBook;
	}

}
