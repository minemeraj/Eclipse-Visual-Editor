package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;

public class FormLayoutTest {

	private Shell sShell = null;
	private Button button = null;
	private FormAttachment bottomAttachment;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		FormLayout formLayout = new FormLayout();
		formLayout.marginHeight = 10;
		formLayout.marginWidth = 20;
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setLayout(formLayout);
		sShell.setSize(new Point(300, 200));
		button = new Button(sShell, SWT.NONE);
		FormData data = new FormData();
		FormAttachment topAttachment = new FormAttachment(0,12);
		data.top = topAttachment;
		bottomAttachment = new FormAttachment(100,-5);
		data.bottom = bottomAttachment;
		data.left = topAttachment;
		data.right = bottomAttachment;
		button.setLayoutData(data);
	}

}
