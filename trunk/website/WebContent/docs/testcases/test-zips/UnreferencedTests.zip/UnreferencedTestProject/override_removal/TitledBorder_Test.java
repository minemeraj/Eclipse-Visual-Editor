package override_removal;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class TitledBorder_Test extends JPanel {

	/**
	 * This is the default constructor
	 */
	public TitledBorder_Test() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		TitledBorder titleBorderVariable = javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.green,5), "Title border test", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Courier New", java.awt.Font.ITALIC, 18), java.awt.Color.red);
		this.setBorder(titleBorderVariable);
	}

}
