package test.me;

public class Test6_Unmodelled_Unref {

	private CustomBook customBook = null;  
	private CustomBook customBook1 = null;  //  
	private CustomBook customBook2 = null;  // @jve:decl-index=0:
	private CustomBook customBook3 = null;  // @jve:visual-constraint=""
	private CustomBook customBook4 = null;  // @jve:decl-index=0:visual-constraint=""
	private BookButton bookButton = null;  //  @jve:decl-index=0:visual-constraint="20,65"

	/**
	 * This method initializes customBook	
	 * 	
	 * @return test.me.CustomBook	
	 */
	private CustomBook getCustomBook() {
		if (customBook == null) {
			customBook = new CustomBook();
			customBook1 = new CustomBook();
			customBook2 = new CustomBook();
			customBook3 = new CustomBook();
			customBook4 = new CustomBook();
		}
		return customBook;
	}

	/**
	 * This method initializes bookButton	
	 * 	
	 * @return test.me.BookButton	
	 */
	private BookButton getBookButton() {
		if (bookButton == null) {
			CustomBook localCustomBook1 = new CustomBook(); 
			CustomBook localCustomBook2 = new CustomBook(); //
			CustomBook localCustomBook3 = new CustomBook(); //  @jve:decl-index=0:
			CustomBook localCustomBook4 = new CustomBook(); //  @jve:visual-constraint=""
			CustomBook localCustomBook5 = new CustomBook(); //  @jve:decl-index=0:visual-constraint=""
			bookButton = new BookButton();
			bookButton.setSize(326, 55);
			//bookButton.setBook(customBook);
		}
		return bookButton;
	}

}
