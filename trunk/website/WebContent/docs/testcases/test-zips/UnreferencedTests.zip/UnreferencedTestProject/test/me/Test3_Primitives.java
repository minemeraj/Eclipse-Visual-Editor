package test.me;

import javax.swing.JButton;

public class Test3_Primitives  {

	private JButton jButton = null;  //  @jve:decl-index=0:visual-constraint="125,98"
	private String title = null; 
	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */    
	private JButton getJButton() {
		if (jButton == null) {
			title = "Button title";
			jButton = new JButton();
			jButton.setSize(116, 34);
			//jButton.setText(title);
		}
		return jButton;
	}
}
