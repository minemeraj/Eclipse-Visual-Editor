package override_removal_swt;

import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;


public class Test_AbsCoAdDH_SWT {

	private Shell sShell = null;  //  @jve:decl-index=0:visual-constraint="36,28"
	private Composite composite = null;
	/**
	 * This method initializes sShell	
	 *
	 */
	private void createSShell() {
		sShell = new Shell();
		createComposite();
		sShell.setSize(new org.eclipse.swt.graphics.Point(261,181));
	}

	/**
	 * This method initializes composite	
	 *
	 */
	private void createComposite() {
		composite = new Composite(sShell, SWT.NONE);
		composite.setBounds(new org.eclipse.swt.graphics.Rectangle(36,21,179,101));
	}

	/*
	 * Temporary main generation 
	 */
	public static void main(String[] args) {
		// before you run this, make sure to set up the following in
		// the launch configuration (Arguments->VM Arguments) for the correct SWT lib. path
		// the following is a windows example,
		// -Djava.library.path="installation_directory\plugins\org.eclipse.swt.win32_3.0.1\os\win32\x86"
		org.eclipse.swt.widgets.Display display = org.eclipse.swt.widgets.Display
				.getDefault();
		Test_AbsCoAdDH_SWT test = new Test_AbsCoAdDH_SWT();
		test.createSShell();
		test.sShell.open();
	
		while (!test.sShell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
}
