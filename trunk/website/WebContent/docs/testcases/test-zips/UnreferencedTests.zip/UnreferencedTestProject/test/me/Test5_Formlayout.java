package test.me;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

public class Test5_Formlayout extends Composite {

	private Button button = null;
	private Text text = null;

	public Test5_Formlayout(Composite parent, int style) {
		super(parent, style);
		initialize();
	}

	private void initialize() {
		this.setLayout(new FormLayout());
		setSize(new Point(300, 200));
		text = new Text(this, SWT.BORDER);
		FormData data1 = new FormData();
		data1.left = new FormAttachment(11, 12);
		data1.top = new FormAttachment(13, 14);
		text.setLayoutData(data1);

		button = new Button(this, SWT.NONE);
		FormData data2 = new FormData();
		data2.left = new FormAttachment(text);
		data2.top = new FormAttachment(70, 0);
		data2.right = new FormAttachment(120, 0);
		button.setLayoutData(data2);
	}

}
