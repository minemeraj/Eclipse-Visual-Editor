package override_removal;

import javax.swing.JPanel;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;

public class FlowLayoutTest extends JPanel {

	private JButton jButton = null;
	private JLabel jLabel = null;

	/**
	 * This is the default constructor
	 */
	public FlowLayoutTest() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel = new JLabel();
		jLabel.setText("Layout");
		FlowLayout flowLayout = new FlowLayout();
		flowLayout.setHgap(10);
		flowLayout.setVgap(20);
		this.setLayout(flowLayout);
		this.setSize(300, 200);
		this.add(getJButton(), null);
		this.add(jLabel, null);
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setText("flow");
		}
		return jButton;
	}

}
