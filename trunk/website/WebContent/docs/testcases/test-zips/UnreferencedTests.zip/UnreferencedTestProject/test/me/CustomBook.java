package test.me;

import java.util.EventListener;

public class CustomBook {
private String author;
public CustomBook subBook;

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

public CustomBook getSubBook() {
	return subBook;
}

public void setSubBook(CustomBook subBook) {
	this.subBook = subBook;
}
public void addBookListener(BookListener l){}
public void removeBookListener(BookListener l){}
}
