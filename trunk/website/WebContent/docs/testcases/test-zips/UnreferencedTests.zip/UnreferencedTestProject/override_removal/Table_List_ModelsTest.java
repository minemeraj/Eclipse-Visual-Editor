package override_removal;

import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultListModel;
import javax.swing.DefaultComboBoxModel;

public class Table_List_ModelsTest {

	private DefaultTableModel defaultTableModel = null;  
	private DefaultListModel defaultListModel = null;  
	private DefaultComboBoxModel defaultComboBoxModel = null;  

	/**
	 * This method initializes defaultTableModel	
	 * 	
	 * @return javax.swing.table.DefaultTableModel	
	 */
	private DefaultTableModel getDefaultTableModel() {
		if (defaultTableModel == null) {
			defaultTableModel = new DefaultTableModel();
		}
		return defaultTableModel;
	}

	/**
	 * This method initializes defaultListModel	
	 * 	
	 * @return javax.swing.DefaultListModel	
	 */
	private DefaultListModel getDefaultListModel() {
		if (defaultListModel == null) {
			defaultListModel = new DefaultListModel();
		}
		return defaultListModel;
	}

	/**
	 * This method initializes defaultComboBoxModel	
	 * 	
	 * @return javax.swing.DefaultComboBoxModel	
	 */
	private DefaultComboBoxModel getDefaultComboBoxModel() {
		if (defaultComboBoxModel == null) {
			defaultComboBoxModel = new DefaultComboBoxModel();
		}
		return defaultComboBoxModel;
	}

}
