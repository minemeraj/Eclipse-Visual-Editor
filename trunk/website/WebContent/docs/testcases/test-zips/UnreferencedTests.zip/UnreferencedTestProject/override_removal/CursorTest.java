package override_removal;

import javax.swing.JPanel;

public class CursorTest extends JPanel {

	private JPanel jPanel = null;  //  @jve:decl-index=0:visual-constraint="336,27"
	private java.awt.Cursor NECURSOR;

	/**
	 * This is the default constructor
	 */
	public CursorTest() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		java.awt.Cursor handCursor = new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR);
		this.setCursor(handCursor);
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setSize(158, 237);
			NECURSOR = new java.awt.Cursor(java.awt.Cursor.N_RESIZE_CURSOR);
			jPanel.setCursor(NECURSOR);
		}
		return jPanel;
	}

}
