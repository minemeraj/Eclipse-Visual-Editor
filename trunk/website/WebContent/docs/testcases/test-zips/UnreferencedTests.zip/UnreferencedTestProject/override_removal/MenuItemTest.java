package override_removal;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.MenuItem;
import java.awt.Menu;

public class MenuItemTest {

	private MenuItem invisibleMenuItem1 = null;  
	private Menu menu = null;
	private JMenu jMenu = null;
	private JMenuItem jMenuItem = null;
	private JMenuItem standaloneJMenuItem1 = null;  
	/**
	 * This method initializes menuItem1	
	 * 	
	 * @return java.awt.MenuItem	
	 */
	private MenuItem getInvisibleMenuItem1() {
		if (invisibleMenuItem1 == null) {
			invisibleMenuItem1 = new MenuItem();
		}
		return invisibleMenuItem1;
	}

	/**
	 * This method initializes menu	
	 * 	
	 * @return java.awt.Menu	
	 */
	private Menu getMenu() {
		if (menu == null) {
			menu = new Menu();
		}
		return menu;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getJMenu() {
		if (jMenu == null) {
			jMenu = new JMenu();
			jMenu.setSize(new java.awt.Dimension(37,12));
			jMenu.add(getJMenuItem());
		}
		return jMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getJMenuItem() {
		if (jMenuItem == null) {
			jMenuItem = new JMenuItem();
		}
		return jMenuItem;
	}

	/**
	 * This method initializes jMenuItem1	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getStandaloneJMenuItem1() {
		if (standaloneJMenuItem1 == null) {
			standaloneJMenuItem1 = new JMenuItem();
			standaloneJMenuItem1.setSize(new java.awt.Dimension(8,8));
		}
		return standaloneJMenuItem1;
	}
}
