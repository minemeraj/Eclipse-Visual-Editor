package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.RowData;

public class RowLayout_RowData_Test {

	private Shell sShell = null;
	private Button button = null;
	private Label label = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		RowData rowData1 = new org.eclipse.swt.layout.RowData();
		rowData1.height = 150;
		RowData rowData = new org.eclipse.swt.layout.RowData();
		rowData.height = 100;
		RowLayout rowLayout = new RowLayout();
		rowLayout.fill = true;
		rowLayout.marginBottom = 4;
		rowLayout.justify = true;
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setLayout(rowLayout);
		sShell.setSize(new Point(300, 200));
		button = new Button(sShell, SWT.NONE);
		button.setText("RowLayout");
		button.setLayoutData(rowData);
		label = new Label(sShell, SWT.NONE);
		label.setText("Test");
		label.setLayoutData(rowData1);
	}

}
