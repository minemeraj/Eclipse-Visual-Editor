package override_removal;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class CheckboxGroupTest extends JFrame {

	private JPanel jContentPane = null;
	private Checkbox checkbox = null;
	private Checkbox checkbox1 = null;
	private Checkbox checkbox2 = null;
	private CheckboxGroup checkboxGroup = null;  
	/**
	 * This is the default constructor
	 */
	public CheckboxGroupTest() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getCheckbox(), java.awt.BorderLayout.NORTH);
			jContentPane.add(getCheckbox1(), java.awt.BorderLayout.CENTER);
			jContentPane.add(getCheckbox2(), java.awt.BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes checkbox	
	 * 	
	 * @return java.awt.Checkbox	
	 */
	private Checkbox getCheckbox() {
		if (checkbox == null) {
			checkbox = new Checkbox();
			checkbox.setCheckboxGroup(getCheckboxGroup());
		}
		return checkbox;
	}

	/**
	 * This method initializes checkbox1	
	 * 	
	 * @return java.awt.Checkbox	
	 */
	private Checkbox getCheckbox1() {
		if (checkbox1 == null) {
			checkbox1 = new Checkbox();
		}
		return checkbox1;
	}

	/**
	 * This method initializes checkbox2	
	 * 	
	 * @return java.awt.Checkbox	
	 */
	private Checkbox getCheckbox2() {
		if (checkbox2 == null) {
			checkbox2 = new Checkbox();
		}
		return checkbox2;
	}

	/**
	 * This method initializes checkboxGroup	
	 * 	
	 * @return java.awt.CheckboxGroup	
	 */
	private CheckboxGroup getCheckboxGroup() {
		if (checkboxGroup == null) {
			checkboxGroup = new CheckboxGroup();
		}
		return checkboxGroup;
	}

}
