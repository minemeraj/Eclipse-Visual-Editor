package test.me;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class Test4_Events {

	private CustomBook customBook = null;  //  @jve:visual-constraint="103,56"
	private BookButton bookButton = null;  //  @jve:decl-index=0:visual-constraint="188,56"

	/**
	 * This method initializes customBook	
	 * 	
	 * @return test.me.CustomBook	
	 */    
	private CustomBook getCustomBook() {
		if (customBook == null) {
			customBook = new CustomBook();
			customBook.addBookListener(new test.me.BookListener() { 
				public void authorChanged(javax.swing.event.TableModelEvent e) {    
					System.out.println("authorChanged()"); // TODO Auto-generated Event stub authorChanged()
				}
			});
		}
		return customBook;
	}

	/**
	 * This method initializes bookButton	
	 * 	
	 * @return test.me.BookButton	
	 */    
	private BookButton getBookButton() {
		if (bookButton == null) {
			bookButton = new BookButton();
			bookButton.setSize(108, 92);
			//bookButton.setBook(getCustomBook());
		}
		return bookButton;
	}

}
