package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;

public class Point_Rectangle_Test {

	private Shell sShell = null;
	private Rectangle defaultRectangle = null;
	private Button button = null;
	
	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		defaultRectangle = new Rectangle(30,30,100,100);
		Point location = new Point(defaultRectangle.x, defaultRectangle.y);
		Point size = new Point(defaultRectangle.width, defaultRectangle.height);
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setSize(new Point(300, 200));
		button = new Button(sShell, SWT.NONE);
		button.setText("30,30 - 100x100");
		button.setLocation(location);
		button.setSize(size);
	}

}
