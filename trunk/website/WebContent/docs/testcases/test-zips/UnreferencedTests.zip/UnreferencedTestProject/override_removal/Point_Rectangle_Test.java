package override_removal;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Point_Rectangle_Test extends JFrame {

	private JPanel jContentPane = null;
	private JButton jButton = null;
	private Rectangle defaultRect = null;

	/**
	 * This is the default constructor
	 */
	public Point_Rectangle_Test() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJButton(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			defaultRect = new Rectangle(100,100,100,100);
			Point location = defaultRect.getLocation();
			Dimension size = defaultRect.getSize();
			jButton = new JButton();
			jButton.setLocation(location);
			jButton.setSize(size);
		}
		return jButton;
	}

}
