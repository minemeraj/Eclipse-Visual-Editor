package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.widgets.Display;

public class FontTest {

	private Shell sShell = null;
	private Button button = null;
	private Label label = null;
	private Font fieldFont;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setSize(new Point(300, 200));
		button = new Button(sShell, SWT.NONE);
		button.setBounds(new org.eclipse.swt.graphics.Rectangle(33,20,226,43));
		Font localVariableFont = new Font(Display.getDefault(), "Times New Roman CE", 18, SWT.NORMAL);
		button.setFont(localVariableFont);
		button.setText("Local variable font");
		label = new Label(sShell, SWT.NONE);
		label.setBounds(new org.eclipse.swt.graphics.Rectangle(30,80,246,44));
		fieldFont = new Font(Display.getDefault(), "Nimrod", 12, SWT.NORMAL);
		label.setFont(fieldFont);
		label.setText("Field font");
	}

}
