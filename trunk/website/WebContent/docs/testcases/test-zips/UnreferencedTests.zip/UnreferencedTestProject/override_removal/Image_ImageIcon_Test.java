package override_removal;

import java.awt.BorderLayout;
import java.awt.Image;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class Image_ImageIcon_Test extends JFrame {

	private JPanel jContentPane = null;
	private JButton jButton = null;
	private ImageIcon swingImage;

	/**
	 * This is the default constructor
	 */
	public Image_ImageIcon_Test() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 200);
		Image EclipseBeanImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/javabean-swt.gif"));
		this.setIconImage(EclipseBeanImage);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJButton(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			swingImage = new ImageIcon(getClass().getResource("/javabean-swing.gif"));
			jButton.setIcon(swingImage);
		}
		return jButton;
	}

}
