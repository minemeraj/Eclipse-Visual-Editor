package test.me;

import javax.swing.JTextArea;


public class Test1 {

	private CustomBook book = null;  //  @jve:visual-constraint=""
	private BookButton bookButton = null;  //  @jve:decl-index=0:visual-constraint="64,61"
	private BookButton bookButton1 = null;  //  @jve:decl-index=0:visual-constraint="66,110"
	private CustomBook book1 = null; //  @jve:visual-constraint=""
	/**
	 * This method initializes book	
	 * 	
	 * @return java.awt.print.Book	
	 */    
	private CustomBook getBook() {
		if (book == null) {
			book = new CustomBook();
			book.setAuthor("Book author");
		}
		return book;
	}
	/**
	 * This method initializes bookButton	
	 * 	
	 * @return test.me.BookButton	
	 */    
	private BookButton getBookButton() {
		if (bookButton == null) {
			bookButton = new BookButton();
			bookButton.setSize(168, 40);
			//bookButton.setBook(getBook());
		}
		return bookButton;
	}
	/**
	 * This method initializes bookButton1	
	 * 	
	 * @return test.me.BookButton	
	 */    
	private BookButton getBookButton1() {
		if (bookButton1 == null) {
			bookButton1 = new BookButton();
			bookButton1.setSize(165, 39);
			//bookButton1.setBook(book1);
		}
		return bookButton1;
	}
	/**
	 * This method initializes book1	
	 * 	
	 * @return java.awt.print.Book	
	 */    
	private CustomBook getBook1() {
		if (book1 == null) {
			book1 = new CustomBook();
			book1.setAuthor("Book ONE author");
		}
		return book1;
	}
}
