package override_removal;

import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

public class Dimension_Insets_Test extends JPanel {

	private JButton jButton = null;  //  @jve:decl-index=0:visual-constraint="325,24"
	private Dimension buttonSize ;
	private JLabel jLabel = null;

	/**
	 * This is the default constructor
	 */
	public Dimension_Insets_Test() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		GridBagConstraints gridBagConstraints = new GridBagConstraints();
		java.awt.Insets jLabelInsets = new java.awt.Insets(120,120,120,120);
		gridBagConstraints.insets = jLabelInsets;
		jLabel = new JLabel();
		jLabel.setText("JLabel");
		jLabel.setName("jLabel");
		Dimension fixedSize = new Dimension(300,300);
		this.setLayout(new GridBagLayout());
		this.setSize(fixedSize);
		this.add(jLabel, gridBagConstraints);
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			buttonSize =  new Dimension(100, 100);
			jButton.setSize(buttonSize);
			jButton.setText("100x100");
		}
		return jButton;
	}

}
