package override_removal;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;

public class FontTest extends JPanel {

	private java.awt.Font fieldFont;
	private JButton jButton = null;
	private JLabel jLabel = null;

	/**
	 * This is the default constructor
	 */
	public FontTest() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		jLabel = new JLabel();
		jLabel.setText("localVariableFont");
		java.awt.Font localVariableFont = new java.awt.Font("Brush Script", java.awt.Font.BOLD | java.awt.Font.ITALIC, 24);
		jLabel.setFont(localVariableFont);
		this.setSize(300, 200);
		fieldFont = new java.awt.Font("Arabic Transparent", java.awt.Font.BOLD | java.awt.Font.ITALIC, 18);
		this.setFont(fieldFont);
		this.add(jLabel, null);
		this.add(getJButton(), null);
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setFont(fieldFont);
			jButton.setText("fieldFont");
		}
		return jButton;
	}

}
