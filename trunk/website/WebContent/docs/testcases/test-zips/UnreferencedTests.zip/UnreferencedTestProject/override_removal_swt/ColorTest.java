package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;

public class ColorTest extends Composite {

	private Label label = null;
	private Color redColor;

	public ColorTest(Composite parent, int style) {
		super(parent, style);
		initialize();
	}

	private void initialize() {
		Color myColor = new Color(Display.getCurrent(), 236, 233, 12);
		this.setBackground(myColor);
		setSize(new Point(300, 200));
		label = new Label(this, SWT.NONE);
		label.setBounds(new org.eclipse.swt.graphics.Rectangle(67,52,158,98));
		redColor = Display.getCurrent().getSystemColor(SWT.COLOR_RED);
		label.setForeground(redColor);
		label.setText("Red text");
	}

}
