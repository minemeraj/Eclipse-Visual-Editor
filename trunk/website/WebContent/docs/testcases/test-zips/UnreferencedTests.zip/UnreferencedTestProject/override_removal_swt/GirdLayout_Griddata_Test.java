package override_removal_swt;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;

public class GirdLayout_Griddata_Test {

	private Shell sShell = null;
	private Button button = null;
	private Button checkBox = null;

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		GridData gridData1 = new org.eclipse.swt.layout.GridData();
		gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData1.verticalAlignment = org.eclipse.swt.layout.GridData.END;
		GridData gridData = new org.eclipse.swt.layout.GridData();
		gridData.horizontalSpan = 3;
		gridData.grabExcessVerticalSpace = true;
		gridData.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
		gridData.grabExcessHorizontalSpace = true;
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 4;
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setLayout(gridLayout);
		sShell.setSize(new Point(300, 200));
		button = new Button(sShell, SWT.NONE);
		button.setText("Button");
		button.setLayoutData(gridData1);
		checkBox = new Button(sShell, SWT.CHECK);
		checkBox.setText("Checkbox");
		checkBox.setLayoutData(gridData);
	}

}
