package override_removal;

import javax.swing.JTable;
import javax.swing.table.TableColumn;

public class TableColumnTest {

	private JTable jTable = null;  //  @jve:decl-index=0:visual-constraint="45,29"
	private TableColumn invisibleFieldTC;

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable() {
		if (jTable == null) {
			TableColumn ivjTableColumn = new TableColumn();
			TableColumn invisibleLocalVarTC = new TableColumn();
			invisibleFieldTC = new TableColumn();
			jTable = new JTable();
			jTable.setAutoCreateColumnsFromModel(false);
			jTable.setSize(new java.awt.Dimension(173,75));
			jTable.addColumn(ivjTableColumn);
		}
		return jTable;
	}

}
