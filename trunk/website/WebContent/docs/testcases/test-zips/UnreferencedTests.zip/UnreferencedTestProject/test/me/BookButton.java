package test.me;

import javax.swing.JButton;

public class BookButton extends JButton {
private static final long serialVersionUID = 1L;
private CustomBook book;

public CustomBook getBook() {
	return book;
}

public void setBook(CustomBook book) {
	this.book = book;
	setText("Book set:"+book);
}
}
