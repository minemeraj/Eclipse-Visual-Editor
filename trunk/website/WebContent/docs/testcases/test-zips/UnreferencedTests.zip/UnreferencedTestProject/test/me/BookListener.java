package test.me;

import java.util.EventListener;

import javax.swing.event.TableModelEvent;

public interface BookListener extends EventListener {
public void authorChanged(TableModelEvent e);
}
