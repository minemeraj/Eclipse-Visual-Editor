package com.ibm.ivj.examples.vc.swing.layoutmanagers;

/*
 * Licensed Materials - Property of IBM,
 * VisualAge for Java
 * (c) Copyright IBM Corp 1998, 2001
 */
/**
 * This type was created in VisualAge.
 */
public class XAlignmentBoxLayoutPage extends javax.swing.JPanel implements java.awt.event.MouseListener {
	private javax.swing.JButton ivjJButton1 = null;
	private javax.swing.JButton ivjJButton2 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
	private javax.swing.BoxLayout ivjXAlignmentBoxLayoutPageBoxLayout = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public XAlignmentBoxLayoutPage() {
	super();
	initialize();
}
/**
 * XAlignmentBoxLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public XAlignmentBoxLayoutPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * XAlignmentBoxLayoutPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public XAlignmentBoxLayoutPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * XAlignmentBoxLayoutPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public XAlignmentBoxLayoutPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * connEtoC1:  (JTextArea1.mouse.mouseClicked(java.awt.event.MouseEvent) --> XAlignmentBoxLayoutPage.jTextArea1_MouseClicked(Ljava.awt.event.MouseEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.MouseEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.jTextArea1_MouseClicked(arg1);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new javax.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setPreferredSize(new java.awt.Dimension(197, 27));
			ivjJButton1.setText("X=0.0(LEFT_ALIGNMENT)");
			ivjJButton1.setBackground(java.awt.Color.orange);
			ivjJButton1.setMaximumSize(new java.awt.Dimension(150, 100));
			ivjJButton1.setMinimumSize(new java.awt.Dimension(150, 100));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJButton1;
}
/**
 * Return the JButton2 property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getJButton2() {
	if (ivjJButton2 == null) {
		try {
			ivjJButton2 = new javax.swing.JButton();
			ivjJButton2.setName("JButton2");
			ivjJButton2.setText("X=0.5(CENTER_ALIGNMENT)");
			ivjJButton2.setBackground(java.awt.Color.green);
			ivjJButton2.setMaximumSize(new java.awt.Dimension(200, 150));
			ivjJButton2.setPreferredSize(new java.awt.Dimension(209, 27));
			ivjJButton2.setAlignmentX(0.5F);
			ivjJButton2.setMinimumSize(new java.awt.Dimension(200, 150));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJButton2;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1");
			ivjJTextArea1.setAlignmentY(0.0F);
			ivjJTextArea1.setText("X=1.0 (RIGHT_ALIGNMENT).\nClick the middle of this component. This changes its \nX alignment to be 0.5 (CENTER_ALIGNMENT),\nwhich means that its middle is along the same\nvertical line as the middle of other components\nthat have 0.5 X alignment. The top component\nstill has an X alignment of 0.0 (LEFT_ALIGNMENT),\nwhich makes its left side aligned with the other\ncomponents\' centers.");
			ivjJTextArea1.setBackground(java.awt.Color.magenta);
			ivjJTextArea1.setMaximumSize(new java.awt.Dimension(300, 200));
			ivjJTextArea1.setPreferredSize(new java.awt.Dimension(436, 121));
			ivjJTextArea1.setAlignmentX(1.0F);
			ivjJTextArea1.setMinimumSize(new java.awt.Dimension(300, 200));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Return the XAlignmentBoxLayoutPageBoxLayout property value.
 * @return javax.swing.BoxLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.BoxLayout getXAlignmentBoxLayoutPageBoxLayout() {
	javax.swing.BoxLayout ivjXAlignmentBoxLayoutPageBoxLayout = null;
	try {
		/* Create part */
		ivjXAlignmentBoxLayoutPageBoxLayout = new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjXAlignmentBoxLayoutPageBoxLayout;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() throws java.lang.Exception {
	// user code begin {1}
	// user code end
	getJTextArea1().addMouseListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("XAlignmentBoxLayoutPage");
		setLayout(getXAlignmentBoxLayoutPageBoxLayout());
		setBackground(new java.awt.Color(230,230,230));
		setSize(500, 270);
		add(getJButton1());
		add(getJButton2(), getJButton2().getName());
		add(getJTextArea1(), getJTextArea1().getName());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jTextArea1_MouseClicked(java.awt.event.MouseEvent mouseEvent) {
	getJTextArea1().setAlignmentX((float)0.5);
	invalidate();
	getParent().validate();	
	return;
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		com.ibm.ivj.examples.vc.swing.layoutmanagers.XAlignmentBoxLayoutPage aXAlignmentBoxLayoutPage;
		aXAlignmentBoxLayoutPage = new com.ibm.ivj.examples.vc.swing.layoutmanagers.XAlignmentBoxLayoutPage();
		frame.getContentPane().add("Center", aXAlignmentBoxLayoutPage);
		frame.setSize(aXAlignmentBoxLayoutPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseClicked(java.awt.event.MouseEvent e) {
	// user code begin {1}
	// user code end
	if (e.getSource() == getJTextArea1()) 
		connEtoC1(e);
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseEntered(java.awt.event.MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseExited(java.awt.event.MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mousePressed(java.awt.event.MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseReleased(java.awt.event.MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
}
