package gridbaglayout.example;

import javax.swing.AbstractListModel;

/*
 * Created on May 15, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author pwalker
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class GridBagLayoutExampleListModel extends AbstractListModel {
	String [] data =  
	   {  "Serif", "SansSerif", "Monospaced", 
		  "Dialog", "DialogInput" 
	   };

	/* (non-Javadoc)
	 * @see javax.swing.ListModel#getElementAt(int)
	 */
	public Object getElementAt(int arg0) {
		if (arg0 < data.length)
			return data[arg0];
		return data[0];
	}

	/* (non-Javadoc)
	 * @see javax.swing.ListModel#getSize()
	 */
	public int getSize() {
		return data.length;
	}

}
