package gridbaglayout.example;

import java.awt.Font;

import javax.swing.JFrame;

/*
 * Created on Apr 8, 2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author pwalker
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class GridBagLayoutExample extends JFrame {

	 private javax.swing.JPanel jContentPane = null;
	 private javax.swing.JLabel jLabel = null;
	 private javax.swing.JCheckBox jCheckBox = null;
	 private javax.swing.JCheckBox jCheckBox1 = null;
	 private javax.swing.JTextField jTextField = null;
	 private javax.swing.JTextField jTextField1 = null;
	 private javax.swing.JList styleList = null;
	 private javax.swing.JLabel jLabel1 = null;
     
	/**
	 * This method initializes 
	 * 
	 */
	public GridBagLayoutExample() {
		super();
		initialize();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setContentPane(getJContentPane());
		this.setSize(352, 284);
		this.setTitle("GridBagLayout Example");
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJContentPane() {
		if(jContentPane == null) {
			jContentPane = new javax.swing.JPanel();
			java.awt.GridBagConstraints consGridBagConstraints7 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints8 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints9 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints11 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints12 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints16 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints17 = new java.awt.GridBagConstraints();
			consGridBagConstraints16.gridy = 3;
			consGridBagConstraints16.gridx = 1;
			consGridBagConstraints17.gridy = 3;
			consGridBagConstraints17.gridx = 2;
			consGridBagConstraints7.gridy = 1;
			consGridBagConstraints7.gridx = 2;
			consGridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
			consGridBagConstraints9.weightx = 1.0;
			consGridBagConstraints9.gridy = 4;
			consGridBagConstraints9.gridx = 0;
			consGridBagConstraints9.gridwidth = 3;
			consGridBagConstraints11.gridy = 0;
			consGridBagConstraints11.gridx = 0;
			consGridBagConstraints9.anchor = java.awt.GridBagConstraints.SOUTH;
			consGridBagConstraints12.gridy = 1;
			consGridBagConstraints12.gridx = 0;
			consGridBagConstraints8.gridy = 2;
			consGridBagConstraints8.gridx = 2;
			consGridBagConstraints8.insets = new java.awt.Insets(5,0,30,0);
			consGridBagConstraints7.insets = new java.awt.Insets(5,0,5,0);
			consGridBagConstraints12.weighty = 1.0D;
			consGridBagConstraints12.fill = java.awt.GridBagConstraints.BOTH;
			consGridBagConstraints12.gridheight = 3;
			consGridBagConstraints16.insets = new java.awt.Insets(0,20,0,5);
			consGridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints9.insets = new java.awt.Insets(0,5,0,0);
			jContentPane.setLayout(new java.awt.GridBagLayout());
			jContentPane.add(getJLabel(), consGridBagConstraints11);
			jContentPane.add(getJCheckBox(), consGridBagConstraints7);
			jContentPane.add(getJCheckBox1(), consGridBagConstraints8);
			jContentPane.add(getJTextField(), consGridBagConstraints17);
			jContentPane.add(getJTextField1(), consGridBagConstraints9);
			jContentPane.add(getStyleList(), consGridBagConstraints12);
			jContentPane.add(getJLabel1(), consGridBagConstraints16);
		}
		return jContentPane;
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setText("Font style");
		}
		return jLabel;
	}
	/**
	 * This method initializes jCheckBox
	 * 
	 * @return javax.swing.JCheckBox
	 */
	private javax.swing.JCheckBox getJCheckBox() {
		if(jCheckBox == null) {
			jCheckBox = new javax.swing.JCheckBox();
			jCheckBox.setText("Bold");
			jCheckBox.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					updateFont();
				}
			});
		}
		return jCheckBox;
	}
	/**
	 * This method initializes jCheckBox1
	 * 
	 * @return javax.swing.JCheckBox
	 */
	private javax.swing.JCheckBox getJCheckBox1() {
		if(jCheckBox1 == null) {
			jCheckBox1 = new javax.swing.JCheckBox();
			jCheckBox1.setText("Italic");
			jCheckBox1.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					updateFont();
				}
			});
		}
		return jCheckBox1;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField() {
		if(jTextField == null) {
			jTextField = new javax.swing.JTextField();
			jTextField.setText("12");
			jTextField.setColumns(4);
			jTextField.addActionListener(new java.awt.event.ActionListener() { 
				public void actionPerformed(java.awt.event.ActionEvent e) {    
					updateFont();
				}
			});
		}
		return jTextField;
	}
	/**
	 * This method initializes jTextField1
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField1() {
		if(jTextField1 == null) {
			jTextField1 = new javax.swing.JTextField();
			jTextField1.setEditable(false);
			jTextField1.setText("The quick brown fox");
		}
		return jTextField1;
	}
	/**
	 * This method initializes styleList
	 * 
	 * @return javax.swing.JList
	 */
	private javax.swing.JList getStyleList() {
		if(styleList == null) {
			styleList = new javax.swing.JList();
			styleList.setModel(new GridBagLayoutExampleListModel());
			styleList.addListSelectionListener(new javax.swing.event.ListSelectionListener() { 
				public void valueChanged(javax.swing.event.ListSelectionEvent e) {    
					updateFont();
				}
			});
			styleList.setSelectedIndex(0);
		}
		return styleList;
	}
	/**
	 * This method initializes jLabel1
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel1() {
		if(jLabel1 == null) {
			jLabel1 = new javax.swing.JLabel();
			jLabel1.setText("Size: ");
		}
		return jLabel1;
	}

	public void updateFont()
	{  Font font = 
		  new Font((String)getStyleList().getSelectedValue(),
			 (getJCheckBox().isSelected() ? Font.BOLD : 0)
				+ (getJCheckBox1().isSelected() ? Font.ITALIC : 0),
			 Integer.parseInt(getJTextField().getText()));
	   getJTextField1().setFont(font);
	   repaint();
	}

}  //  @jve:visual-info  decl-index=0 visual-constraint="0,0"
